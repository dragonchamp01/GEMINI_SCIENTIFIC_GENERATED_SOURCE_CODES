# Turing Machine Simulation

## Concept
A Turing Machine is a theoretical model of computation consisting of an infinite tape divided into cells, a tape head that can read and write symbols, and a finite set of states. It is the foundation of modern computer science and is used to define the concept of computability (what can and cannot be computed).

## Components
1.  **Tape**: An infinite list of symbols (initially mostly blanks).
2.  **Head**: Points to the current cell being read/written.
3.  **State Register**: Stores the current internal state of the machine.
4.  **Transition Table**: Rules that specify: (Current State, Current Symbol) $	o$ (New Symbol, Move Direction, New State).

## Code Explanation
The provided code simulates a simple Turing Machine that increments a binary number on the tape. It defines the states (e.g., "scan", "increment", "halt") and the transition rules. The implementation shows how the tape and head evolve step-by-step.
