# Topology Basics

## Concept
Topology is the mathematical study of the properties that are preserved through deformations, twistings, and stretchings of objects. In a discrete space, a topology is a collection of subsets (called "open sets") that satisfy certain axioms. From these open sets, we can define:
1.  **Interior**: The largest open set contained within a set.
2.  **Closure**: The smallest closed set containing a set.
3.  **Boundary**: The difference between the closure and the interior.

## Axioms
A collection $	au$ of subsets of $X$ is a topology if:
1.  $\emptyset \in 	au$ and $X \in 	au$.
2.  The union of any subcollection of $	au$ is in $	au$.
3.  The intersection of any finite subcollection of $	au$ is in $	au$.

## Code Explanation
The provided code defines a simple topology on a set $X = \{1, 2, 3\}$. It implements functions to calculate the interior and closure of an arbitrary subset $A \subseteq X$ based on the given open sets.
