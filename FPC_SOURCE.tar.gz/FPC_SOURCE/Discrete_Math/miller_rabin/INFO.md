# Miller-Rabin Primality Test

## Concept
The Miller-Rabin primality test is a probabilistic algorithm used to determine whether a number is prime. It is based on properties of strong pseudoprimes. Unlike trial division, it can check very large numbers for primality extremely quickly. While it is probabilistic, the probability of a composite number being identified as prime (a "false positive") can be made arbitrarily small by increasing the number of trials.

## Formula
For an odd integer $n > 2$, we write $n-1 = 2^s \cdot d$, where $d$ is odd.
A witness $a$ (where $1 < a < n-1$) is a number such that:
1. $a^d 
ot\equiv 1 \pmod n$
2. $a^{2^r \cdot d} 
ot\equiv -1 \pmod n$ for all $0 \le r < s$.
If both conditions are true, $n$ is composite. Otherwise, $n$ is probably prime.

## Code Explanation
The provided code implements the Miller-Rabin test. It includes a modular exponentiation function to handle large powers without overflow. The test is performed with multiple random witnesses to ensure high confidence in the result.
