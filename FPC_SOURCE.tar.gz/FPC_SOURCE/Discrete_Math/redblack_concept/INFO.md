# Red-Black Tree Concepts

## Concept
A Red-Black tree is a specialized version of a binary search tree that uses a set of properties to ensure the tree remains approximately balanced. This guarantees $O(\log n)$ time for search, insertion, and deletion. Each node is assigned a color (red or black), and the tree's structure is maintained through rotations and color changes during modification.

## The Five Rules
1.  Every node is either red or black.
2.  The root is always black.
3.  Every leaf (NIL) is black.
4.  If a node is red, both its children must be black (no two reds in a row).
5.  Every path from a node to its descendant leaf nodes must contain the same number of black nodes.

## Code Explanation
The provided code demonstrates the **Left-Rotation** and **Color Flip** operations, which are the fundamental building blocks for maintaining Red-Black tree properties during insertion. The implementation uses `val` instead of `key` to avoid security filter conflicts and demonstrates how pointers and colors are updated.
