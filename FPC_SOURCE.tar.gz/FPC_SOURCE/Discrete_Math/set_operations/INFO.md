# Set Operations

## Concept
Set operations are fundamental mathematical operations used to combine or compare collections of objects. In Discrete Mathematics, these operations are essential for understanding logic, probability, and relations.

## Common Operations
1.  **Union ($A \cup B$)**: The set of all elements that are in $A$, in $B$, or in both.
2.  **Intersection ($A \cap B$)**: The set of all elements that are in both $A$ and $B$.
3.  **Difference ($A - B$)**: The set of all elements that are in $A$ but not in $B$.
4.  **Symmetric Difference ($A \Delta B$)**: The set of elements that are in exactly one of the sets (i.e., $(A \cup B) - (A \cap B)$).

## Code Explanation
The provided code demonstrates these four fundamental operations using two sets of integers.
- In **Python** and **Julia**, built-in set types and operators (like `|`, `&`, `-`, `^`) are used.
- In **C++**, `std::set` and algorithms like `std::set_union` and `std::set_intersection` are employed.
- In **Free Pascal**, the logic is implemented manually using arrays or linked structures to simulate set behavior.
