# Edmonds-Karp Algorithm

## Concept
The Edmonds-Karp algorithm is an implementation of the Ford-Fulkerson method for computing the maximum flow in a flow network. It specifically uses Breadth-First Search (BFS) to find the shortest augmenting path (in terms of number of edges). This choice of BFS guarantees that the algorithm terminates in polynomial time, regardless of the edge capacities.

## Algorithm
1. Use BFS to find the shortest path from source $s$ to sink $t$ in the residual graph.
2. If a path is found:
   a. Identify the bottleneck capacity $c_{min}$ along the path.
   b. Update residual capacities along the path and its reverse edges.
   c. Add $c_{min}$ to the total flow.
3. Repeat until no path from $s$ to $t$ exists.

## Code Explanation
The provided code implements Edmonds-Karp using a queue-based BFS to find augmenting paths and an array to store the parent of each node in the path for backtracking.
