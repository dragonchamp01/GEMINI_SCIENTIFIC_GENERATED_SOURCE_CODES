# Dijkstra's Algorithm

## Concept
Dijkstra's algorithm is used for finding the shortest paths between nodes in a graph. For a given source node in the graph, the algorithm finds the shortest path between that node and every other node. It is a greedy algorithm that uses a priority queue to select the next node with the smallest tentative distance.

## Formula
1. Initialize distances: $dist[source] = 0$, all other $dist[v] = \infty$.
2. Add all nodes to a priority queue $Q$.
3. While $Q$ is not empty:
   a. Extract node $u$ with minimum $dist[u]$.
   b. For each neighbor $v$ of $u$:
      $alt = dist[u] + weight(u, v)$
      if $alt < dist[v]$: $dist[v] = alt$.

## Code Explanation
The provided code implements Dijkstra's algorithm using an adjacency list and a priority queue (or min-heap). It calculates the shortest distance from a start node to all reachable nodes in a sample graph.
