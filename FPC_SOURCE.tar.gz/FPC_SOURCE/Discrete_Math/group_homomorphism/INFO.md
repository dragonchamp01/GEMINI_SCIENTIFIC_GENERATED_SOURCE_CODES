# Group Homomorphism

## Concept
A group homomorphism is a map $f: G 	o H$ between two groups $(G, \ast)$ and $(H, \cdot)$ such that for all $a, b \in G$:
$f(a \ast b) = f(a) \cdot f(b)$
This property ensures that the structure of the group is preserved under the mapping. Common examples include the exponential map from $(\mathbb{R}, +)$ to $(\mathbb{R}^+, 	imes)$ or the modulo operation.

## Properties
-   $f(e_G) = e_H$ (Identity is mapped to identity).
-   $f(a^{-1}) = f(a)^{-1}$ (Inverses are preserved).
-   The kernel of $f$ is a normal subgroup of $G$.

## Code Explanation
The provided code demonstrates a homomorphism from $(\mathbb{Z}, +)$ to $(\mathbb{Z}_n, + \pmod n)$. It verifies the property $f(a+b) = f(a) + f(b) \pmod n$ for various integer pairs.
