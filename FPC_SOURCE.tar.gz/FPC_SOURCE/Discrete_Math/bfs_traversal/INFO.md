# Breadth-First Search (BFS) Traversal

## Concept
Breadth-First Search (BFS) is a fundamental graph traversal algorithm. It starts at a designated source node and explores all its direct neighbors before moving on to the neighbors of those neighbors. This "level-by-level" exploration makes BFS ideal for finding the shortest path in unweighted graphs.

## Algorithm
1. Initialize a queue and a list/set to keep track of visited nodes.
2. Push the starting node into the queue and mark it as visited.
3. While the queue is not empty:
   a. Dequeue a node $u$.
   b. Process node $u$ (e.g., print its value).
   c. For each neighbor $v$ of $u$ that has not been visited:
      - Mark $v$ as visited.
      - Enqueue $v$.

## Code Explanation
The provided code implements BFS using an adjacency list representation of a graph. It uses a queue to manage the frontier of exploration and a visited array to ensure each node is processed exactly once.
