# Planarity Check

## Concept
A planar graph is a graph that can be drawn in the plane such that no edges cross each other. Planarity is a fundamental property in graph theory with applications in circuit design and geography. Kuratowski's Theorem states that a finite graph is planar if and only if it does not contain a subgraph that is a subdivision of $K_5$ (complete graph on 5 vertices) or $K_{3,3}$ (complete bipartite graph on 3+3 vertices).

## Necessary Conditions
For a simple connected planar graph with $V \ge 3$ vertices and $E$ edges:
1. $E \le 3V - 6$
2. If the graph has no cycles of length 3 (e.g., bipartite), then $E \le 2V - 4$.
Euler's Formula: $V - E + F = 2$, where $F$ is the number of faces.

## Code Explanation
The provided code implements basic planarity checks using Euler's necessary conditions. While a full planarity test (like the Hopcroft-Tarjan algorithm) is complex, these conditions quickly identify many non-planar graphs. The code evaluates $V$ and $E$ and checks the inequality $E \le 3V - 6$.
