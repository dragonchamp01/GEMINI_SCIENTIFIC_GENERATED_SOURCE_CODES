# Dihedral Group D3

## Concept
The dihedral group $D_3$ is the group of symmetries of an equilateral triangle. It includes rotations and reflections that leave the triangle's shape and position unchanged. It is the smallest non-Abelian dihedral group and is isomorphic to the symmetric group $S_3$.

## Elements
The group has $2 \cdot 3 = 6$ elements:
-   **Rotations**: $R_0$ (0°), $R_{120}$ (120°), $R_{240}$ (240°)
-   **Reflections**: $S_1, S_2, S_3$ (reflections across the three altitudes of the triangle).

## Properties
-   The product of two rotations is a rotation.
-   The product of two reflections is a rotation.
-   The product of a rotation and a reflection is a reflection.
-   The group is non-Abelian (e.g., $R_{120} \circ S_1 
eq S_1 \circ R_{120}$).

## Code Explanation
The provided code represents the symmetry operations as permutation of the triangle's vertices. It demonstrates the composition of rotations and reflections and verifies the isomorphism with $S_3$ by showing similar algebraic behavior.
