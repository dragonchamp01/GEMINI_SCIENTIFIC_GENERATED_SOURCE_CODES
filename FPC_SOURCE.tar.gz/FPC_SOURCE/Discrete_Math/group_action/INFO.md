# Group Action

## Concept
A group action is a formal way of using a group to describe the symmetries of a set. If $G$ is a group and $X$ is a set, a group action of $G$ on $X$ is a function that maps $(g, x)$ to another element in $X$ while preserving the identity and composition properties. Group actions are used to define orbits, stabilizers, and to prove results like Burnside's Lemma.

## Properties
1.  **Identity**: $e \cdot x = x$ for all $x \in X$.
2.  **Compatibility**: $(gh) \cdot x = g \cdot (h \cdot x)$ for all $g, h \in G$ and $x \in X$.
-   **Orbit**: The set of elements in $X$ that $x$ can be moved to by elements of $G$.
-   **Stabilizer**: The set of elements in $G$ that leave $x$ fixed.

## Code Explanation
The provided code simulates the action of the cyclic group $\mathbb{Z}_4$ on a set of 4 items by cyclic shifting. It calculates the orbit of an element and the stabilizer subgroup, demonstrating the fundamental properties of group actions.
