# Subgroup Lattice

## Concept
A subgroup lattice is a partial order diagram (Hasse diagram) that shows all the subgroups of a group $G$ and how they are contained within one another. Each node represents a subgroup, and an edge from $H$ to $K$ indicates that $H \subseteq K$ and there is no subgroup $L$ such that $H \subsetneq L \subsetneq K$.

## Properties
-   The top node is the group $G$ itself.
-   The bottom node is the trivial subgroup $\{e\}$.
-   Lagrange's Theorem: The order of every subgroup $H$ must divide the order of the group $G$.

## Code Explanation
The provided code identifies all subgroups of the cyclic group $(\mathbb{Z}_6, +)$. It iterates through the power set of $\mathbb{Z}_6$, checks if each subset satisfies the group axioms (Closure, Identity, Inverse), and identifies the inclusion hierarchy.
