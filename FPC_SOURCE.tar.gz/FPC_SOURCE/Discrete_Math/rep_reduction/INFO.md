# Representation Reduction

## Concept
A representation is reducible if there is a non-trivial subspace that is invariant under the action of all group elements. Representation reduction is the process of decomposing a large representation into a direct sum of irreducible representations (irreps). In quantum chemistry, this is used to identify the symmetry of molecular orbitals or vibrations.

## Formula
The number of times an irreducible representation $\Gamma_i$ occurs in a reducible representation $\Gamma_{red}$ is given by the reduction formula:
$n_i = \frac{1}{|G|} \sum_{g \in G} \chi_{red}(g) \cdot \chi_i^*(g)$
where $|G|$ is the order of the group and $\chi$ are the characters.

## Code Explanation
The provided code demonstrates the reduction of a simple representation of the group $C_2$ (Identity and Reflection). It uses the character table of $C_2$ and the reduction formula to find how many times each irrep ($A$ and $B$) appears in a given reducible representation.
