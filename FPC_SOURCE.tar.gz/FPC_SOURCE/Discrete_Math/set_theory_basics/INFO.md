# Set Theory Basics

## Concept
Set theory is the branch of mathematical logic that studies sets, which are collections of objects. Fundamental concepts include membership, cardinality (the number of elements), and relations between sets such as being a subset or a superset. Another key concept is the Cartesian product, which combines two sets to form a set of ordered pairs.

## Formula
1.  **Cardinality ($|A|$)**: The number of elements in set $A$.
2.  **Subset ($A \subseteq B$)**: Every element of $A$ is also an element of $B$.
3.  **Cartesian Product ($A 	imes B$)**: The set of all ordered pairs $(a, b)$ where $a \in A$ and $b \in B$.
    $|A 	imes B| = |A| \cdot |B|$

## Code Explanation
The provided code demonstrates:
- Calculating the cardinality of a set.
- Checking if one set is a subset of another.
- Computing the Cartesian product of two sets.
The implementations show how to handle pairs and basic logical checks across different languages.
