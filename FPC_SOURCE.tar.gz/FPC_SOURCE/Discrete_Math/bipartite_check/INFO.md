# Bipartite Graph Check

## Concept
A bipartite graph (or bigraph) is a graph whose vertices can be divided into two disjoint and independent sets $U$ and $V$ such that every edge connects a vertex in $U$ to one in $V$. There are no edges between vertices of the same set. A graph is bipartite if and only if it does not contain any odd-length cycles.

## Algorithm
The most common way to check for bipartiteness is using Breadth-First Search (BFS) or Depth-First Search (DFS) to color the graph:
1. Assign a color (e.g., 0) to the starting node.
2. For each neighbor of the current node:
   a. If the neighbor has not been colored, assign it the opposite color (e.g., 1).
   b. If the neighbor has already been colored with the same color as the current node, the graph is not bipartite.
3. Repeat for all components of the graph.

## Code Explanation
The provided code uses BFS to check if a graph is bipartite. It maintains a color array (using -1 for uncolored, 0 and 1 for the two sets) and validates the edge conditions during traversal.
