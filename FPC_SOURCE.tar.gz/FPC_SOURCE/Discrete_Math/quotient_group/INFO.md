# Quotient Group

## Concept
A quotient group (or factor group) is a mathematical group obtained by partitioning a larger group $G$ using a normal subgroup $N$. The elements of the quotient group, denoted $G/N$, are the cosets of $N$ in $G$. The group operation on $G/N$ is defined by $(aN) \ast (bN) = (a \ast b)N$.

## Properties
1.  **Existence**: The quotient group $G/N$ exists if and only if $N$ is a **normal subgroup** of $G$.
2.  **Order**: If $G$ is finite, the order of the quotient group is $|G/N| = |G| / |N|$.
3.  **Elements**: Each element in $G/N$ is a set (a coset) of elements from the original group.

## Code Explanation
The provided code demonstrates the construction of the quotient group $\mathbb{Z}_{12} / \{0, 4, 8\}$. 
- The original group $G$ is $(\mathbb{Z}_{12}, +)$.
- The normal subgroup $N$ is $\{0, 4, 8\}$.
- The code identifies the distinct cosets (e.g., $\{0, 4, 8\}$, $\{1, 5, 9\}$, etc.) and verifies that they form a group of order 4.
