# Tarjan's SCC Algorithm

## Concept
Strongly Connected Components (SCCs) are subgraphs where every vertex is reachable from every other vertex within that subgraph. Tarjan's algorithm finds all SCCs in a directed graph in linear time $O(V+E)$. It is based on a single Depth-First Search (DFS) traversal.

## Algorithm
1. Perform DFS while maintaining:
   - `discovery_time`: The time a node was first visited.
   - `low_link`: The smallest `discovery_time` reachable from that node in the DFS tree.
2. Push visited nodes onto a stack.
3. If a node's `discovery_time` equals its `low_link`, all nodes currently on the stack down to this node form an SCC.
4. Update `low_link` during DFS to identify back-edges to ancestor nodes.

## Code Explanation
The provided code implements Tarjan's algorithm. It keeps track of the discovery times and low-link values for each node and outputs the list of SCCs found in a sample directed graph.
