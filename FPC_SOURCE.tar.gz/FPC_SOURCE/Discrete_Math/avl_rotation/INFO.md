# AVL Tree Rotations

## Concept
An AVL tree is a self-balancing binary search tree. It maintains its balance by ensuring that the heights of the two child subtrees of any node differ by at most one. When an insertion or deletion causes this balance factor to exceed the threshold, "rotations" are performed to restore balance.

## Types of Rotations
1.  **Right Rotation (LL)**: Used when the left child's left subtree becomes too tall.
2.  **Left Rotation (RR)**: Used when the right child's right subtree becomes too tall.
3.  **Left-Right Rotation (LR)**: A left rotation followed by a right rotation.
4.  **Right-Left Rotation (RL)**: A right rotation followed by a left rotation.

## Code Explanation
The provided code implements the two basic single rotations (Left and Right). It demonstrates how nodes are rearranged to decrease the height of a subtree while preserving the Binary Search Tree property (Left < Root < Right).
