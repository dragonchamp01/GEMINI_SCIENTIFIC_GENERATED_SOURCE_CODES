# Adjacency Matrix

## Concept
In graph theory and computer science, an adjacency matrix is a square matrix used to represent a finite graph. The elements of the matrix indicate whether pairs of vertices are adjacent or not in the graph. For a simple graph, the adjacency matrix is a (0,1)-matrix with zeros on its diagonal. If the graph is undirected, the adjacency matrix is symmetric.

## Formula
For a graph $G$ with $n$ vertices, the adjacency matrix $A$ is an $n 	imes n$ matrix where:
$A_{ij} = 1$ if there is an edge between vertex $i$ and vertex $j$,
$A_{ij} = 0$ otherwise.
For weighted graphs, $A_{ij}$ stores the weight of the edge instead of 1.

## Code Explanation
The provided code demonstrates how to create an adjacency matrix from an edge list and how to perform basic queries (e.g., checking if two nodes are connected). The implementation supports both undirected and directed representations.
