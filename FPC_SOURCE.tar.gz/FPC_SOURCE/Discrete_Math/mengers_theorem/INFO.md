# Menger's Theorem

## Concept
Menger's theorem is a result in graph theory that characterizes the connectivity of a graph. It exists in two versions: node-connectivity and edge-connectivity. In its edge version, it states that the maximum number of edge-disjoint paths between two vertices $u$ and $v$ is equal to the minimum number of edges whose removal disconnects $u$ and $v$. This is a specific case of the Max-Flow Min-Cut Theorem.

## Formula
If $\lambda(u, v)$ is the maximum number of edge-disjoint paths between $u$ and $v$, and $\kappa'(u, v)$ is the size of the minimum edge cut, then:
$\lambda(u, v) = \kappa'(u, v)$

## Code Explanation
The provided code calculates the edge-connectivity between two nodes by treating the graph as a flow network where each edge has a capacity of 1. It uses the Edmonds-Karp Max-Flow algorithm to find the maximum number of disjoint paths, thereby demonstrating Menger's Theorem.
