# Point Group D3h

## Concept
The point group $D_{3h}$ represents the symmetry operations of a trigonal planar object, such as the $BF_3$ molecule. It is a group of order 12, combining the symmetries of a triangle ($D_3$) with a horizontal mirror plane ($\sigma_h$).

## Elements
The 12 elements are:
1.  **E**: Identity.
2.  **2C3**: Two 120° rotations around the z-axis.
3.  **3C2**: Three 180° rotations around axes in the xy-plane.
4.  **σh**: Reflection in the horizontal (xy) plane.
5.  **2S3**: Two improper rotations (rotation followed by reflection).
6.  **3σv**: Three vertical mirror planes.

## Code Explanation
The provided code defines the group elements and their multiplication logic using a lookup-based approach (as the full $12 	imes 12$ table is extensive). It demonstrates the composition of a rotation and a reflection to identify the resulting symmetry operation.
