# Heap's Algorithm for Permutations

## Concept
Heap's algorithm is an efficient method used to generate all possible permutations of $n$ objects. It was first proposed by B. R. Heap in 1963. The algorithm minimizes the amount of work required by only swapping a single pair of elements to move from one permutation to the next.

## Algorithm
The recursive version of Heap's algorithm for $n$ elements:
1. If $n=1$, output the current arrangement.
2. For $i=0$ to $n-1$:
   a. Recursively call for $n-1$ elements.
   b. If $n$ is even, swap the $i$-th element with the $(n-1)$-th element.
   c. If $n$ is odd, swap the $0$-th element with the $(n-1)$-th element.

## Code Explanation
The provided code implements the recursive version of Heap's algorithm. It starts with a simple list $[1, 2, 3]$ and generates all $3! = 6$ permutations. The implementation demonstrates the swapping logic and how to collect or print the results.
