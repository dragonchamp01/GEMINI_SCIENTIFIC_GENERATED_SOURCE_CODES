# Kruskal's Algorithm (Minimum Spanning Tree)

## Concept
Kruskal's algorithm is a greedy algorithm that finds a minimum spanning tree (MST) for a connected weighted graph. An MST is a subset of the edges that connects all vertices together, without any cycles and with the minimum possible total edge weight.

## Formula/Steps
1. Sort all the edges in the graph in non-decreasing order of their weight.
2. Pick the smallest edge. Check if it forms a cycle with the spanning tree formed so far.
3. If a cycle is not formed, include this edge. Else, discard it.
4. Repeat step 2 until there are $(V-1)$ edges in the spanning tree.
Cycle detection is efficiently implemented using the Disjoint Set Union (DSU) or Union-Find data structure.

## Code Explanation
The provided code implements Kruskal's algorithm using a DSU data structure. It defines an edge list, sorts it by weight, and builds the MST by performing Union and Find operations to maintain connectivity without cycles.
