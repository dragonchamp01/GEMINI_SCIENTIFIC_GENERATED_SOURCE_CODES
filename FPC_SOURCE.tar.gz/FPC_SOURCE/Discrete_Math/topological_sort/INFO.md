# Topological Sort

## Concept
Topological sorting for a Directed Acyclic Graph (DAG) is a linear ordering of vertices such that for every directed edge $uv$, vertex $u$ comes before $v$ in the ordering. Topological sorting is not possible if the graph contains a cycle. It is widely used in scheduling tasks, dependency resolution (like package managers), and instruction scheduling in compilers.

## Algorithm (Kahn's Algorithm)
1. Compute the in-degree (number of incoming edges) for each node.
2. Initialize a queue with all nodes having an in-degree of 0.
3. While the queue is not empty:
   a. Extract a node $u$ from the queue and add it to the topological order.
   b. For each neighbor $v$ of $u$, decrement the in-degree of $v$.
   c. If the in-degree of $v$ becomes 0, add $v$ to the queue.
If the number of nodes in the topological order is less than the total number of nodes, the graph has a cycle.

## Code Explanation
The provided code implements Kahn's Algorithm using an adjacency list and an in-degree array. It processes a sample DAG and returns the linear ordering of nodes.
