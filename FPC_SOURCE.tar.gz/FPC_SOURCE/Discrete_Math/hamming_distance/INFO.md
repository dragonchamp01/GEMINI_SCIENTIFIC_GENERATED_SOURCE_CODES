# Hamming Distance

## Concept
The Hamming distance between two strings of equal length is the number of positions at which the corresponding symbols are different. In other words, it measures the minimum number of substitutions required to change one string into the other. It is widely used in telecommunication to count the number of flipped bits in a fixed-length binary word as an estimate of error.

## Formula
For two strings $s_1$ and $s_2$ of length $n$:
$d_H(s_1, s_2) = \sum_{i=1}^{n} [s_1[i] 
eq s_2[i]]$
where the expression inside the sum is 1 if true, and 0 if false.

## Code Explanation
The provided code calculates the Hamming distance between two binary strings or character strings. It verifies that the strings have the same length and then iterates through each position to count the differences.
