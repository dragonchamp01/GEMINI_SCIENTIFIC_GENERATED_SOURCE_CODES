# Power Set

## Concept
The power set of a set $S$, denoted as $\mathcal{P}(S)$, is the collection of all possible subsets of $S$. If a set $S$ has $n$ elements, its power set contains $2^n$ elements. This is a fundamental concept in combinatorics and set theory.

## Formula
For a set $S = \{a, b, c\}$, the power set is:
$\mathcal{P}(S) = \{\emptyset, \{a\}, \{b\}, \{c\}, \{a, b\}, \{a, c\}, \{b, c\}, \{a, b, c\}\}$
One common way to generate the power set is to use the binary representation of integers from $0$ to $2^n - 1$. Each bit corresponds to the presence or absence of an element in a subset.

## Code Explanation
The provided code implements a recursive or bitwise approach to generate all subsets of a given set.
- In **Python**, `itertools.chain` and `combinations` are often used, but here we show a recursive generator.
- In **C++**, a bitmasking approach is used to iterate through all $2^n$ subsets.
- In **Free Pascal**, the bitmasking logic is implemented using loops.
- In **Julia**, a recursive approach is used to demonstrate functional style.
