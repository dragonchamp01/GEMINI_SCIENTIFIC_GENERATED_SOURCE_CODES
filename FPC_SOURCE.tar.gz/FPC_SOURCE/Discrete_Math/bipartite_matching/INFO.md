# Maximum Bipartite Matching

## Concept
In a bipartite graph, a matching is a set of edges such that no two edges share a common vertex. Maximum Bipartite Matching is the process of finding a matching with the maximum possible number of edges. This problem can be solved by reducing it to a Maximum Flow problem or by using a dedicated augmenting path algorithm.

## Algorithm (Augmenting Path)
1. Initialize all vertices as unmatched.
2. For each vertex $u$ in the first set:
   a. Use DFS to find an "augmenting path" (a path that starts and ends at unmatched vertices and alternates between matched and unmatched edges).
   b. If an augmenting path is found, update the matching by flipping the status of edges along the path.
3. The total number of edges in the matching is the size of the maximum matching.

## Code Explanation
The provided code implements the DFS-based augmenting path algorithm. It finds the maximum matching between two sets of nodes (e.g., jobs and people). The implementation handles the adjacency list representation and maintains the match assignments for both sets.
