# Symmetric Group S3

## Concept
The symmetric group $S_3$ is the group of all permutations of a set of 3 elements $\{1, 2, 3\}$. It has $3! = 6$ elements. It is the smallest non-Abelian group, meaning the order of composition matters ($a \circ b 
eq b \cdot a$ for some elements).

## Elements and Composition
The elements are often represented in cycle notation:
-   $e$: Identity (1)(2)(3)
-   $ho_1$: (1 2 3) - Rotation/Shift
-   $ho_2$: (1 3 2) - Rotation/Shift
-   $\mu_1$: (2 3) - Swap 2 and 3
-   $\mu_2$: (1 3) - Swap 1 and 3
-   $\mu_3$: (1 2) - Swap 1 and 2

The group operation is the composition of permutations (applying one after another).

## Code Explanation
The provided code represents elements of $S_3$ as tuples/arrays. It implements a composition function and generates the full $6 	imes 6$ Cayley table for $S_3$. It demonstrates that the group is non-Abelian by comparing $a \circ b$ and $b \circ a$.
