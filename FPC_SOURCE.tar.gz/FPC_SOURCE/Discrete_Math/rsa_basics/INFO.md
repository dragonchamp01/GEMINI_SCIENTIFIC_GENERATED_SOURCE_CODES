# RSA Fundamentals

## Concept
RSA (Rivest-Shamir-Adleman) is a public-key cryptosystem used for secure data transmission. It is based on the mathematical difficulty of factoring the product of two large prime numbers. It involves a public key, which can be shared with everyone, and a private key, which must be kept confidential.

## Formula
1. Choose two distinct primes $p$ and $q$.
2. Compute $n = pq$ and $\phi(n) = (p-1)(q-1)$.
3. Choose an integer $e$ such that $1 < e < \phi(n)$ and $	ext{gcd}(e, \phi(n)) = 1$.
4. Compute $d$ as the modular multiplicative inverse of $e$ modulo $\phi(n)$ ($de \equiv 1 \pmod{\phi(n)}$).
5. Public Key: $(e, n)$, Private Key: $(d, n)$.
6. Encryption: $c = m^e \pmod n$.
7. Decryption: $m = c^d \pmod n$.

## Code Explanation
The provided code demonstrates the entire RSA flow: generating keys from two primes, encrypting a message (integer), and decrypting it back. It uses modular exponentiation to handle large powers efficiently.
