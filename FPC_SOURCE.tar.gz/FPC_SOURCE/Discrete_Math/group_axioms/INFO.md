# Group Axioms

## Concept
A group $(G, \cdot)$ is a set $G$ together with a binary operation $\cdot$ that combines any two elements $a$ and $b$ to form another element $a \cdot b$. To be considered a group, the set and operation must satisfy four axioms: Closure, Associativity, Identity, and Inverse.

## Axioms
1.  **Closure**: For all $a, b \in G$, the result of $a \cdot b$ is also in $G$.
2.  **Associativity**: For all $a, b, c \in G$, $(a \cdot b) \cdot c = a \cdot (b \cdot c)$.
3.  **Identity Element**: There exists an element $e \in G$ such that for every $a \in G$, $e \cdot a = a \cdot e = a$.
4.  **Inverse Element**: For each $a \in G$, there exists an element $b \in G$ such that $a \cdot b = b \cdot a = e$.

## Code Explanation
The provided code verifies if a given set and a modular addition operation (e.g., $\mathbb{Z}_n$) satisfy the group axioms. It programmatically checks every element and pair to confirm closure, identity, and the existence of inverses.
