# Pigeonhole Principle Simulation

## Concept
The Pigeonhole Principle is a fundamental concept in combinatorics. It states that if you have more "pigeons" than "pigeonholes," and you put every pigeon into a hole, then at least one hole must contain more than one pigeon. This seemingly simple idea is used to prove many deep results in mathematics and computer science (e.g., hash collisions, lossy compression limits).

## Formula
If $n$ items are distributed into $m$ containers, and $n > m$, then at least one container contains $\lceil n/m ceil$ items or more.

## Code Explanation
The provided code simulates placing $N$ items into $M$ bins randomly. It tracks the distribution and identifies "collisions" where more than one item lands in the same bin, empirically demonstrating the principle.
