# Maximum Flow (Ford-Fulkerson Method)

## Concept
The Maximum Flow problem involves finding the greatest amount of flow that can be sent through a network from a source node to a sink node, given capacity constraints on the edges. The Ford-Fulkerson method is a greedy approach that repeatedly finds an "augmenting path" in the residual graph and increases the flow along that path.

## Algorithm
1. Initialize flow on all edges to 0.
2. While there exists a path from source $s$ to sink $t$ in the residual graph:
   a. Find the minimum capacity $c_{min}$ along the path (the "bottleneck").
   b. For each edge $(u, v)$ in the path:
      - Increase flow $f(u, v)$ by $c_{min}$.
      - Decrease residual capacity $r(u, v)$ by $c_{min}$.
      - Increase reverse residual capacity $r(v, u)$ by $c_{min}$.
3. The total max flow is the sum of flows leaving the source.

## Code Explanation
The provided code implements the Ford-Fulkerson method using Depth-First Search (DFS) to find augmenting paths. It uses an adjacency matrix to represent capacities and residual capacities.
