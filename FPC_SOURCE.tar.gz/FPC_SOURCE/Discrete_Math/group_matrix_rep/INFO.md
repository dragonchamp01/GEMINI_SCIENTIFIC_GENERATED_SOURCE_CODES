# Group Matrix Representation

## Concept
A group representation is a way of representing elements of an abstract group as linear transformations of a vector space. Specifically, it is a group homomorphism from a group $G$ to the general linear group $GL(n, V)$. This allows the use of linear algebra tools to study the abstract properties of the group.

## Formula
For a group $G$, a representation is a map $ho: G 	o GL(n, V)$ such that:
$ho(g_1 \cdot g_2) = ho(g_1) ho(g_2)$ for all $g_1, g_2 \in G$.
The dimension of the vector space $V$ is called the dimension of the representation.

## Code Explanation
The provided code implements the standard $2 	imes 2$ matrix representation of the cyclic group $C_3$. The elements are rotations by 0°, 120°, and 240° in the 2D plane. The code verifies that the group operation (addition modulo 3) corresponds to matrix multiplication.
