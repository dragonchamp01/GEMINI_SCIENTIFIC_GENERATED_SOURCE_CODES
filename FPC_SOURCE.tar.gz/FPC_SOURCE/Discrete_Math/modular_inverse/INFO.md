# Modular Inverse

## Concept
The modular multiplicative inverse of an integer $a$ modulo $m$ is an integer $x$ such that the product $ax$ is congruent to $1$ with respect to the modulus $m$. This is the equivalent of division in modular arithmetic. The inverse exists if and only if $a$ and $m$ are coprime ($	ext{gcd}(a, m) = 1$).

## Formula
The inverse can be found using the Extended Euclidean Algorithm, which finds integers $x$ and $y$ such that:
$ax + my = 	ext{gcd}(a, m)$
If $	ext{gcd}(a, m) = 1$, then $ax \equiv 1 \pmod m$, and $x$ is the modular inverse.

## Code Explanation
The provided code implements the Extended Euclidean Algorithm to calculate the modular inverse. It handles the case where the inverse does not exist and ensures the returned result is positive.
