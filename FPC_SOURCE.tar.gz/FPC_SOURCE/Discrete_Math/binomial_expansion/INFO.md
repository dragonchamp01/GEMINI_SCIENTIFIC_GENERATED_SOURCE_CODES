# Binomial Expansion

## Concept
The Binomial Theorem describes the algebraic expansion of powers of a binomial. It states that it is possible to expand the polynomial $(x + y)^n$ into a sum involving terms of the form $ax^b y^c$. The coefficients are the binomial coefficients $\binom{n}{k}$, which appear in Pascal's triangle.

## Formula
$(x + y)^n = \sum_{k=0}^{n} \binom{n}{k} x^{n-k} y^k$
where $\binom{n}{k} = \frac{n!}{k!(n-r)!}$.

## Code Explanation
The provided code expands the expression $(x + y)^n$ for a given $n$. It calculates the binomial coefficients and prints the resulting polynomial in a readable format. The implementation uses the previously defined combination logic to find the coefficients for each term.
