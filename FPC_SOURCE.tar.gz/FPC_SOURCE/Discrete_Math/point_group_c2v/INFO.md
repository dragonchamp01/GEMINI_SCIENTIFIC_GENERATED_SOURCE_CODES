# Point Group C2v

## Concept
The point group $C_{2v}$ is a symmetry group commonly encountered in chemistry and molecular physics (e.g., the water molecule $H_2O$). It contains four symmetry operations that leave the object's orientation in space unchanged. It is an Abelian group and is isomorphic to the Klein four-group ($V_4$).

## Elements
1.  **E**: Identity operation (do nothing).
2.  **C2**: Rotation by 180° around the principal axis (z-axis).
3.  **σv(xz)**: Reflection in the xz-plane (vertical mirror plane).
4.  **σv'(yz)**: Reflection in the yz-plane (vertical mirror plane).

## Properties
-   Each element is its own inverse ($X \cdot X = E$).
-   The product of any two non-identity elements is the third non-identity element (e.g., $C_2 \cdot \sigma_v = \sigma'_v$).
-   The group is Abelian ($A \cdot B = B \cdot A$).

## Code Explanation
The provided code represents the $C_{2v}$ group operations using a $2 	imes 2$ character array or a lookup-based composition function. It generates the Cayley table for the group and verifies the Abelian property and the self-inverse property of the elements.
