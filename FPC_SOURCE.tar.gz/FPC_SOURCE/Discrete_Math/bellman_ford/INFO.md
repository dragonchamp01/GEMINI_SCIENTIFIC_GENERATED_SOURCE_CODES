# Bellman-Ford Algorithm

## Concept
The Bellman-Ford algorithm is a graph search algorithm that finds the shortest paths from a single source vertex to all other vertices in a weighted directed graph. It is more versatile than Dijkstra's algorithm because it can handle graphs with negative edge weights. Additionally, it can detect the presence of negative weight cycles (cycles where the sum of edge weights is negative).

## Algorithm
1. Initialize distances from source to all vertices as infinity, and source to 0.
2. Relax all edges $(V-1)$ times:
   For each edge $(u, v)$ with weight $w$:
   If $dist[u] + w < dist[v]$, then $dist[v] = dist[u] + w$.
3. Check for negative cycles:
   For each edge $(u, v)$ with weight $w$:
   If $dist[u] + w < dist[v]$, then a negative cycle exists.

## Code Explanation
The provided code implements the Bellman-Ford algorithm. It processes an edge list and returns the shortest distances from a source node. It also includes a check to report if a negative cycle is detected in the graph.
