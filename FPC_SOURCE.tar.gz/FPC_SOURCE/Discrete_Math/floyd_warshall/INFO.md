# Floyd-Warshall Algorithm

## Concept
The Floyd-Warshall algorithm is an all-pairs shortest path algorithm. It calculates the shortest distances between every pair of vertices in a weighted directed graph. It is a classic example of dynamic programming and is capable of handling negative edge weights, provided there are no negative weight cycles.

## Formula
Let $dist[i][j]$ be the shortest distance from node $i$ to node $j$. The algorithm iteratively updates this distance by considering each node $k$ as an intermediate point:
$dist[i][j] = \min(dist[i][j], dist[i][k] + dist[k][j])$
This is performed for all $k \in \{1, \dots, V\}$.

## Code Explanation
The provided code implements the Floyd-Warshall algorithm using an adjacency matrix initialized with edge weights (and infinity where no edge exists). It uses triple-nested loops to update the distances and outputs the final distance matrix.
