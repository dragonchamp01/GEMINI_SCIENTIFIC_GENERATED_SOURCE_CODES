# Fast Fibonacci (Matrix Exponentiation)

## Concept
Calculating the $n$-th Fibonacci number can be done efficiently using matrix exponentiation. This method reduces the time complexity from linear $O(n)$ to logarithmic $O(\log n)$. This is achieved by expressing the Fibonacci recurrence relation as a matrix transformation.

## Formula
The Fibonacci recurrence $F_{n+1} = F_n + F_{n-1}$ can be written as:
$\begin{pmatrix} F_{n+1} \ F_n \end{pmatrix} = \begin{pmatrix} 1 & 1 \ 1 & 0 \end{pmatrix} \begin{pmatrix} F_n \ F_{n-1} \end{pmatrix}$
By repeating this process, we get:
$\begin{pmatrix} F_{n+1} \ F_n \end{pmatrix} = \begin{pmatrix} 1 & 1 \ 1 & 0 \end{pmatrix}^n \begin{pmatrix} F_1 \ F_0 \end{pmatrix}$
Using binary exponentiation (exponentiation by squaring), we can compute $M^n$ in $O(\log n)$ matrix multiplications.

## Code Explanation
The provided code implements matrix exponentiation to find the $n$-th Fibonacci number modulo $10^9+7$. It defines a $2 	imes 2$ matrix multiplication function and a power function using the squaring method.
