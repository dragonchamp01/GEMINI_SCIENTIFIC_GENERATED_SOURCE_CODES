# Graph Coloring (Greedy Algorithm)

## Concept
Graph coloring is a way of coloring the vertices of a graph such that no two adjacent vertices are assigned the same color. The smallest number of colors needed to color a graph $G$ is called its chromatic number, denoted $\chi(G)$. While finding the exact chromatic number is NP-hard, a greedy algorithm can provide a good approximation efficiently.

## Algorithm (Greedy)
1. Color the first vertex with the first color.
2. For each remaining vertex:
   a. Check the colors assigned to its already colored neighbors.
   b. Assign the smallest available color that has not been used by its neighbors.

## Code Explanation
The provided code implements the greedy coloring algorithm. It iterates through the vertices and assigns the first available color while avoiding conflicts with neighbors. The result is a color assignment for each node and an estimate of the number of colors required.
