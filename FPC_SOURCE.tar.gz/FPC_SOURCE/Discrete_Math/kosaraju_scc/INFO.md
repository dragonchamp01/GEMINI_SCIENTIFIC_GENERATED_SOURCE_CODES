# Kosaraju's SCC Algorithm

## Concept
Kosaraju's algorithm is a linear-time algorithm to find the strongly connected components of a directed graph. It relies on the fact that the SCCs of a graph are the same as the SCCs of its transpose (the graph with all edges reversed).

## Algorithm
1. Perform DFS on the original graph to find the "finish times" of each node. Push nodes onto a stack as they finish.
2. Compute the transpose of the graph (reverse all edges).
3. Pop nodes from the stack. For each node, if it has not been visited, perform DFS on the transposed graph to find all nodes reachable from it. These nodes form an SCC.

## Code Explanation
The provided code implements Kosaraju's algorithm in two DFS passes. The first pass determines the order of nodes based on finish times, and the second pass (on the reversed graph) extracts the SCCs.
