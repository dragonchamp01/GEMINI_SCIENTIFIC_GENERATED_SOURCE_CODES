# Tree Traversal

## Concept
Tree traversal refers to the process of visiting all nodes in a tree data structure in a specific order. For a binary tree, where each node has at most two children, the most common depth-first traversal methods are:
1.  **Pre-order**: Visit Root, then Left child, then Right child.
2.  **In-order**: Visit Left child, then Root, then Right child.
3.  **Post-order**: Visit Left child, then Right child, then Root.

## Properties
-   **In-order** traversal of a Binary Search Tree (BST) visits nodes in non-decreasing sorted order.
-   **Pre-order** is often used to create a copy of the tree or evaluate prefix expressions.
-   **Post-order** is used to delete nodes or evaluate postfix (Reverse Polish) expressions.

## Code Explanation
The provided code constructs a simple binary tree and implements the three recursive traversal methods. It outputs the sequence of node values for each method.
