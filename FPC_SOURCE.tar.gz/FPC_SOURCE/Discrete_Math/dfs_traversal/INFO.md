# Depth-First Search (DFS) Traversal

## Concept
Depth-First Search (DFS) is a graph traversal algorithm that explores as far as possible along each branch before backtracking. It is a powerful tool used for topological sorting, solving puzzles (like mazes), and identifying strongly connected components.

## Algorithm
1. Start at a source node and mark it as visited.
2. Recursively visit each unvisited neighbor.
3. Alternatively, use a stack:
   a. Push the starting node onto the stack.
   b. While the stack is not empty:
      - Pop a node $u$.
      - If $u$ is not visited, mark it as visited and push all its unvisited neighbors onto the stack.

## Code Explanation
The provided code implements DFS using recursion. It uses an adjacency list to represent the graph and a visited array to keep track of explored nodes. The output shows the order in which nodes are visited.
