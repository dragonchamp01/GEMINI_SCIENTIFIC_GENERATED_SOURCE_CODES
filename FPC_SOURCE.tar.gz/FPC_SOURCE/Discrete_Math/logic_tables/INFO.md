# Logic Tables (Truth Tables)

## Concept
A truth table is a mathematical table used in logic to compute the functional values of logical expressions on each of their functional arguments. In discrete mathematics, truth tables are fundamental for proving logical equivalences and analyzing digital circuits.

## Logical Operators
1.  **AND ($P \land Q$)**: True if both $P$ and $Q$ are true.
2.  **OR ($P \lor Q$)**: True if at least one of $P$ or $Q$ is true.
3.  **XOR ($P \oplus Q$)**: True if exactly one of $P$ or $Q$ is true.
4.  **IMPLIES ($P 	o Q$)**: False only if $P$ is true and $Q$ is false.
5.  **NOT ($
eg P$)**: Reverses the truth value.

## Code Explanation
The provided code generates a truth table for two variables $P$ and $Q$. It evaluates and displays the results for AND, OR, XOR, and IMPLIES. The implementation iterates through all four possible combinations of truth values (TT, TF, FT, FF).
