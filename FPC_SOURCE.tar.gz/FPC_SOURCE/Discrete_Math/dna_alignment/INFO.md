# DNA Sequence Alignment (Needleman-Wunsch)

## Concept
The Needleman-Wunsch algorithm performs a global alignment on two sequences (often DNA or proteins). It uses dynamic programming to find the alignment that maximizes a similarity score, considering matches, mismatches, and gaps. This is a fundamental tool in bioinformatics for comparing genetic sequences.

## Formula
Let $S(i, j)$ be the score for aligning the first $i$ characters of sequence $A$ and the first $j$ characters of sequence $B$.
$S(i, j) = \max \begin{cases} S(i-1, j-1) + 	ext{score}(A_i, B_j) & 	ext{(Match/Mismatch)} \ S(i-1, j) + 	ext{gap\_penalty} & 	ext{(Gap in B)} \ S(i, j-1) + 	ext{gap\_penalty} & 	ext{(Gap in A)} \end{cases}$

## Code Explanation
The provided code implements the Needleman-Wunsch algorithm. It builds a scoring matrix, fills it using the recurrence relation, and then performs a "traceback" to reconstruct the aligned sequences. It uses a simple scoring scheme: match=+1, mismatch=-1, gap=-1.
