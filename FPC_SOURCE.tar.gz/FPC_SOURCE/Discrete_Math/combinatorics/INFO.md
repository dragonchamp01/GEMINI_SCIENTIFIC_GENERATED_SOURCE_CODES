# Combinatorics (Permutations and Combinations)

## Concept
Combinatorics is a branch of mathematics concerning the study of finite or countable discrete structures. Key aspects include counting the number of ways to arrange or select items from a set.
1.  **Permutations**: The number of ways to arrange $r$ items from a set of $n$ unique items, where order matters.
2.  **Combinations**: The number of ways to select $r$ items from a set of $n$ unique items, where order does not matter.

## Formula
1.  **Factorial**: $n! = n 	imes (n-1) 	imes \dots 	imes 1$
2.  **Permutations ($P(n, r)$)**: $P(n, r) = \frac{n!}{(n-r)!}$
3.  **Combinations ($C(n, r)$)**: $C(n, r) = \binom{n}{r} = \frac{n!}{r!(n-r)!}$

## Code Explanation
The provided code implements functions to calculate factorials, permutations, and combinations. It uses large integer types where appropriate to prevent overflow and demonstrates the calculation for $n=10, r=3$.
- **Python** and **Julia** handle arbitrarily large integers.
- **C++** and **Free Pascal** use `double` or `uint64_t` but are limited by fixed bit widths.
