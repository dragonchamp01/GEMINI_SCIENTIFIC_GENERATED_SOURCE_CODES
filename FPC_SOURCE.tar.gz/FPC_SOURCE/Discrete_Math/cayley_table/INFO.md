# Cayley Table

## Concept
A Cayley table is a square grid used to describe the structure of a finite group. It lists all the elements of the group along the top and left sides, and the entry in each cell is the result of the binary operation applied to the corresponding row and column elements.

## Properties
-   Each row and each column of a Cayley table contains each element of the group exactly once (Latin square property).
-   If the group is Abelian, the table is symmetric about its main diagonal.
-   The row/column corresponding to the identity element simply reproduces the elements of the group.

## Code Explanation
The provided code generates the Cayley table for the group $(\mathbb{Z}_n, + \pmod n)$. It formats the output as a grid to clearly show the relationship between elements under the operation. The implementation can be adapted for any finite group and binary operation.
