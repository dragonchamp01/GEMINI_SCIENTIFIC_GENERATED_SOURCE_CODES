# Representation Direct Sum

## Concept
In representation theory, if we have two representations $ho_1: G 	o GL(V)$ and $ho_2: G 	o GL(W)$ of a group $G$, we can form their direct sum $ho_1 \oplus ho_2: G 	o GL(V \oplus W)$. The resulting representation acts on the direct sum of the vector spaces by combining the two matrices into a larger block-diagonal matrix.

## Formula
For a group element $g \in G$:
$ho_1 \oplus ho_2(g) = \begin{pmatrix} ho_1(g) & 0 \ 0 & ho_2(g) \end{pmatrix}$
The character of the direct sum is the sum of the individual characters:
$\chi_{ho_1 \oplus ho_2}(g) = \chi_{ho_1}(g) + \chi_{ho_2}(g)$

## Code Explanation
The provided code combines two $2 	imes 2$ rotation representations into a $4 	imes 4$ block-diagonal matrix. It verifies the character property by calculating the trace of the combined matrix and comparing it to the sum of the individual traces.
