# Cycle Detection in Directed Graphs

## Concept
A cycle in a directed graph occurs when a path exists that starts at a vertex and returns to the same vertex. Cycle detection is critical for algorithms that require Directed Acyclic Graphs (DAGs), such as topological sorting. In a Depth-First Search (DFS) traversal, a cycle is detected if we encounter a vertex that is currently in the recursion stack (an ancestor in the current DFS path).

## Algorithm (DFS-based)
1. Initialize `visited` and `recursion_stack` arrays to false.
2. For each unvisited vertex $u$:
   a. Mark $u$ as visited and push to `recursion_stack`.
   b. For each neighbor $v$ of $u$:
      - If $v$ is not visited, recursively call DFS for $v$. If it returns true, a cycle exists.
      - If $v$ is already in `recursion_stack`, a cycle exists (found a back-edge).
   c. Remove $u$ from `recursion_stack`.
3. If no cycle is found after visiting all nodes, the graph is acyclic.

## Code Explanation
The provided code implements the recursive DFS approach. it maintains a set or array for the recursion stack to efficiently identify back-edges. The implementation handles multiple components of a graph.
