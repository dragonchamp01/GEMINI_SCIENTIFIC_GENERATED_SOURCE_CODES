# Riemann Curvature Tensor

## Concept
The Riemann curvature tensor $R^ho_{\sigma\mu
u}$ is a fourth-rank tensor that encapsulates all the information about the curvature of a Riemannian manifold. If the Riemann tensor is zero everywhere, the space is "flat" (Euclidean or Minkowski). If it is non-zero, the space is curved, meaning parallel transport of a vector around a closed loop will result in a change in the vector's direction.

## Formula
The Riemann tensor is defined in terms of the Christoffel symbols $\Gamma^\alpha_{\mu
u}$:
$R^ho_{\sigma\mu
u} = \partial_\mu \Gamma^ho_{
u\sigma} - \partial_
u \Gamma^ho_{\mu\sigma} + \Gamma^ho_{\mu\lambda}\Gamma^\lambda_{
u\sigma} - \Gamma^ho_{
u\lambda}\Gamma^\lambda_{\mu\sigma}$
where $\partial_\mu$ denotes the partial derivative with respect to coordinate $x^\mu$.

## Code Explanation
The provided code calculates the Riemann tensor components for a 2D sphere of radius $R$. In spherical coordinates $(	heta, \phi)$, the metric is $ds^2 = R^2 d	heta^2 + R^2 \sin^2	heta d\phi^2$.
The code implements the calculation of Christoffel symbols and then the Riemann tensor components. For a sphere, we expect non-zero curvature.
