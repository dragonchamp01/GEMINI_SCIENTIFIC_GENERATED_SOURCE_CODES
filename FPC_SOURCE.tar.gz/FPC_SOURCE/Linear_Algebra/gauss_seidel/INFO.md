# Gauss-Seidel Method

## Concept
The Gauss-Seidel method is an iterative technique for solving a square system of $n$ linear equations $Ax = b$. It is an improvement upon the Jacobi method because it uses the newly computed values of the variables as soon as they are available, which typically leads to faster convergence.

## Formula
For a system $Ax = b$, the iterative formula for the components of $x$ is:
$x_i^{(k+1)} = \frac{1}{a_{ii}} \left( b_i - \sum_{j=1}^{i-1} a_{ij} x_j^{(k+1)} - \sum_{j=i+1}^{n} a_{ij} x_j^{(k)} ight)$
Note that the first summation uses the values from the *current* iteration $k+1$, while the second uses values from the *previous* iteration $k$.

## Code Explanation
The provided code solves a $3 	imes 3$ linear system. It iterates until the change in the solution vector is smaller than the convergence tolerance. The implementation demonstrates the "in-place" update nature of the Gauss-Seidel algorithm.
