# Singular Value Decomposition (Basic)

## Concept
Singular Value Decomposition (SVD) factors any $m 	imes n$ matrix $A$ into three matrices: $A = U \Sigma V^T$.
- $U$: $m 	imes m$ orthogonal matrix (left singular vectors).
- $\Sigma$: $m 	imes n$ diagonal matrix with non-negative real numbers (singular values).
- $V$: $n 	imes n$ orthogonal matrix (right singular vectors).
SVD is the foundation of data compression (PCA), noise reduction, and solving ill-conditioned systems.

## Formula
The singular values $\sigma_i$ are the square roots of the eigenvalues of $A^T A$. The columns of $V$ are the eigenvectors of $A^T A$. The columns of $U$ are the eigenvectors of $A A^T$ or can be found via $u_i = \frac{1}{\sigma_i} A v_i$.

## Code Explanation
The provided code demonstrates SVD for a $2 	imes 2$ matrix. It calculates the singular values by finding the eigenvalues of $A^T A$. In Python and Julia, library functions are used for verification, while the manual calculation path is shown for understanding.
