# SVD Power Method

## Concept
The SVD Power Method is an iterative algorithm used to find the dominant singular value $\sigma_1$ and the corresponding left and right singular vectors ($u_1$ and $v_1$) of a matrix $A$. It works by applying the standard Power Method to the symmetric matrix $A^T A$.

## Formula
1. Start with a random unit vector $v^{(0)}$.
2. Iterate: $w = A^T (A v^{(k)})$
3. Update $v^{(k+1)} = w / ||w||$
4. The dominant singular value is $\sigma_1 = ||A v^{(k+1)}||$
5. The dominant left singular vector is $u_1 = (A v^{(k+1)}) / \sigma_1$

## Code Explanation
The provided code calculates the first (largest) singular value and its vectors for a $3 	imes 2$ matrix. It demonstrates how to perform the matrix-vector multiplications and normalization steps to converge to the primary component of the SVD.
