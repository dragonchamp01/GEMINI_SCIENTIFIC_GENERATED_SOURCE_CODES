# Change of Basis

## Concept
A basis is a set of linearly independent vectors that span a vector space. In $\mathbb{R}^n$, the standard basis consists of the unit vectors along the axes. However, we can express vectors in any other valid basis. Change of basis is the mathematical process of switching from one coordinate system to another.

## Formula
If we have a vector $[v]_B$ in basis $B = \{b_1, \dots, b_n\}$, and we want to find its representation $[v]_C$ in basis $C = \{c_1, \dots, c_n\}$, we use a transition matrix $P_{C \leftarrow B}$:
$[v]_C = P_{C \leftarrow B} [v]_B$
The columns of $P_{C \leftarrow B}$ are the coordinates of the vectors in $B$ expressed in terms of basis $C$.

## Code Explanation
The provided code transforms a vector from the standard basis to a new basis $B = \{(1, 1), (1, -1)\}$. It calculates the transition matrix (which is the inverse of the matrix containing basis $B$ as columns) and multiplies it by the input vector to find its coordinates in the new basis.
