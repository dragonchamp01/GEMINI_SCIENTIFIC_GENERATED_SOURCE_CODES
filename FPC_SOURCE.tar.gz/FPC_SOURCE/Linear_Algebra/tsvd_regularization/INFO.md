# TSVD Regularization

## Concept
Truncated Singular Value Decomposition (TSVD) is a regularization method used to solve ill-posed linear systems $Ax = b$, where $A$ is nearly singular or has very small singular values. These small singular values make the standard solution $x = A^{-1}b$ highly sensitive to noise in $b$. TSVD provides a more stable solution by setting the smallest singular values to zero.

## Formula
If the SVD of $A$ is $U \Sigma V^T$, the standard solution is $x = \sum_{i=1}^{n} \frac{u_i^T b}{\sigma_i} v_i$.
The TSVD solution with truncation parameter $k$ is:
$x_k = \sum_{i=1}^{k} \frac{u_i^T b}{\sigma_i} v_i$
where $k < n$. This removes the terms with very small $\sigma_i$ that would otherwise dominate the sum and amplify noise.

## Code Explanation
The provided code solves a $3 	imes 3$ system with an ill-conditioned matrix. It computes the SVD, applies truncation to keep only the largest singular values, and computes the regularized solution. The implementation compares the TSVD solution with the (potentially unstable) full inverse solution.
