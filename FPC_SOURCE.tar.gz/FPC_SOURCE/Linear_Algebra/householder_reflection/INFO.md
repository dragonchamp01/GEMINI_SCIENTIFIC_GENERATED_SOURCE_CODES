# Householder Reflection

## Concept
A Householder reflection (or transformation) is a linear transformation that describes a reflection about a plane or hyperplane containing the origin. In numerical linear algebra, Householder reflections are used to zero out all but the first entry of a vector, which is the key step in computing the QR decomposition or reducing a matrix to Hessenberg/Tridiagonal form.

## Formula
For a vector $x$, we want to find an orthogonal matrix $H$ such that $Hx = [c, 0, \dots, 0]^T$. The matrix $H$ is defined as:
$H = I - 2vv^T$
where $v$ is a unit vector (Householder vector) found by:
$v = \frac{x - ||x||e_1}{||x - ||x||e_1||}$
where $e_1 = [1, 0, \dots, 0]^T$.

## Code Explanation
The provided code calculates the Householder vector $v$ and the corresponding reflection matrix $H$ for a given 3D vector. It demonstrates how applying $H$ to the original vector $x$ results in a vector where all elements after the first one are zero.
