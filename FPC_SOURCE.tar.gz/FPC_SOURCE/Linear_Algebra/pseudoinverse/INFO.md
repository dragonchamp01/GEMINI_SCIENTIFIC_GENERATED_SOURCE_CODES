# Moore-Penrose Pseudoinverse

## Concept
The Moore-Penrose pseudoinverse $A^+$ is a generalization of the matrix inverse for matrices that are not square or are singular. It is the standard way to find the "best fit" (least squares) solution to a system of linear equations $Ax = b$ when no exact solution exists or when there are infinitely many solutions.

## Formula
For a matrix $A$ with full column rank, the pseudoinverse is:
$A^+ = (A^T A)^{-1} A^T$
For a matrix $A$ with full row rank, it is:
$A^+ = A^T (A A^T)^{-1}$
More generally, it can be computed using SVD: If $A = U \Sigma V^T$, then $A^+ = V \Sigma^+ U^T$, where $\Sigma^+$ is formed by taking the reciprocal of each non-zero element on the diagonal.

## Code Explanation
The provided code calculates the pseudoinverse of a $3 	imes 2$ rectangular matrix using the formula $A^+ = (A^T A)^{-1} A^T$.
It computes the transpose, the product $A^T A$, inverts that product, and finally multiplies it by $A^T$.
The result is verified by solving a simple overdetermined system.
