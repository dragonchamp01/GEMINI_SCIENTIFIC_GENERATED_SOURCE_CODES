# Metric Tensor

## Concept
The metric tensor $g_{\mu
u}$ is a symmetric second-rank tensor that defines the geometric properties of a manifold. It allows for the calculation of distances, angles, and volumes in any coordinate system. In physics, it is the fundamental object used to describe the gravitational field in General Relativity.

## Formula
The squared infinitesimal distance (line element) $ds^2$ is given by:
$ds^2 = \sum_{\mu}\sum_{
u} g_{\mu
u} dx^\mu dx^
u$
For a flat Minkowski space in Cartesian coordinates, the metric is $\eta_{\mu
u} = 	ext{diag}(-1, 1, 1, 1)$. In polar coordinates $(r, 	heta)$, it is $g_{\mu
u} = \begin{pmatrix} 1 & 0 \ 0 & r^2 \end{pmatrix}$.

## Code Explanation
The provided code demonstrates how to calculate the line element $ds^2$ for a given displacement in polar coordinates. It defines the metric tensor as a matrix function of the coordinates and performs the double summation (tensor contraction) to find the interval.
