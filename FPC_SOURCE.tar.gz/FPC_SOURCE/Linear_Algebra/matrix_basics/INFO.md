# Matrix Basics

## Concept
Matrix algebra defines the operations that can be performed on matrices, which are rectangular arrays of numbers. These operations form the building blocks for linear transformations, data science, and scientific computing.

## Operations
1. **Addition/Subtraction**: Performed element-wise on matrices of the same dimensions.
2. **Scalar Multiplication**: Each element is multiplied by a scalar constant.
3. **Matrix Multiplication**: If $A$ is $m 	imes p$ and $B$ is $p 	imes n$, then $C = A \cdot B$ is $m 	imes n$, where $c_{ij} = \sum_{k=1}^p a_{ik} b_{kj}$.
4. **Transpose**: Flipping a matrix over its diagonal ($a_{ij}^T = a_{ji}$).
5. **Trace**: The sum of the diagonal elements of a square matrix.
6. **Determinant**: A scalar value that characterizes square matrices (e.g., non-zero means invertible).

## Code Explanation
The provided code demonstrates these basic operations. It includes functions for matrix addition, multiplication, and transposition. The implementation shows how to iterate through indices to perform these tasks manually for better understanding.
