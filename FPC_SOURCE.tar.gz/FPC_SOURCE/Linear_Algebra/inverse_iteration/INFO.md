# Inverse Iteration

## Concept
Inverse iteration is an iterative eigenvalue algorithm that allows finding the eigenvector corresponding to a specific eigenvalue of a square matrix. By choosing a "shift" $\mu$ close to a target eigenvalue, the method converges rapidly to that specific eigenvalue and its eigenvector.

## Formula
Starting with an initial vector $v_0$ and a shift $\mu$:
Solve the linear system for $w$:
$(A - \mu I) w = v_k$
Update the vector:
$v_{k+1} = w / ||w||$
The eigenvalue is then approximated using the Rayleigh Quotient or by observing the growth rate of $w$.

## Code Explanation
The provided code finds the smallest eigenvalue of a $3 	imes 3$ matrix by setting the shift $\mu = 0$. It uses a LU-decomposition or direct solver to solve the system $(A - \mu I) w = v_k$ in each iteration. The implementation demonstrates the rapid convergence to the eigenvector associated with the eigenvalue closest to the shift.
