# Matrix Exponential

## Concept
The matrix exponential $e^A$ is a square matrix defined by the Taylor series:
$e^A = \sum_{k=0}^{\infty} \frac{1}{k!} A^k = I + A + \frac{1}{2!} A^2 + \frac{1}{3!} A^3 + \dots$
It is fundamental in solving systems of linear differential equations of the form $\dot{x} = Ax$.

## Formula
For a diagonalizable matrix $A = PDP^{-1}$, the matrix exponential is simplified to:
$e^A = P e^D P^{-1}$
where $e^D$ is a diagonal matrix containing the exponentials of the eigenvalues.
Numerically, it can also be approximated using the Padé approximation or the Taylor series expansion.

## Code Explanation
The provided code approximates $e^A$ using the first 10 terms of the Taylor series expansion for a $2 	imes 2$ matrix. It includes a function for matrix powers and factorial calculation. The implementation allows observing how the result stabilizes as more terms are added to the series.
