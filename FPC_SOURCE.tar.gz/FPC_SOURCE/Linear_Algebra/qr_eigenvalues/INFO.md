# QR Eigenvalue Algorithm

## Concept
The QR algorithm is one of the most important methods in numerical linear algebra for finding all eigenvalues of a square matrix. It is based on the iterative QR decomposition of the matrix. Over several iterations, the matrix typically converges to an upper triangular form (Schur form), where the diagonal elements are the eigenvalues.

## Formula
Starting with $A_0 = A$:
1. Decompose $A_k = Q_k R_k$ using QR decomposition.
2. Form $A_{k+1} = R_k Q_k$.
$A_{k+1}$ is similar to $A_k$ ($A_{k+1} = Q_k^T A_k Q_k$) and thus shares the same eigenvalues. As $k 	o \infty$, the off-diagonal elements of $A_k$ below the main diagonal tend to zero.

## Code Explanation
The provided code implements the basic QR eigenvalue iteration. It performs a set number of iterations and then extracts the diagonal elements as the eigenvalues. The implementation demonstrates similarity transformations and the convergence towards a triangular form.
