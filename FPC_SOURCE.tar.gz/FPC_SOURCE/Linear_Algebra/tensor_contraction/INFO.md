# Tensor Contraction

## Concept
Tensor contraction is an operation that generalizes the concept of a matrix-vector product or matrix-matrix product to higher-dimensional arrays (tensors). It involves summing over repeated indices of two tensors to produce a new tensor of lower rank.

## Formula
If we have a tensor $A_{ijk}$ and a tensor $B_{kl}$, the contraction over index $k$ results in a new tensor $C_{ijl}$:
$C_{ijl} = \sum_{k} A_{ijk} B_{kl}$
This operation is fundamental in Einstein notation used in physics.

## Code Explanation
The provided code demonstrates the contraction of a 3rd-order tensor $A$ (shape $2 	imes 2 	imes 2$) and a 2nd-order tensor $B$ (shape $2 	imes 2$) over a shared index.
In Python and Julia, high-level functions like `tensordot` are used. In C++ and Free Pascal, the logic is implemented using nested loops to show the index-summation process.
