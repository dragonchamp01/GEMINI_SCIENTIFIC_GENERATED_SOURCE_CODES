# Sherman-Morrison Formula

## Concept
The Sherman-Morrison formula provides an efficient way to compute the inverse of a matrix after a rank-1 update. If the inverse of $A$ is known, and we update $A$ to $A + uv^T$ (where $u$ and $v$ are vectors), the inverse of the updated matrix can be calculated directly without recomputing the entire matrix inversion.

## Formula
$(A + uv^T)^{-1} = A^{-1} - \frac{A^{-1}uv^T A^{-1}}{1 + v^T A^{-1}u}$
This is valid as long as $1 + v^T A^{-1}u 
eq 0$.

## Code Explanation
The provided code starts with a matrix $A$ and its known inverse. It defines vectors $u$ and $v$ for a rank-1 update and applies the Sherman-Morrison formula to find the new inverse. The result is verified by comparing it with a direct matrix inversion of the updated matrix.
