# QR Decomposition (Gram-Schmidt Process)

## Concept
QR decomposition factors a matrix $A$ into an orthogonal matrix $Q$ ($Q^T Q = I$) and an upper triangular matrix $R$. The Modified Gram-Schmidt process is a numerically stable method to compute this decomposition by orthogonalizing the columns of $A$ one by one.

## Formula
For a matrix $A = [a_1, a_2, \dots, a_n]$, the process is:
1. $u_1 = a_1, e_1 = u_1 / ||u_1||$
2. $u_2 = a_2 - (a_2 \cdot e_1)e_1, e_2 = u_2 / ||u_2||$
3. $u_k = a_k - \sum_{j=1}^{k-1} (a_k \cdot e_j)e_j, e_k = u_k / ||u_k||$
The matrix $Q$ consists of columns $e_k$, and $R_{ij} = a_j \cdot e_i$.

## Code Explanation
The provided code implements the Modified Gram-Schmidt algorithm to decompose a $3 	imes 3$ matrix. It computes $Q$ and $R$ and then verifies that $Q \cdot R = A$ and $Q^T \cdot Q = I$.
