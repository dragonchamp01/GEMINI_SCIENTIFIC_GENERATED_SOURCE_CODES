# CKM Matrix (Cabibbo-Kobayashi-Maskawa)

## Concept
The CKM matrix is a $3 	imes 3$ unitary matrix used in the Standard Model of particle physics. It describes the strength of flavor-changing weak interactions between quarks (up, down, strange, charm, bottom, top). The matrix elements represent the probability of a quark of one flavor decaying into another flavor via the emission of a W boson.

## Formula
The matrix relates the weak interaction eigenstates $(d', s', b')$ to the mass eigenstates $(d, s, b)$:
$\begin{pmatrix} d' \ s' \ b' \end{pmatrix} = \begin{pmatrix} V_{ud} & V_{us} & V_{ub} \ V_{cd} & V_{cs} & V_{cb} \ V_{td} & V_{ts} & V_{tb} \end{pmatrix} \begin{pmatrix} d \ s \ b \end{pmatrix}$
Because it is a unitary matrix, it must satisfy $V V^\dagger = I$, which ensures the conservation of probability.

## Code Explanation
The provided code defines the CKM matrix using standard experimental values. It verifies the unitarity of the matrix by calculating $V V^\dagger$ and comparing it to the identity matrix. The implementation handles complex matrix multiplication.
