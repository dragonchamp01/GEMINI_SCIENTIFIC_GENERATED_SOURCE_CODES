# Condition Number of a Matrix

## Concept
The condition number of a matrix $A$ is a measure of how much the output value of the inverse function can change for a small change in the input. For a linear system $Ax = b$, a high condition number means that small errors in $b$ can lead to large errors in $x$. Such matrices are called "ill-conditioned."

## Formula
The condition number $\kappa(A)$ relative to a matrix norm $||\cdot||$ is defined as:
$\kappa(A) = ||A|| \cdot ||A^{-1}||$
If $A$ is singular, the condition number is infinite. Common norms used are the 1-norm (maximum column sum) or the $\infty$-norm (maximum row sum).

## Code Explanation
The provided code calculates the condition number of a $2 	imes 2$ matrix using the $\infty$-norm. It computes the matrix norm, finds the inverse of the matrix, computes the norm of the inverse, and finally multiplies them.
