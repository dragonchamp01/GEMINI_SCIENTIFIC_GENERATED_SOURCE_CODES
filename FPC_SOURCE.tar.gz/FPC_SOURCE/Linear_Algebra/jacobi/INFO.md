# Jacobi Method (Linear Systems)

## Concept
The Jacobi Method is an iterative algorithm used to solve a system of linear equations $Ax = b$, where $A$ is a strictly diagonally dominant matrix. It works by splitting the matrix $A$ into its diagonal part $D$ and the remainder $R = A - D$.

## Formula
The iterative update rule for the components of the solution vector $x$ is:
$x_i^{(k+1)} = \frac{1}{a_{ii}} \left( b_i - \sum_{j 
eq i} a_{ij} x_j^{(k)} ight)$
In each step, the new values are calculated using only the values from the previous iteration. This allows for parallel computation of the vector components.

## Code Explanation
The provided code solves a $3 	imes 3$ linear system. 
It verifies if the matrix is suitable for iteration and then applies the Jacobi update rule until the difference between consecutive solution vectors is within the tolerance.
The implementation shows the convergence of the solution vector towards the exact result.
