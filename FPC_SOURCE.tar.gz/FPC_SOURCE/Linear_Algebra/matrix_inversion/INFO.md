# Matrix Inversion (Gauss-Jordan Elimination)

## Concept
Matrix inversion is the process of finding a matrix $A^{-1}$ such that $A \cdot A^{-1} = I$, where $I$ is the identity matrix. Only non-singular (square matrices with non-zero determinants) can be inverted.

## Formula
The Gauss-Jordan elimination method transforms the augmented matrix $[A | I]$ into $[I | A^{-1}]$ using elementary row operations:
1. Swapping rows (pivoting) to avoid division by zero or small numbers.
2. Multiplying a row by a non-zero scalar.
3. Adding a multiple of one row to another.

## Code Explanation
The provided code implements Gauss-Jordan elimination with partial pivoting. 
It creates an identity matrix of the same size, augments the input matrix, and performs row operations to reduce the left side to the identity matrix.
The implementation handles the cases where the matrix might be singular.
