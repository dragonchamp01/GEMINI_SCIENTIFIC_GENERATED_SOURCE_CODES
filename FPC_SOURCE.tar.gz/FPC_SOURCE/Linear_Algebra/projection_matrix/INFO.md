# Projection Matrix

## Concept
A projection matrix $P$ is a square matrix that represents a linear transformation from a vector space to a subspace. If we project a vector onto a subspace, the resulting vector lies entirely within that subspace. If we apply the projection again, the vector does not change ($P^2 = P$), a property known as idempotency.

## Formula
For a subspace spanned by the columns of a matrix $A$ (where $A$ has full column rank), the orthogonal projection matrix onto that subspace is:
$P = A(A^T A)^{-1} A^T$
For any vector $v$, the projection $p = Pv$ is the vector in the subspace closest to $v$.

## Code Explanation
The provided code constructs a projection matrix onto the plane in $\mathbb{R}^3$ spanned by two vectors. It computes $P = A(A^T A)^{-1} A^T$ and verifies the property $P^2 = P$ by comparing the matrix with its square.
