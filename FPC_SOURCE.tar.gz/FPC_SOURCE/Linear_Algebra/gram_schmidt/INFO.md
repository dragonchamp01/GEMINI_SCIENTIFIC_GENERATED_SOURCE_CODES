# Gram-Schmidt Process

## Concept
The Gram-Schmidt process is a mathematical algorithm for orthonormalizing a set of vectors in an inner product space, most commonly the Euclidean space $\mathbb{R}^n$. Given a set of linearly independent vectors, the process produces an orthogonal or orthonormal set of vectors that span the same subspace.

## Formula
Given vectors $\{v_1, \dots, v_n\}$, the orthogonal vectors $\{u_1, \dots, u_n\}$ are found by:
1. $u_1 = v_1$
2. $u_2 = v_2 - 	ext{proj}_{u_1}(v_2)$
3. $u_k = v_k - \sum_{j=1}^{k-1} 	ext{proj}_{u_j}(v_k)$
where $	ext{proj}_u(v) = \frac{v \cdot u}{u \cdot u} u$. To make them orthonormal, divide each $u_i$ by its norm.

## Code Explanation
The provided code implements the **Modified Gram-Schmidt** process, which is more numerically stable than the classical version. It transforms three 3D vectors into an orthonormal basis and verifies the result by checking the dot products between the resulting vectors (which should be 0 or 1).
