# Eigenvalues (Power Method)

## Concept
The Power Method is an iterative algorithm used to find the dominant eigenvalue (the eigenvalue with the largest absolute magnitude) and its corresponding eigenvector of a square matrix. It is particularly useful for large sparse matrices where more complex algorithms like QR decomposition are computationally expensive.

## Formula
Starting with an initial vector $v_0$ (usually all ones), the iteration process is:
$v_{k+1} = \frac{A v_k}{||A v_k||}$
The eigenvalue $\lambda$ can be approximated using the Rayleigh Quotient:
$\lambda \approx \frac{v_k^T A v_k}{v_k^T v_k}$
As $k 	o \infty$, $v_k$ converges to the dominant eigenvector and $\lambda$ to the dominant eigenvalue.

## Code Explanation
The provided code finds the dominant eigenvalue of a $3 	imes 3$ matrix. 
It starts with an initial guess vector and repeatedly multiplies it by the matrix $A$, normalizing the result at each step to prevent numerical overflow.
The iteration stops when the change in the eigenvalue approximation is below a specified tolerance.
