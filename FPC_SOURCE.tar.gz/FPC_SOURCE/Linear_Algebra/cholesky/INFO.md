# Cholesky Decomposition

## Concept
Cholesky decomposition is a decomposition of a symmetric, positive-definite matrix $A$ into the product of a lower triangular matrix $L$ and its transpose $L^T$. This method is roughly twice as efficient as LU decomposition for solving systems of linear equations and is widely used in numerical optimization and Monte Carlo simulations.

## Formula
For a symmetric positive-definite matrix $A$, the components of the lower triangular matrix $L$ are:
$L_{jj} = \sqrt{a_{jj} - \sum_{k=1}^{j-1} L_{jk}^2}$
$L_{ij} = \frac{1}{L_{jj}} \left( a_{ij} - \sum_{k=1}^{j-1} L_{ik} L_{jk} ight)$ for $i > j$

## Code Explanation
The provided code implements the Cholesky algorithm. It computes the lower triangular matrix $L$ and then verifies the result by computing $L \cdot L^T$. The implementation handles error checking to ensure the matrix is positive-definite (i.e., the term under the square root must be positive).
