# Power Method with Deflation

## Concept
The standard Power Method only finds the dominant eigenvalue (the one with the largest absolute magnitude). To find subsequent eigenvalues, we use **Deflation**. Wielandt's deflation modifies the matrix $A$ into a new matrix $A'$ that shares all eigenvalues with $A$ except for the dominant one, which is replaced by zero.

## Formula
If $\lambda_1$ is the dominant eigenvalue and $v_1$ is the corresponding eigenvector (normalized such that $v_1^T v_1 = 1$), the deflated matrix is:
$A' = A - \lambda_1 v_1 v_1^T$
The dominant eigenvalue of $A'$ will then be the second largest eigenvalue of $A$.

## Code Explanation
The provided code finds the two largest eigenvalues of a $3 	imes 3$ matrix. 
1. It applies the Power Method to find $\lambda_1$ and $v_1$.
2. It constructs the deflated matrix $A'$.
3. It applies the Power Method again to $A'$ to find $\lambda_2$.
The implementation is provided across all four languages to demonstrate matrix manipulation and iterative convergence.
