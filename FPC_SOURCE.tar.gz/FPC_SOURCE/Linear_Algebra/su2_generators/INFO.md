# SU(2) Generators

## Concept
The generators of the $SU(2)$ group form a basis for its Lie algebra $su(2)$. These generators represent infinitesimal rotations in spin space. In physics, they are directly related to the spin operators $S_x, S_y, S_z$.

## Formula
The three generators $J_1, J_2, J_3$ are typically defined as:
$J_k = \frac{i}{2} \sigma_k$
where $\sigma_k$ are the Pauli matrices. They satisfy the commutation relations:
$[J_i, J_j] = \epsilon_{ijk} J_k$
where $\epsilon_{ijk}$ is the Levi-Civita symbol.

## Code Explanation
The provided code generates the three $2 	imes 2$ complex matrices $J_x, J_y, J_z$. It then verifies the commutation relation $[J_x, J_y] = J_z$ to demonstrate the algebraic structure of $su(2)$.
