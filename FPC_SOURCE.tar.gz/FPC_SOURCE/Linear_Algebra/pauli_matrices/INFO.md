# Pauli Matrices

## Concept
The Pauli matrices $\sigma_x, \sigma_y, \sigma_z$ are a set of three $2 	imes 2$ complex matrices which are Hermitian and unitary. They are the standard representation of the spin operator for spin-1/2 particles and form a basis for the vector space of $2 	imes 2$ Hermitian matrices.

## Formula
$\sigma_x = \begin{pmatrix} 0 & 1 \ 1 & 0 \end{pmatrix}, \quad \sigma_y = \begin{pmatrix} 0 & -i \ i & 0 \end{pmatrix}, \quad \sigma_z = \begin{pmatrix} 1 & 0 & 0 \ 0 & -1 \end{pmatrix}$
Properties:
1. $\sigma_i^2 = I$ (Idempotency)
2. $\sigma_i \sigma_j = i \epsilon_{ijk} \sigma_k$ (Multiplication rule)
3. $\{\sigma_i, \sigma_j\} = 2\delta_{ij} I$ (Anticommutation)

## Code Explanation
The provided code defines the three Pauli matrices and verifies their fundamental properties, such as being their own inverse ($\sigma_i^2 = I$) and their anticommutation relations.
