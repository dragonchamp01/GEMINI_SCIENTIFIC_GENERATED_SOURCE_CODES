# Quantum Fourier Transform (QFT) Matrix

## Concept
The Quantum Fourier Transform (QFT) is a linear transformation on quantum bits, and is the quantum analogue of the discrete Fourier transform. It is a unitary transformation used in many quantum algorithms, most notably Shor's factoring algorithm and the quantum phase estimation algorithm.

## Formula
The elements of an $N 	imes N$ QFT matrix $F_N$ are given by:
$F_{jk} = \frac{1}{\sqrt{N}} \omega^{jk}$
where $\omega = e^{2\pi i / N}$ is the $N$-th root of unity, and $j, k \in \{0, 1, \dots, N-1\}$.
The matrix is unitary, meaning $F_N^\dagger F_N = I$.

## Code Explanation
The provided code generates the $4 	imes 4$ QFT matrix ($N=4$ for 2 qubits). It calculates each complex entry using the root of unity formula and verifies that the resulting matrix is unitary by computing $F F^\dagger$ and checking if it equals the identity matrix.
