# SU(2) to SO(3) Mapping

## Concept
The group $SU(2)$ (Special Unitary group of degree 2) is the "double cover" of $SO(3)$ (Special Orthogonal group of degree 3). This means that every $3 	imes 3$ rotation matrix in $SO(3)$ corresponds to two $2 	imes 2$ matrices in $SU(2)$ ($U$ and $-U$). This mapping is essential in quantum mechanics for describing how spin states transform under rotations.

## Formula
An $SU(2)$ matrix $U$ representing a rotation by angle $	heta$ around axis $\hat{n} = (n_x, n_y, n_z)$ is:
$U = \cos(	heta/2)I - i\sin(	heta/2)(\vec{n} \cdot \vec{\sigma})$
The corresponding $SO(3)$ matrix elements are given by:
$R_{ij} = \frac{1}{2} 	ext{Tr}(\sigma_i U \sigma_j U^\dagger)$
where $\sigma_i$ are the Pauli matrices.

## Code Explanation
The provided code takes an axis and an angle, constructs the $2 	imes 2$ $SU(2)$ matrix, and then calculates the corresponding $3 	imes 3$ $SO(3)$ rotation matrix. It demonstrates the transformation from the complex spinor representation to the real vector rotation representation.
