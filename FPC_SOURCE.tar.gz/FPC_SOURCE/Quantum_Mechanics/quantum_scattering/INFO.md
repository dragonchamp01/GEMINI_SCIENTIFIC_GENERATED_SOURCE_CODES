# Quantum Scattering (Born Approximation)

## Concept
Scattering theory studies how particles deflect when they interact with a potential $V(r)$. In the first Born approximation, we assume the incident wave is only slightly perturbed by the potential. This allows us to calculate the scattering amplitude $f(	heta)$, which relates to the probability of a particle being deflected by an angle $	heta$.

## Formula
For a spherically symmetric potential $V(r)$, the scattering amplitude in the first Born approximation is:
$f(	heta) = -\frac{2m}{\hbar^2 q} \int_{0}^{\infty} r V(r) \sin(qr) dr$
where $q = 2k \sin(	heta/2)$ is the momentum transfer and $k = \sqrt{2mE}/\hbar$.
For a Yukawa potential $V(r) = \frac{V_0 e^{-\alpha r}}{r}$, the result is:
$f(	heta) = -\frac{2mV_0}{\hbar^2 (\alpha^2 + q^2)}$

## Code Explanation
The provided code calculates the scattering amplitude for a Yukawa potential as a function of the scattering angle $	heta$. It demonstrates how the amplitude decreases as the scattering angle increases, a characteristic of particle collisions.
