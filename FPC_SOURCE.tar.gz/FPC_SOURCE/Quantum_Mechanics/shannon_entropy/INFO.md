# Shannon Entropy

## Concept
Shannon entropy, introduced by Claude Shannon in 1948, is a fundamental measure in information theory. It quantifies the amount of uncertainty or information contained in a probability distribution. In the context of quantum mechanics, it can be used to describe the uncertainty associated with the outcome of a measurement on a quantum state.

## Formula
For a discrete random variable $X$ with possible outcomes $x_1, \dots, x_n$ and probability mass function $P(X)$, the Shannon entropy $H(X)$ is:
$H(X) = -\sum_{i=1}^{n} P(x_i) \log_b P(x_i)$
Typically, the base $b=2$ is used, and the entropy is measured in bits. If $P(x_i) = 0$, the term $0 \log 0$ is defined as 0.

## Code Explanation
The provided code calculates the Shannon entropy for a given list of probabilities. it ensures the probabilities are normalized and handles the $0 \log 0$ case correctly. It compares the entropy of a certain outcome (low entropy) with a uniform distribution (maximum entropy).
