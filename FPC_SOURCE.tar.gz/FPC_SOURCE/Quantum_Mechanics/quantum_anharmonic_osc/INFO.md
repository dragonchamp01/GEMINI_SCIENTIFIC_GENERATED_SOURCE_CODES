# Quantum Anharmonic Oscillator (Perturbation)

## Concept
The quantum anharmonic oscillator is an extension of the harmonic oscillator where the potential includes higher-order terms, such as a quartic term $\lambda x^4$. Most physical systems are not perfectly harmonic; anharmonicity accounts for phenomena like thermal expansion and the dissociation of molecules. Since exact analytical solutions for the anharmonic oscillator are generally unavailable, we use perturbation theory to find approximate energy levels.

## Formula
For a Hamiltonian $H = H_{HO} + \lambda x^4$, the first-order correction to the $n$-th energy level is:
$\Delta E_n^{(1)} = \langle n | \lambda x^4 | n angle$
Using the ladder operators ($a, a^\dagger$), the result for the ground state ($n=0$) is:
$\Delta E_0^{(1)} = \frac{3 \lambda \hbar^2}{4 m^2 \omega^2}$
In dimensionless units ($m = \omega = \hbar = 1$):
$\Delta E_n^{(1)} = \frac{3 \lambda}{4} (2n^2 + 2n + 1)$

## Code Explanation
The provided code calculates the energy levels of an anharmonic oscillator using first-order perturbation theory. It displays the base harmonic energy and the shifted energy for a given perturbation strength $\lambda$.
