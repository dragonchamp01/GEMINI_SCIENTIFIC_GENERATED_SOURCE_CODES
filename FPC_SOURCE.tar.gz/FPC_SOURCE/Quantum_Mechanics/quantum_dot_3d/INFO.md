# Quantum Dot (3D Infinite Well)

## Concept
A quantum dot is a nanocrystal made of semiconductor materials that are small enough to exhibit quantum mechanical properties. Specifically, its excitons are confined in all three spatial dimensions. This leads to a discrete energy spectrum, earning them the nickname "artificial atoms." The simplest model for a quantum dot is a 3D infinite potential well (a cubic or rectangular box).

## Formula
For a cubic dot of side length $L$, the energy levels are:
$E_{n_x, n_y, n_z} = \frac{\pi^2 \hbar^2}{2m L^2} (n_x^2 + n_y^2 + n_z^2)$
where $n_x, n_y, n_z = 1, 2, 3, \dots$ are the quantum numbers.

## Code Explanation
The provided code calculates the lowest energy levels for a cubic quantum dot. It generates all combinations of $(n_x, n_y, n_z)$, calculates the energy, and displays the unique energy levels along with their degeneracy (the number of different states having the same energy).
