# Quantum Partition Function

## Concept
In quantum statistical mechanics, the partition function $Z$ is a sum over all possible quantum states of a system, weighted by the Boltzmann factor $e^{-\beta E_n}$, where $\beta = 1/k_BT$. It is used to calculate thermodynamic quantities such as internal energy, entropy, and free energy.

## Formula
For a system with energy levels $E_n$:
$Z(\beta) = \sum_{n} g_n e^{-\beta E_n}$
where $g_n$ is the degeneracy of the $n$-th energy level.
For a Quantum Harmonic Oscillator:
$Z = \sum_{n=0}^{\infty} e^{-\beta \hbar \omega (n + 1/2)} = \frac{e^{-\beta \hbar \omega / 2}}{1 - e^{-\beta \hbar \omega}}$

## Code Explanation
The provided code calculates the partition function for a discrete set of energy levels at a given temperature. It demonstrates the calculation for a QHO by summing the first $N$ terms and compares it with the analytical closed-form solution.
