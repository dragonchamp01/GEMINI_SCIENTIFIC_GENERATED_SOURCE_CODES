# Zeeman Effect

## Concept
The Zeeman effect is the splitting of atomic energy levels in the presence of an external magnetic field. This occurs because the magnetic moment of the atom interacts with the field, causing the degeneracy of the magnetic quantum states to be lifted. It is classified into the normal Zeeman effect (ignoring spin) and the anomalous Zeeman effect (including spin).

## Formula
The energy shift $\Delta E$ for a state with total angular momentum $J$ and magnetic quantum number $m_j$ is:
$\Delta E = g_j \mu_B B m_j$
where:
- $g_j$ is the Landé g-factor: $g_j = 1 + \frac{j(j+1) + s(s+1) - l(l+1)}{2j(j+1)}$
- $\mu_B$ is the Bohr magneton.
- $B$ is the magnetic field strength.
- $m_j \in \{-j, -j+1, \dots, j\}$.

## Code Explanation
The provided code calculates the energy shifts for the $^2P_{3/2}$ state of an atom in a 1 Tesla magnetic field. It computes the Landé g-factor and lists the shifts for all possible $m_j$ values.
