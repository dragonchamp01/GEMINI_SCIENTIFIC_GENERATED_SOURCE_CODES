# Quantum Relative Entropy

## Concept
Quantum relative entropy is a measure of the "distance" or distinguishability between two quantum states, represented by density matrices $ho$ and $\sigma$. It is the quantum analogue of the Kullback-Leibler divergence from classical information theory. While not a true metric (it is not symmetric and does not satisfy the triangle inequality), it is always non-negative (Klein's inequality) and zero if and only if $ho = \sigma$.

## Formula
The relative entropy $S(ho || \sigma)$ is defined as:
$S(ho || \sigma) = 	ext{Tr}(ho \ln ho) - 	ext{Tr}(ho \ln \sigma)$
where $\ln$ is the matrix logarithm. For the value to be finite, the support of $ho$ must be contained in the support of $\sigma$.

## Code Explanation
The provided code calculates the quantum relative entropy between two $2 	imes 2$ density matrices. It uses matrix diagonalization to compute the matrix logarithms and then performs the trace operation. It compares a state with itself (result 0) and with a different state.
