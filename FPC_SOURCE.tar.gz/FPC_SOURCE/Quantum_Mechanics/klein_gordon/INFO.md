# Klein-Gordon Equation

## Concept
The Klein-Gordon equation is a relativistic wave equation, which is a quantized version of the relativistic energy-momentum relation. It describes relativistic particles with spin 0 (scalar particles), such as the Higgs boson. Unlike the Schrödinger equation, it is second-order in time and can result in negative probability densities, which led to its interpretation as a field equation for particles and antiparticles.

## Formula
In natural units ($c = \hbar = 1$):
$\left( \square + m^2 ight) \phi = 0$
or, in 1D space:
$\frac{\partial^2 \phi}{\partial t^2} - \frac{\partial^2 \phi}{\partial x^2} + m^2 \phi = 0$
Solutions are plane waves: $\phi(x, t) = e^{i(kx - \omega t)}$, where $\omega = \sqrt{k^2 + m^2}$.

## Code Explanation
The provided code simulates the evolution of a 1D scalar field using the finite difference method. It demonstrates how a wave packet propagates and disperses according to the Klein-Gordon relation.
