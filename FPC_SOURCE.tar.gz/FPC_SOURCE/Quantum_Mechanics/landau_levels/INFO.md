# Landau Levels

## Concept
Landau levels are the discrete energy levels that a charged particle (typically an electron) can occupy when moving in a uniform magnetic field. This is a quantum mechanical phenomenon where the continuous energy spectrum of a free particle in 2D becomes quantized into discrete levels due to the Lorentz force, similar to a harmonic oscillator.

## Formula
For a particle with charge $q$ and mass $m$ in a magnetic field $B$, the energy levels are:
$E_n = \hbar \omega_c \left( n + \frac{1}{2} ight), \quad n = 0, 1, 2, \dots$
where $\omega_c = \frac{qB}{m}$ is the cyclotron frequency. Each level is highly degenerate, with the number of states per unit area proportional to the magnetic flux density.

## Code Explanation
The provided code calculates the first 5 Landau levels for an electron in a magnetic field of 1 Tesla. It calculates the cyclotron frequency and the corresponding energy in milli-electron volts (meV).
