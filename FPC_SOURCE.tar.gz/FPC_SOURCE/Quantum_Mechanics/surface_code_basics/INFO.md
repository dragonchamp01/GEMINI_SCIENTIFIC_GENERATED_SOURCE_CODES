# Surface Code Basics

## Concept
The surface code is a type of topological quantum error-correcting code. Qubits are arranged on a 2D grid, and errors are detected by measuring "stabilizers" (local parity checks). There are two types of stabilizers:
1.  **Plaquette ($Z$) operators**: Detect $X$ (bit-flip) errors.
2.  **Star ($X$) operators**: Detect $Z$ (phase-flip) errors.
Logical operators in the surface code correspond to strings of physical operators that wrap around the lattice or connect different boundaries.

## Error Detection
When a physical qubit has an error, the eigenvalues of the neighboring stabilizers change from $+1$ to $-1$. This $-1$ result is called a "syndrome" or "defect." By matching pairs of defects (typically using a minimum-weight perfect matching algorithm), we can deduce the most likely error and apply a correction.

## Code Explanation
The provided code demonstrates the syndrome detection logic for a $2 	imes 2$ grid of stabilizers. It takes a "grid" of physical qubits, introduces an $X$ error, and identifies which $Z$-plaquettes will report a syndrome change.
