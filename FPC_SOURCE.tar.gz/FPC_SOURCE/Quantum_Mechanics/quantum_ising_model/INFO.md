# Quantum Ising Model (Transverse Field)

## Concept
The Transverse Field Ising Model (TFIM) is a quantum version of the classical Ising model. It describes a system of spins on a lattice that interact with their neighbors and are subject to an external magnetic field applied perpendicular to the axis of spin interaction. It is a paradigm for quantum phase transitions, exhibiting a transition between a ferromagnetic phase and a paramagnetic phase as the field strength changes.

## Formula
The Hamiltonian for $N$ spins is:
$H = -J \sum_{i=1}^{N-1} \sigma_z^i \sigma_z^{i+1} - h \sum_{i=1}^N \sigma_x^i$
where:
- $J$ is the exchange interaction strength.
- $h$ is the transverse field strength.
- $\sigma_z^i$ and $\sigma_x^i$ are Pauli operators acting on the $i$-th spin.

## Code Explanation
The provided code constructs the $4 	imes 4$ Hamiltonian matrix for a 2-spin system using Kronecker products of Pauli matrices. It calculates the ground state energy and the first excited state energy for varying transverse field strengths, demonstrating the competition between interaction and field.
