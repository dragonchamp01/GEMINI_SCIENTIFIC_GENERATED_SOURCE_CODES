# Radial Schrodinger Equation

## Concept
For a particle in a central potential $V(r)$, such as the electron in a hydrogen atom, the Schrodinger equation can be separated into angular and radial parts. The radial part $R(r)$ describes the radial distribution of the electron and depends on the principal quantum number $n$ and the angular momentum quantum number $l$.

## Formula
The radial equation for $u(r) = r R(r)$ is:
$-\frac{\hbar^2}{2m} \frac{d^2u}{dr^2} + \left[ V(r) + \frac{l(l+1)\hbar^2}{2mr^2} ight] u(r) = E u(r)$
For the Hydrogen atom, $V(r) = -\frac{Ze^2}{4\pi\epsilon_0 r}$. The solutions are related to associated Laguerre polynomials.

## Code Explanation
The provided code evaluates the ground state ($n=1, l=0$) radial wavefunction for the Hydrogen atom.
$R_{10}(r) = 2 a_0^{-3/2} e^{-r/a_0}$
It calculates the radial probability density $P(r) = r^2 |R(r)|^2$ and identifies the radius of maximum probability (the Bohr radius $a_0$).
