# Born-Oppenheimer Approximation

## Concept
The Born-Oppenheimer (BO) approximation is a fundamental tool in molecular physics and quantum chemistry. It assumes that the motion of atomic nuclei and electrons in a molecule can be separated due to the vast difference in their masses. Because nuclei are thousands of times heavier than electrons, they move much more slowly. This allows us to solve the electronic Schrödinger equation for fixed nuclear positions, resulting in a Potential Energy Surface (PES).

## Formula
The molecular Hamiltonian is split: $H = T_{nuc} + H_{elec}(R)$, where $R$ represents the fixed nuclear coordinates.
The electronic energy $E_e(R)$ is found by solving:
$H_{elec}(R) \psi_e(r; R) = E_e(R) \psi_e(r; R)$
The total effective potential for nuclear motion is then $V_{eff}(R) = E_e(R) + V_{nuc-nuc}(R)$.

## Code Explanation
The provided code simulates the Potential Energy Surface for a simple diatomic system. It calculates the electronic energy (modeled as a Morse potential or similar approximation) plus the nuclear repulsion energy as a function of the distance $R$ between the two nuclei. It identifies the equilibrium bond length where the total energy is minimized.
