# Partial Trace

## Concept
The partial trace is a linear mapping from the density matrix of a composite system to the density matrix of one of its subsystems. If we have a system $AB$ in a state $ho_{AB}$, the state of subsystem $A$ is given by the reduced density matrix $ho_A = 	ext{Tr}_B(ho_{AB})$. This operation effectively "ignores" or averages out the degrees of freedom of subsystem $B$.

## Formula
$ho_A = \sum_{j} \langle j_B | ho_{AB} | j_B angle$
where $\{|j_Bangle\}$ is an orthonormal basis for subsystem $B$.
For a 2-qubit system $ho$ (a $4 	imes 4$ matrix):
$ho_A = \begin{pmatrix} ho_{00,00} + ho_{01,01} & ho_{00,10} + ho_{01,11} \ ho_{10,00} + ho_{11,01} & ho_{10,10} + ho_{11,11} \end{pmatrix}$

## Code Explanation
The provided code implements the partial trace for a 2-qubit system to extract the $2 	imes 2$ reduced density matrix of the first qubit. It demonstrates that the reduced density matrix of an entangled Bell state is a maximally mixed state ($I/2$).
