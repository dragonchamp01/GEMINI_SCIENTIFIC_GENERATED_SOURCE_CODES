# Quantum Hall Effect (Integer)

## Concept
The Quantum Hall Effect (QHE) is a quantum-mechanical version of the Hall effect, observed in two-dimensional electron systems (like those in semiconductors) at very low temperatures and high magnetic fields. The Hall conductance $\sigma_{xy}$ is found to take on discrete, quantized values that are integer multiples of the fundamental constant $e^2/h$.

## Formula
The Hall conductance is:
$\sigma_{xy} = 
u \frac{e^2}{h}$
where $
u$ is an integer (the filling factor).
The Hall resistance is:
$R_H = \frac{1}{\sigma_{xy}} = \frac{h}{
u e^2}$
The constant $R_K = h/e^2 \approx 25812.807 \Omega$ is known as the von Klitzing constant.

## Code Explanation
The provided code calculates the Hall resistance for the first 5 integer filling factors. It uses the known physical constants to provide the resistance in Ohms ($\Omega$).
