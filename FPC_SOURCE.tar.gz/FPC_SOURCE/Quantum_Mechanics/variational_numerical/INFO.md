# Variational Numerical Method

## Concept
The Variational Method is used to approximate the lowest energy eigenvalue (ground state) of a quantum system when the Schrodinger equation cannot be solved analytically. It is based on the principle that for any normalized trial wavefunction $\psi_{trial}$, the expected value of the Hamiltonian $H$ is an upper bound to the true ground state energy $E_0$:
$E_0 \le \frac{\langle \psi_{trial} | H | \psi_{trial} angle}{\langle \psi_{trial} | \psi_{trial} angle}$

## Algorithm
1.  Choose a trial wavefunction $\psi(x, \alpha)$ with one or more adjustable parameters $\alpha$.
2.  Calculate the expectation value of the energy $E(\alpha) = \langle H angle$.
3.  Minimize $E(\alpha)$ with respect to $\alpha$. The minimum value is the approximation of the ground state energy.

## Code Explanation
The provided code applies the variational method to a quartic potential $V(x) = x^4$. It uses a Gaussian trial function $\psi(x, \alpha) = e^{-\alpha x^2}$ and finds the value of $\alpha$ that minimizes the total energy (Kinetic + Potential). The kinetic energy is calculated using numerical second derivatives.
