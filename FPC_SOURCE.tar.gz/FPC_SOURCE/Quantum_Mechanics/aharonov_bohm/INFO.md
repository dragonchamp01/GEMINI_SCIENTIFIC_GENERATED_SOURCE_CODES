# Aharonov-Bohm Effect

## Concept
The Aharonov-Bohm (AB) effect is a quantum mechanical phenomenon that demonstrates the physical significance of electromagnetic potentials ($\Phi$ and $\vec{A}$), rather than just the fields ($\vec{E}$ and $\vec{B}$). A charged particle moving around a region containing a magnetic flux $\Phi$ experiences a phase shift in its wavefunction, even if the magnetic field is zero along the particle's path.

## Formula
The phase shift $\Delta \phi$ acquired by a particle of charge $q$ moving along a path $C$ is:
$\Delta \phi = \frac{q}{\hbar} \oint_{C} \vec{A} \cdot d\vec{l} = \frac{q\Phi_B}{\hbar}$
where $\Phi_B$ is the magnetic flux enclosed by the path. This phase shift causes a shift in the interference pattern in double-slit experiments.

## Code Explanation
The provided code calculates the phase shift for an electron (charge $e$) circling a solenoid with a given magnetic flux. It displays the phase shift in radians and as a fraction of $2\pi$.
