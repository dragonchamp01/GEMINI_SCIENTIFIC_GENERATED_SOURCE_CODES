# Heisenberg Matrix Mechanics

## Concept
Matrix mechanics was the first complete and logically consistent formulation of quantum mechanics. It describes physical quantities (position, momentum, energy) as matrices that change with time. A key feature is the non-commutativity of these matrices, which leads directly to the Heisenberg uncertainty principle. The dynamic evolution of an operator $A$ is given by the Heisenberg equation of motion.

## Formula
1.  **Canonical Commutation Relation**: $[x, p] = xp - px = i\hbar I$, where $I$ is the identity matrix.
2.  **Heisenberg Equation**: $\frac{dA}{dt} = \frac{i}{\hbar} [H, A] + \frac{\partial A}{\partial t}$.
3.  **Expectation Value**: $\langle A angle = \psi^\dagger A \psi$.

## Code Explanation
The provided code demonstrates the non-commutative nature of position ($X$) and momentum ($P$) operators by representing them as matrices in a finite-dimensional Hilbert space (using the harmonic oscillator basis). It calculates the commutator $[X, P]$ and verifies that it is proportional to the identity matrix multiplied by $i$.
