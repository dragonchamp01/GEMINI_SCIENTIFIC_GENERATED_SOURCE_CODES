# Quantum Measurements

## Concept
In quantum mechanics, a measurement is an action that forces a system in a superposition of states to "collapse" into one of the eigenstates of the observable (Hermitian operator) being measured. The probability of obtaining a specific result is given by the Born rule. Unlike classical measurements, quantum measurements are inherently probabilistic and generally disturb the system.

## Formula
1.  **Observable**: Represented by a Hermitian operator $M$.
2.  **Eigenvalues**: Possible measurement results $\{m_i\}$.
3.  **Born Rule**: The probability of measuring outcome $m_i$ for state $|\psiangle$ is $P(m_i) = \langle \psi | P_i | \psi angle$, where $P_i = |m_iangle\langle m_i|$ is the projector onto the eigenstate.
4.  **Expectation Value**: The average result of many measurements: $\langle M angle = \langle \psi | M | \psi angle$.

## Code Explanation
The provided code simulates measuring a qubit in the Z-basis ($|0angle, |1angle$). It calculates the probabilities for each outcome given a superposition state and computes the expectation value $\langle Z angle$.
