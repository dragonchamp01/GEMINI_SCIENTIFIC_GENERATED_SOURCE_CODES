# Bell States (Quantum Entanglement)

## Concept
Bell states are four specific maximally entangled quantum states of two qubits. When two qubits are in a Bell state, the state of one qubit is perfectly correlated with the state of the other, regardless of the distance between them. This phenomenon, which Einstein called "spooky action at a distance," is a cornerstone of quantum information theory.

## The Four States
1.  $|\Phi^+angle = \frac{1}{\sqrt{2}} (|00angle + |11angle)$
2.  $|\Phi^-angle = \frac{1}{\sqrt{2}} (|00angle - |11angle)$
3.  $|\Psi^+angle = \frac{1}{\sqrt{2}} (|01angle + |10angle)$
4.  $|\Psi^-angle = \frac{1}{\sqrt{2}} (|01angle - |10angle)$

## Code Explanation
The provided code represents the $|\Phi^+angle$ Bell state as a 4-dimensional complex vector in the computational basis ($|00angle, |01angle, |10angle, |11angle$). It calculates the probabilities of measuring each of the four possible outcomes and demonstrates that for $|\Phi^+angle$, you only ever measure $|00angle$ or $|11angle$, each with 50% probability.
