# Quantum Teleportation

## Concept
Quantum teleportation is a process by which a quantum state (the information in a qubit) can be transmitted from one location to another, with the help of classical communication and a previously shared entangled Bell state between the sending and receiving locations. It does not transport the particle itself, but rather its state.

## Protocol Steps
1.  **Entanglement**: A Bell pair $(|\Phi^+angle)$ is shared between Alice and Bob.
2.  **Bell Measurement**: Alice performs a Bell-state measurement on her qubit and the qubit to be teleported.
3.  **Classical Communication**: Alice sends 2 bits of classical information to Bob.
4.  **Correction**: Bob applies a specific unitary transformation ($I, X, Z,$ or $XZ$) based on Alice's bits to recover the original state.

## Code Explanation
The provided code simulates the mathematical transformation of the state vectors during the teleportation process. It demonstrates how the state of the target qubit becomes identical to the source qubit after the appropriate Pauli operations are applied.
