# Transfer Matrix Method

## Concept
The transfer matrix method is a powerful tool for solving one-dimensional Schrödinger equation problems, particularly for multi-layered structures or periodic potentials. It relates the amplitudes of the forward and backward moving waves at one point to those at another point. By multiplying the matrices of individual regions, one can find the total transmission and reflection coefficients of complex potential profiles.

## Formula
For a potential barrier of height $V$ and width $L$, the transfer matrix $M$ relates the coefficients:
$\begin{pmatrix} A_{in} \ B_{in} \end{pmatrix} = M \begin{pmatrix} A_{out} \ B_{out} \end{pmatrix}$
The transmission coefficient $T$ is given by $T = \frac{1}{|M_{11}|^2}$.
For a barrier where $E < V$:
$M = \begin{pmatrix} \cosh(\kappa L) + i\frac{\epsilon}{2}\sinh(\kappa L) & i\frac{\eta}{2}\sinh(\kappa L) \ -i\frac{\eta}{2}\sinh(\kappa L) & \cosh(\kappa L) - i\frac{\epsilon}{2}\sinh(\kappa L) \end{pmatrix}$
where $\kappa = \sqrt{2m(V-E)}/\hbar$, $\epsilon = \frac{\kappa}{k} - \frac{k}{\kappa}$, and $\eta = \frac{\kappa}{k} + \frac{k}{\kappa}$.

## Code Explanation
The provided code calculates the transmission probability $T$ through a single rectangular potential barrier. It constructs the complex $2 	imes 2$ transfer matrix and extracts the $M_{11}$ element to find the tunneling probability.
