# Expectation Value <x>

## Concept
The expectation value of position $\langle x angle$ represents the average position of a particle if its position were measured many times in identical quantum states. It is calculated by integrating the position operator weighted by the probability density of the wavefunction.

## Formula
For a continuous 1D wavefunction $\psi(x)$:
$\langle x angle = \int_{-\infty}^{\infty} x |\psi(x)|^2 dx$
For a discretized state vector over a grid $\{x_i\}$:
$\langle x angle = \sum_{i} x_i |\psi_i|^2 \Delta x$
assuming the state is normalized.

## Code Explanation
The provided code calculates the expectation value of position for a Gaussian wave packet centered at $x=2$. It discretizes the domain, defines the wavefunction, ensures normalization, and performs the summation over the grid points.
