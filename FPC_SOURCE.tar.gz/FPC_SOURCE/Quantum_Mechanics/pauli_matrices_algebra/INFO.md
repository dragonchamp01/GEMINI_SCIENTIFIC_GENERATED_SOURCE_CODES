# Pauli Matrices Algebra

## Concept
The Pauli matrices $\sigma_x, \sigma_y, \sigma_z$ (often denoted $X, Y, Z$) are fundamental in quantum mechanics for describing spin and qubits. They are Hermitian ($A = A^\dagger$), unitary ($A A^\dagger = I$), and involutory ($A^2 = I$). Their algebraic properties, such as commutation and anti-commutation relations, define the structure of spin physics.

## Definitions
$\sigma_x = \begin{pmatrix} 0 & 1 \ 1 & 0 \end{pmatrix}, \quad \sigma_y = \begin{pmatrix} 0 & -i \ i & 0 \end{pmatrix}, \quad \sigma_z = \begin{pmatrix} 1 & 0 \ 0 & -1 \end{pmatrix}$

## Algebraic Relations
1.  **Commutation**: $[\sigma_j, \sigma_k] = 2i \epsilon_{jkl} \sigma_l$ (e.g., $[X, Y] = 2iZ$).
2.  **Anti-commutation**: $\{\sigma_j, \sigma_k\} = 2 \delta_{jk} I$ (e.g., $XY + YX = 0$).
3.  **Product**: $\sigma_j \sigma_k = \delta_{jk} I + i \epsilon_{jkl} \sigma_l$.

## Code Explanation
The provided code defines the three Pauli matrices and verifies the commutation relation $[X, Y] = 2iZ$ and the anti-commutation relation $\{X, Y\} = 0$. It demonstrates matrix multiplication and scaling with complex units.
