# Quantum Oscillator (2D Isotropic)

## Concept
The 2D isotropic quantum harmonic oscillator describes a particle of mass $m$ in a potential $V(x, y) = \frac{1}{2} m \omega^2 (x^2 + y^2)$. Since the potential is separable in Cartesian coordinates, the problem reduces to two independent 1D oscillators. This system exhibits degeneracy, where different sets of quantum numbers $(n_x, n_y)$ result in the same total energy.

## Formula
The energy eigenvalues are:
$E_{n_x, n_y} = (n_x + n_y + 1) \hbar \omega$
where $n_x, n_y = 0, 1, 2, \dots$
Defining the total quantum number $n = n_x + n_y$, the energy becomes:
$E_n = (n + 1) \hbar \omega$
The degeneracy of level $n$ is $g_n = n + 1$.

## Code Explanation
The provided code calculates the energy levels for a 2D oscillator and identifies the degeneracy for each level. It generates combinations of $n_x$ and $n_y$ and groups them by their total energy to demonstrate the $g_n = n+1$ rule.
