# Bra-Ket Formalism (Dirac Notation)

## Concept
Introduced by Paul Dirac, Bra-Ket notation is the standard mathematical notation for describing quantum states.
-   **Ket $| \psi angle$**: A column vector representing a quantum state in Hilbert space.
-   **Bra $\langle \psi |$**: The Hermitian conjugate (conjugate transpose) of a Ket, represented as a row vector.
-   **Inner Product $\langle \phi | \psi angle$**: A complex scalar representing the projection of one state onto another (overlap).
-   **Outer Product $| \psi angle \langle \phi |$**: An operator (matrix) that maps states to other states.

## Formula
If $| \psi angle = \begin{pmatrix} a \ b \end{pmatrix}$, then $\langle \psi | = \begin{pmatrix} a^* & b^* \end{pmatrix}$.
-   Inner product: $\langle \phi | \psi angle = \sum_i \phi_i^* \psi_i$
-   Outer product: $(| \psi angle \langle \phi |)_{ij} = \psi_i \phi_j^*$

## Code Explanation
The provided code demonstrates basic Bra-Ket operations. It calculates the inner product (scalar) and outer product (matrix) for two-level system states (qubits). It verifies that the inner product of a normalized state with itself is 1.
