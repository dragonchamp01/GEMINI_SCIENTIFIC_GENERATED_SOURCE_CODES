# Grover's Search Algorithm

## Concept
Grover's algorithm is a quantum algorithm for searching an unsorted database with $N$ entries in $O(\sqrt{N})$ time. Classically, searching an unsorted database requires $O(N)$ operations. The algorithm uses amplitude amplification, which increases the probability amplitude of the correct answer through two main operations: the Oracle (which marks the target state) and the Diffusion operator (which reflects the amplitudes about the average).

## Formula
1.  **Oracle**: $U_\omega |xangle = -|xangle$ if $x = \omega$, else $|xangle$.
2.  **Diffusion**: $U_s = 2|sangle\langle s| - I$, where $|sangle$ is the uniform superposition.
The optimal number of iterations is roughly $\frac{\pi}{4}\sqrt{N}$.

## Code Explanation
The provided code simulates the state vector evolution for a search in a 4-element database ($N=4, 2$ qubits). It shows how the amplitude of the "target" state increases after one Grover iteration, leading to a measurement probability of 100%.
