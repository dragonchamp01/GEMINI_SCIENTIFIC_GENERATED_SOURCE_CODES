# Mutual Information Basics

## Concept
Mutual information is a measure of the total correlation between two subsystems, $A$ and $B$, of a composite quantum system $AB$. It quantifies how much information is shared between the two parts. In quantum mechanics, mutual information captures both classical correlations and quantum correlations (such as entanglement).

## Formula
The quantum mutual information $I(A:B)$ is defined in terms of von Neumann entropies:
$I(A:B) = S(ho_A) + S(ho_B) - S(ho_{AB})$
where:
- $S(ho) = -	ext{Tr}(ho \ln ho)$ is the von Neumann entropy.
- $ho_A = 	ext{Tr}_B(ho_{AB})$ and $ho_B = 	ext{Tr}_A(ho_{AB})$ are the reduced density matrices.

## Code Explanation
The provided code calculates the mutual information for a 2-qubit system. It constructs the full density matrix, computes the reduced density matrices for each qubit, and then evaluates the entropies to find the shared information. It demonstrates that for a maximally entangled state, the mutual information is $2 \ln 2$ (or 2 bits).
