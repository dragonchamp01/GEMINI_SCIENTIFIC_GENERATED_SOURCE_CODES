# Born Rule

## Concept
The Born rule is a fundamental postulate of quantum mechanics which gives the probability that a measurement of a quantum system will yield a given result. It states that for a system in state $|\psiangle$, the probability of measuring the system in an eigenstate $|\phiangle$ is the square of the magnitude of the inner product (probability amplitude).

## Formula
$P = |\langle \phi | \psi angle|^2$
For a continuous system:
$P = \left| \int \phi(x)^* \psi(x) dx ight|^2$
If $\phi(x)$ is a position eigenstate $\delta(x - x_0)$, then the rule yields the standard probability density $P(x_0) = |\psi(x_0)|^2$.

## Code Explanation
The provided code calculates the probability of finding a particle in the ground state of a harmonic oscillator given it is currently in a shifted Gaussian state. It performs the inner product (integration) of the two wavefunctions and squares the result.
