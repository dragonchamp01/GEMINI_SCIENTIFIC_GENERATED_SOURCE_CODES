# Probability Density

## Concept
In quantum mechanics, the probability density $|\psi(x)|^2$ is a real-valued function that provides the probability per unit length of finding a particle at position $x$. The wavefunction itself is complex and does not have a direct physical interpretation, but its absolute square represents a physical probability distribution.

## Formula
$P(x) = \psi(x)^* \psi(x) = |\psi(x)|^2$
The total probability over the entire space must be normalized:
$\int_{-\infty}^{\infty} P(x) dx = 1$

## Code Explanation
The provided code calculates and displays the probability density for a complex-valued wavepacket. It demonstrates the use of complex conjugate multiplication and ensures the resulting density is real and normalized.
