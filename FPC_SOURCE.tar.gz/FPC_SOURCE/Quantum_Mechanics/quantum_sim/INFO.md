# Quantum Simulation (Basic State)

## Concept
In quantum mechanics, the state of a system is described by a complex-valued function called the wavefunction $\psi(x)$, or more generally, a state vector $|\psiangle$ in a Hilbert space. For a discrete system (like a qubit or a discretized 1D box), this is represented as a complex vector.

## Properties
1.  **Normalization**: The total probability of finding the particle somewhere must be 1.
    $\int |\psi(x)|^2 dx = 1 \quad 	ext{or} \quad \sum |c_i|^2 = 1$
2.  **Superposition**: A quantum system can be in multiple states simultaneously until measured.
3.  **Complex Amplitudes**: Each component of the vector is a complex number $a + bi$.

## Code Explanation
The provided code demonstrates how to initialize a discrete quantum state vector, normalize it, and calculate the probabilities of being in each state. The implementation handles complex numbers across all four languages.
