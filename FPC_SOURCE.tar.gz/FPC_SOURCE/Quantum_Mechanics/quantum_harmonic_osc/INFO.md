# Quantum Harmonic Oscillator

## Concept
The quantum harmonic oscillator is the quantum-mechanical analog of the classical harmonic oscillator. It describes a particle in a parabolic potential $V(x) = \frac{1}{2} m \omega^2 x^2$. This model is used to describe vibrations in molecules and solids. Unlike the classical oscillator, the energy levels are quantized and the ground state has non-zero energy (zero-point energy).

## Formula
The energy eigenvalues are:
$E_n = (n + \frac{1}{2}) \hbar \omega, \quad n = 0, 1, 2, \dots$
The wavefunctions are given by:
$\psi_n(x) = N_n H_n(\alpha x) e^{-\frac{\alpha^2 x^2}{2}}$
where $H_n$ are Hermite polynomials, $\alpha = \sqrt{\frac{m\omega}{\hbar}}$, and $N_n$ is a normalization constant.

## Code Explanation
The provided code calculates the energy levels for $n=0$ to $n=3$ and evaluates the Hermite polynomials to construct the normalized wavefunctions. It demonstrates the quantization of energy and the shape of the probability distributions for the first few states.
