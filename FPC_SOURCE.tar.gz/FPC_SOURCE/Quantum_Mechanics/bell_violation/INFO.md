# Bell Inequality Violation (CHSH)

## Concept
Bell's Theorem proves that quantum mechanics is incompatible with local hidden-variable theories. The CHSH inequality (named after Clauser, Horne, Shimony, and Holt) provides a way to experimentally test this. For any local hidden-variable theory, the CHSH correlation value $|S|$ must be $\le 2$. Quantum mechanics predicts a maximum value of $2\sqrt{2} \approx 2.828$.

## Formula
$S = E(a, b) - E(a, b') + E(a', b) + E(a', b')$
where $E(a, b)$ is the expectation value of the correlation between measurements at detector angles $a$ and $b$.
Quantum result for a Bell state $|\Psi^-angle$: $E(a, b) = -\cos(a - b)$.
Max violation occurs at $a=0, a'=\pi/2, b=\pi/4, b'=3\pi/4$.

## Code Explanation
The provided code calculates the CHSH correlation value $S$ using the quantum mechanical formula for an entangled pair. It demonstrates that the resulting value exceeds the classical limit of 2, confirming the violation of Bell's inequality.
