# Shor's Factorization Basics

## Concept
Shor's algorithm is a quantum algorithm for finding the prime factors of an integer $N$. It is famous for being exponentially faster than the best-known classical algorithms (like the General Number Field Sieve). The algorithm reduces the problem of factoring to the problem of finding the **period** (or order) of a function, a task that quantum computers can perform efficiently using the Quantum Fourier Transform.

## The Procedure
To factor $N$:
1.  **Classical Reduction**: Pick a random integer $a < N$. If $	ext{gcd}(a, N) > 1$, we found a factor.
2.  **Quantum Order Finding**: Find the smallest integer $r$ (the period) such that $a^r \equiv 1 \pmod N$. This is done using Quantum Phase Estimation on the unitary $U|xangle = |ax \pmod Nangle$.
3.  **Classical Factor Extraction**: If $r$ is even and $a^{r/2} 
ot\equiv -1 \pmod N$, then $	ext{gcd}(a^{r/2} \pm 1, N)$ are factors of $N$.

## Code Explanation
The provided code demonstrates the classical reduction part of Shor's algorithm. It takes an integer $N$, a guess $a$, and an assumed period $r$ (simulating the output of the quantum step) to extract the prime factors.
