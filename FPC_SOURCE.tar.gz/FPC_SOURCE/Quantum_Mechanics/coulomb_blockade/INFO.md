# Coulomb Blockade

## Concept
Coulomb blockade is a quantum mechanical phenomenon where the conductance of a small electronic device (like a quantum dot or a tunnel junction) is suppressed at low temperatures and small bias voltages. This occurs because the energy required to add a single electron to the device (the "charging energy") is greater than the thermal energy and the applied voltage.

## Formula
The charging energy $E_c$ is defined as:
$E_c = \frac{e^2}{2C}$
where $e$ is the elementary charge and $C$ is the capacitance of the device. Conduction is blocked if:
$|V| < \frac{e}{2C}$
where $V$ is the bias voltage.

## Code Explanation
The provided code calculates the charging energy for a given capacitance and determines whether the current is "blocked" or "allowed" for a range of bias voltages. It demonstrates the "Coulomb diamond" or staircase behavior in a simplified 1D plot.
