# Stern-Gerlach Experiment Simulation

## Concept
The Stern-Gerlach experiment, performed in 1922, demonstrated that the spatial orientation of angular momentum is quantized. A beam of particles (like silver atoms) with an intrinsic magnetic moment (spin) passes through an inhomogeneous magnetic field. Classically, the beam would smear into a continuous distribution. Quantum mechanically, it splits into discrete points corresponding to the eigenvalues of the spin operator.

## Formula
The force on a particle with magnetic moment $\vec{\mu}$ in a magnetic field $\vec{B}$ is:
$\vec{F} = 
abla (\vec{\mu} \cdot \vec{B})$
For a field gradient in the z-direction ($B_z$), the deflection depends on the spin component $S_z$:
$F_z \approx \mu_z \frac{\partial B_z}{\partial z} = \gamma S_z \frac{\partial B_z}{\partial z}$
For spin-1/2, $S_z = \pm \hbar/2$, leading to two distinct spots.

## Code Explanation
The provided code simulates the deflection of a collection of particles. It randomly assigns spin states (+1/2 or -1/2) to particles and calculates their final vertical position on a screen after passing through a magnetic field gradient.
