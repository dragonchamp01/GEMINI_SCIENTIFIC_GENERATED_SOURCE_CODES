# Bose-Einstein Distribution

## Concept
The Bose-Einstein (BE) distribution is a probability distribution that describes the average number of identical bosons (particles with integer spin) occupying a set of available energy states in thermal equilibrium. Unlike fermions, bosons are not restricted by the Pauli exclusion principle, meaning any number of bosons can occupy the same quantum state. At very low temperatures, this leads to Bose-Einstein Condensation (BEC), where a large fraction of bosons occupy the lowest energy state.

## Formula
The mean occupancy $\langle n_i angle$ of a state with energy $E_i$ is:
$\langle n_i angle = \frac{1}{e^{\beta(E_i - \mu)} - 1}$
where:
- $\beta = 1/k_B T$ is the thermodynamic beta.
- $\mu$ is the chemical potential ($\mu < E_{min}$ for bosons).
- $k_B$ is the Boltzmann constant.

## Code Explanation
The provided code calculates the occupancy of energy states for a given temperature and chemical potential. It demonstrates how the occupancy increases significantly for lower energy states as the temperature decreases, illustrating the onset of condensation.
