# Particle in a Box (Infinite Square Well)

## Concept
The particle in a box model (also known as the infinite square well) describes a particle that is confined within a perfectly rigid box of length $L$, from which it cannot escape. Inside the box, the potential energy is zero; outside, it is infinite. This model is used to illustrate the differences between classical and quantum mechanics, specifically the quantization of energy levels.

## Formula
For a box of length $L$ ($0 \le x \le L$), the energy levels are quantized:
$E_n = \frac{n^2 \pi^2 \hbar^2}{2mL^2}, \quad n = 1, 2, 3, \dots$
The normalized wavefunctions are:
$\psi_n(x) = \sqrt{\frac{2}{L}} \sin\left(\frac{n\pi x}{L}ight)$

## Code Explanation
The provided code calculates the energy of the first few levels and the value of the wavefunction $\psi_n(x)$ at a given point $x$. It demonstrates how the energy scales with the quantum number $n$.
