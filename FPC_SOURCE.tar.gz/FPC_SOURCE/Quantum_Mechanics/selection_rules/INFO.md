# Selection Rules

## Concept
Selection rules are constraints that restrict the possible transitions of a system from one quantum state to another. In the context of light-matter interaction, the electric dipole transition between state $i$ and state $f$ is allowed only if the transition dipole moment $\mu_{fi} = \langle \psi_f | \hat{x} | \psi_i angle$ is non-zero. For a harmonic oscillator, this leads to the rule $\Delta n = \pm 1$.

## Formula
The transition probability is proportional to:
$P \propto |\int_{-\infty}^{\infty} \psi_f(x)^* x \psi_i(x) dx|^2$
If this integral is zero, the transition is "forbidden" (by dipole interaction).

## Code Explanation
The provided code numerically evaluates the transition integral between various states of a Quantum Harmonic Oscillator. It checks the transition from $n=0$ to $n=1$ (allowed) and $n=0$ to $n=2$ (forbidden) to verify the $\Delta n = \pm 1$ selection rule.
