# Fermi's Golden Rule

## Concept
Fermi's Golden Rule is used to calculate the transition rate (transition probability per unit time) from an initial quantum state to a continuum of final states under the influence of a weak, time-dependent perturbation $H'(t)$. It is a central result in time-dependent perturbation theory and is widely used in spectroscopy, nuclear decay, and semiconductor physics.

## Formula
The transition rate $\Gamma_{i 	o f}$ is:
$\Gamma_{i 	o f} = \frac{2\pi}{\hbar} |\langle f | H' | i angle|^2 ho(E_f)$
where:
- $\langle f | H' | i angle$ is the matrix element of the perturbation between initial and final states.
- $ho(E_f)$ is the density of final states at energy $E_f$.
- The rule is valid when the final states form a continuum.

## Code Explanation
The provided code calculates the transition rate for a simple model. It computes the matrix element (integral) of a perturbation $H'(x)$ between two wavefunctions and multiplies it by a density of states factor to find the rate $\Gamma$.
