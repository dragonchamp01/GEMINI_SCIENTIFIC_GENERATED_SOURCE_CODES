# Quantum Phase Estimation (QPE)

## Concept
The Quantum Phase Estimation (QPE) algorithm is used to estimate the phase $	heta$ of an eigenvalue $e^{2\pi i 	heta}$ of a unitary operator $U$. Given a unitary $U$ and its eigenstate $|uangle$ such that $U|uangle = e^{2\pi i 	heta}|uangle$, QPE calculates $	heta$ with high precision. It is a key routine in Shor's algorithm and quantum chemistry (to find energy levels).

## Algorithm
1.  **Initialization**: Prepare $n$ precision qubits in $|0angle$ and the target state $|uangle$.
2.  **Superposition**: Apply Hadamard gates to the precision qubits.
3.  **Controlled-U**: Apply successive controlled-$U^{2^k}$ operations from each precision qubit to the target state.
4.  **Inverse QFT**: Apply the inverse Quantum Fourier Transform to the precision qubits.
5.  **Measurement**: Measure the precision qubits to obtain an binary approximation of $	heta$.

## Code Explanation
The provided code simulates the mathematical result of the QPE process. It assumes we have a unitary with phase $	heta = 0.625$ ($5/8$) and shows how the state vector after the controlled operations and inverse QFT points to the binary representation of the phase.
