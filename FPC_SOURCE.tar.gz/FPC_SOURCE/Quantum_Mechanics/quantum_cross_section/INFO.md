# Quantum Cross Section

## Concept
The scattering cross section $\sigma$ is a measure of the probability that a specific scattering process will occur. It has dimensions of area. The differential cross section $\frac{d\sigma}{d\Omega}$ describes the probability of scattering into a specific solid angle $d\Omega$, while the total cross section $\sigma_{tot}$ is the integral over all angles.

## Formula
1.  **Differential Cross Section**: $\frac{d\sigma}{d\Omega} = |f(	heta)|^2$
2.  **Total Cross Section**: $\sigma_{tot} = \int |f(	heta)|^2 d\Omega = 2\pi \int_{0}^{\pi} |f(	heta)|^2 \sin(	heta) d	heta$
For a hard sphere of radius $R$ in the low-energy limit, $\sigma_{tot} = 4\pi R^2$.

## Code Explanation
The provided code calculates the total cross section for a Yukawa potential by numerically integrating the square of the scattering amplitude over all angles using Simpson's Rule.
