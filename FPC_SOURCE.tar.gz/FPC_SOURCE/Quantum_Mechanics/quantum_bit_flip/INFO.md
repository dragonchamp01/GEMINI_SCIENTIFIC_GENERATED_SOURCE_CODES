# Quantum Bit Flip Error

## Concept
A bit-flip error is one of the most common types of noise in quantum computing. It is the quantum equivalent of a classical bit flip (0 to 1 or 1 to 0). In quantum mechanics, this is represented by the action of the Pauli-$X$ operator on a qubit. Unlike classical errors, quantum errors can occur in superposition and affect the phase of the qubit as well.

## Formula
Action of the Pauli-X operator:
$X |0angle = |1angle$
$X |1angle = |0angle$
In matrix form:
$X = \begin{pmatrix} 0 & 1 \ 1 & 0 \end{pmatrix}$
A general state $|\psiangle = \alpha|0angle + \beta|1angle$ becomes $X|\psiangle = \beta|0angle + \alpha|1angle$.

## Code Explanation
The provided code simulates a bit-flip error on a single qubit state vector. It applies the $X$ operator matrix to a given state and compares the result with the original to illustrate the effect of the error.
