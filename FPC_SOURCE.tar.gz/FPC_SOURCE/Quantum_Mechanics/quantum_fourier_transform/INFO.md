# Quantum Fourier Transform (QFT)

## Concept
The Quantum Fourier Transform (QFT) is a linear transformation on quantum bits, and is the quantum analogue of the discrete Fourier transform. It is a fundamental component of many quantum algorithms, including Shor's algorithm for factoring integers and the quantum phase estimation algorithm. While the classical FFT takes $O(N \log N)$ steps for $N$ amplitudes, the QFT can be performed in $O((\log N)^2)$ steps on a quantum computer.

## Formula
The QFT maps a basis state $|jangle$ to a superposition of basis states:
$|jangle 	o \frac{1}{\sqrt{N}} \sum_{k=0}^{N-1} e^{2\pi i jk / N} |kangle$
where $N = 2^n$ for $n$ qubits.

## Code Explanation
The provided code implements the QFT matrix for a small number of qubits. It constructs the unitary matrix using the mathematical definition and applies it to an input state vector to demonstrate the frequency domain representation of quantum amplitudes.
