# Quantum Stark Effect

## Concept
The Stark effect is the quantum mechanical analogue of the Zeeman effect, describing the splitting and shifting of atomic energy levels in the presence of an external electric field $\vec{E}$. It occurs because the electric field interacts with the electric dipole moment of the atom. The effect can be "linear" (proportional to $E$) or "quadratic" (proportional to $E^2$), depending on whether the atom has a permanent dipole moment in that state.

## Formula
For the Hydrogen atom in the $n=2$ state, the linear Stark effect energy shifts are:
$\Delta E = \pm 3 e E a_0$
where:
- $e$ is the elementary charge.
- $E$ is the electric field strength.
- $a_0$ is the Bohr radius.
This arises from the mixing of the $2s$ and $2p_z$ states which are degenerate in the absence of a field.

## Code Explanation
The provided code calculates the energy level splitting for the $n=2$ manifold of Hydrogen in an external electric field. It computes the magnitude of the shift in electron-volts (eV) and displays the resulting energies of the four states ($2s, 2p_x, 2p_y, 2p_z$).
