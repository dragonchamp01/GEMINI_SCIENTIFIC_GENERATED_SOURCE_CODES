# Clebsch-Gordan Coefficients

## Concept
In quantum mechanics, when two systems with angular momenta $j_1$ and $j_2$ are coupled, the total angular momentum $j$ and its projection $m$ are described by the coupled basis $|j_1, j_2, j, mangle$. The Clebsch-Gordan coefficients are the expansion coefficients of this basis in terms of the uncoupled basis $|j_1, m_1angle |j_2, m_2angle$. They are used to describe atomic transitions, multi-particle spin states, and symmetry properties.

## Formula
$|j, mangle = \sum_{m_1, m_2} \langle j_1, m_1, j_2, m_2 | j, m angle |j_1, m_1angle |j_2, m_2angle$
The coefficients are non-zero only if $|j_1 - j_2| \le j \le j_1 + j_2$ and $m = m_1 + m_2$.

## Code Explanation
The provided code calculates the coefficients for coupling two spin-1/2 particles ($j_1 = 1/2, j_2 = 1/2$). It demonstrates the formation of the triplet states ($j=1$) and the singlet state ($j=0$).
