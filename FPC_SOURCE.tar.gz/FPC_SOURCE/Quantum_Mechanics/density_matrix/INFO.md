# Density Matrix

## Concept
The density matrix $ho$ is an alternative representation of the state of a quantum system. While pure states are represented by vectors $|\psiangle$, mixed states (which arise from statistical uncertainty or entanglement with an environment) require the density matrix formalism. A density matrix $ho$ must be Hermitian, positive semi-definite, and have a trace of 1.

## Formula
1.  **Pure State**: $ho = |\psiangle\langle\psi|$.
2.  **Mixed State**: $ho = \sum p_i |\psi_iangle\langle\psi_i|$, where $\sum p_i = 1$.
3.  **Purity**: A state is pure if $	ext{Tr}(ho^2) = 1$ and mixed if $	ext{Tr}(ho^2) < 1$.
4.  **Expectation Value**: $\langle A angle = 	ext{Tr}(ho A)$.

## Code Explanation
The provided code constructs density matrices for a pure state and a mixed state (a 50/50 mixture of $|0angle$ and $|1angle$). It calculates the trace and the purity $	ext{Tr}(ho^2)$ to distinguish between them.
