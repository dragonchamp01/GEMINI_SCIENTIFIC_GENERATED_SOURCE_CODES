# Schmidt Decomposition

## Concept
Schmidt decomposition is a fundamental theorem in quantum information theory. It states that any pure state $|\psiangle_{AB}$ of a bipartite system can be written as a sum of products of orthonormal states of the two subsystems:
$|\psiangle_{AB} = \sum_{i} \sqrt{\lambda_i} |u_iangle_A |v_iangle_B$
where $\lambda_i$ are non-negative real numbers satisfying $\sum \lambda_i = 1$, called the Schmidt coefficients. The number of non-zero $\lambda_i$ is the **Schmidt rank**, which is a measure of entanglement (rank > 1 means the state is entangled).

## Formula
The Schmidt coefficients $\sqrt{\lambda_i}$ are the singular values of the coefficient matrix $C$ obtained by reshaping the state vector $|\psiangle$.
If $|\psiangle = \sum_{j,k} c_{jk} |jangle_A |kangle_B$, then $C = (c_{jk})$.
Performing Singular Value Decomposition (SVD) on $C$ gives $C = U \Sigma V^\dagger$, where the diagonal elements of $\Sigma$ are the Schmidt coefficients.

## Code Explanation
The provided code takes a 4-dimensional state vector (representing a 2-qubit system), reshapes it into a $2 	imes 2$ matrix, and performs SVD. It outputs the Schmidt coefficients and the Schmidt rank to determine the level of entanglement.
