# Quantum Fine Structure

## Concept
Fine structure describes the small splitting of the spectral lines of an atom due to relativistic effects and spin-orbit coupling. For the hydrogen atom, the main energy levels depend only on the principal quantum number $n$. However, fine structure corrections cause levels with different total angular momentum $j$ to have slightly different energies.

## Formula
The energy correction for the fine structure in a hydrogen-like atom is:
$\Delta E_{FS} = \frac{E_n \alpha^2}{n} \left( \frac{1}{j + 1/2} - \frac{3}{4n} ight)$
where:
- $E_n = -13.6 Z^2 / n^2$ eV is the Bohr energy.
- $\alpha \approx 1/137.036$ is the fine-structure constant.
- $j$ is the total angular momentum quantum number ($j = l \pm 1/2$).

## Code Explanation
The provided code calculates the fine structure energy correction for the $n=2$ state of Hydrogen. It compares the energies for $j=1/2$ and $j=3/2$, showing the magnitude of the splitting in electron-volts (eV).
