# Quantum Error Correction (3-Qubit Repetition Code)

## Concept
Quantum error correction (QEC) is used to protect quantum information from errors due to decoherence and other quantum noise. The 3-qubit repetition code encodes one logical qubit into three physical qubits. If a bit-flip error occurs on any one of the three physical qubits, the error can be detected and corrected by measuring the "syndrome" (parity checks) and applying a majority vote.

## Encoding
-   Logical $|0angle_L = |000angle$
-   Logical $|1angle_L = |111angle$

## Recovery
1.  **Syndrome Measurement**: Measure the parity of pairs (e.g., $Z_1Z_2$ and $Z_2Z_3$).
2.  **Correction**: Based on the syndrome, identify the flipped qubit. If the syndrome $(Z_1Z_2, Z_2Z_3)$ is $(-1, 1)$, qubit 1 is flipped. If $(1, -1)$, qubit 3 is flipped. If $(-1, -1)$, qubit 2 is flipped.

## Code Explanation
The provided code simulates the bit-flip protection. It takes an encoded logical state, applies a random bit-flip error to one of the physical qubits, and then uses majority voting logic to "recover" the original state.
