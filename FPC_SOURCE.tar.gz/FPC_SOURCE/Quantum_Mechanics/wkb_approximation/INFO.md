# WKB Approximation

## Concept
The WKB (Wentzel-Kramers-Brillouin) approximation is a method for finding approximate solutions to linear differential equations with spatially varying coefficients. In quantum mechanics, it is used to solve the Schrödinger equation when the potential $V(x)$ changes slowly compared to the particle's wavelength. It is particularly effective for calculating tunneling probabilities through barriers of arbitrary shape.

## Formula
The tunneling probability $T$ through a barrier $V(x)$ between points $x_1$ and $x_2$ (the classical turning points where $V(x) = E$) is:
$T \approx e^{-2 \gamma}$
where $\gamma = \frac{1}{\hbar} \int_{x_1}^{x_2} \sqrt{2m(V(x) - E)} dx$
This is often called the "Gamow factor."

## Code Explanation
The provided code calculates the tunneling probability through a **parabolic barrier** $V(x) = V_0(1 - x^2/L^2)$. It numerically integrates the Gamow factor $\gamma$ using the Trapezoidal rule between the turning points and computes the resulting transmission coefficient $T$.
