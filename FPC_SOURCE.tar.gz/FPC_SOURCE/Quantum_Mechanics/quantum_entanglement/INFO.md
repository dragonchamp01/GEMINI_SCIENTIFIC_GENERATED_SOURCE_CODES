# Quantum Entanglement

## Concept
Quantum entanglement is a property of multi-particle systems where the state of the system cannot be factored into a product of individual particle states. Even when separated by large distances, the measurement results of entangled particles are correlated in ways that classical physics cannot explain. A state is "entangled" if it is not "separable."

## Criteria for Entanglement
A pure bipartite state $|\psiangle$ is entangled if its **von Neumann entropy of entanglement** is greater than zero. This is equivalent to checking if the reduced density matrix $ho_A = 	ext{Tr}_B(|\psiangle\langle\psi|)$ represents a mixed state. For a 2-qubit state $|\psiangle = \alpha|00angle + \beta|01angle + \gamma|10angle + \delta|11angle$, it is separable if and only if $\alpha\delta - \beta\gamma = 0$.

## Code Explanation
The provided code takes the coefficients of a 2-qubit state and calculates the "concurrence" or the determinant of the coefficient matrix to determine if the state is entangled or separable. It demonstrates the check for a Bell state (entangled) and a product state (separable).
