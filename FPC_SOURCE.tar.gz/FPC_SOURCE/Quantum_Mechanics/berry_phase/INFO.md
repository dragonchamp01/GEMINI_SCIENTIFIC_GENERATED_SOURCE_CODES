# Berry Phase

## Concept
The Berry Phase is a non-trivial geometric phase acquired by a quantum system during an adiabatic, cyclic evolution. Unlike the dynamic phase, which depends on the time elapsed and the energy of the state, the Berry Phase depends only on the geometry of the path taken in the parameter space. It is fundamental to topological insulators and the Aharonov-Bohm effect.

## Formula
For a state $|n(\mathbf{R})angle$ evolving along a closed path $C$ in parameter space $\mathbf{R}$:
$\gamma_n(C) = i \oint_C \langle n(\mathbf{R}) | 
abla_{\mathbf{R}} n(\mathbf{R}) angle \cdot d\mathbf{R}$
For a spin-1/2 particle in a magnetic field $\mathbf{B}$ that traces a solid angle $\Omega$:
$\gamma = -\frac{1}{2} \Omega$

## Code Explanation
The provided code numerically calculates the Berry Phase for a 2-level system (qubit) subjected to a rotating Hamiltonian. It discretizes the cycle into small steps and sums the phase contributions $	ext{Im}(\ln \langle \psi(t) | \psi(t+\Delta t) angle)$, which is the discrete equivalent of the Berry connection integral.
