# Path Integral Basics

## Concept
The Feynman path integral is a formulation of quantum mechanics where the probability amplitude for a particle to move from point $A$ to point $B$ is found by summing over all possible paths between the two points. Each path is weighted by $e^{iS/\hbar}$, where $S$ is the classical action of the path. This provides a bridge between classical and quantum mechanics, as the most likely path corresponds to the stationary action (classical path).

## Formula
The propagator $K(x_f, t_f; x_i, t_i)$ is:
$K(x_f, t_f; x_i, t_i) = \int \mathcal{D}[x(t)] e^{\frac{i}{\hbar} \int_{t_i}^{t_f} L(x, \dot{x}, t) dt}$
For a free particle, the propagator has an analytical form:
$K(x, t; 0, 0) = \sqrt{\frac{m}{2\pi i \hbar t}} e^{\frac{imx^2}{2\hbar t}}$

## Code Explanation
The provided code demonstrates the calculation of the free particle propagator for a given mass and time interval. It calculates the amplitude at various positions $x$, showing the spreading of the probability distribution over time.
