# Probability Current

## Concept
In quantum mechanics, the probability current $j$ is a mathematical quantity describing the flow of probability density. It is analogous to the current density in electromagnetism or fluid dynamics. If the probability density is changing in a region, the probability current explains how much probability is "flowing" into or out of that region, satisfying the continuity equation: $\frac{\partial ho}{\partial t} + 
abla \cdot j = 0$.

## Formula
For a particle of mass $m$ described by a wavefunction $\psi$, the 1D probability current is:
$j = \frac{\hbar}{2mi} \left( \psi^* \frac{\partial \psi}{\partial x} - \psi \frac{\partial \psi^*}{\partial x} ight)$
For a plane wave $\psi = Ae^{ikx}$, the current is $j = |A|^2 \frac{\hbar k}{m} = |A|^2 v$, where $v$ is the classical velocity.

## Code Explanation
The provided code calculates the probability current for a plane wave $\psi(x) = e^{ikx}$. It uses numerical differentiation to find the spatial derivative of the complex wavefunction and then applies the formula to find $j$.
