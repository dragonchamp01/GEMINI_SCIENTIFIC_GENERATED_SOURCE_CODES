# Paschen-Back Effect

## Concept
The Paschen-Back effect is the splitting of atomic energy levels in the presence of a **strong** magnetic field. It occurs when the magnetic field is strong enough to decouple the orbital angular momentum $\vec{L}$ and the spin angular momentum $\vec{S}$. In this limit, the magnetic interaction is much larger than the spin-orbit coupling, and the quantum numbers $m_l$ and $m_s$ become independent good quantum numbers.

## Formula
The energy shift in the Paschen-Back limit is:
$\Delta E = \mu_B B (m_l + 2m_s)$
where:
- $\mu_B \approx 5.788 	imes 10^{-5}$ eV/T is the Bohr magneton.
- $B$ is the magnetic field strength in Tesla.
- $m_l$ is the orbital magnetic quantum number.
- $m_s = \pm 1/2$ is the spin magnetic quantum number.

## Code Explanation
The provided code calculates the energy level splitting for an electron in a $p$-orbital ($l=1$) in a strong magnetic field (e.g., 10 Tesla). It generates all possible combinations of $(m_l, m_s)$ and computes the resulting energy shifts.
