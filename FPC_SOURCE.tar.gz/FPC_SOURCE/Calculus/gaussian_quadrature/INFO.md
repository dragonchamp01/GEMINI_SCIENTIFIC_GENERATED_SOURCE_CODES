# Gaussian Quadrature (Gauss-Legendre)

## Concept
Gaussian Quadrature is a numerical integration method that provides the best possible accuracy for a given number of function evaluations. Unlike the Trapezoidal or Simpson's rules, which use equally spaced points, Gaussian Quadrature picks optimal points (roots of orthogonal polynomials) and weights to make the integration exact for polynomials of degree $2n-1$ or less.

## Formula
For the interval $[-1, 1]$, the integral is approximated as:
$\int_{-1}^{1} f(x) dx \approx \sum_{i=1}^{n} w_i f(x_i)$
For a general interval $[a, b]$, a change of variables is used:
$x = \frac{b-a}{2}t + \frac{b+a}{2}$
$\int_{a}^{b} f(x) dx \approx \frac{b-a}{2} \sum_{i=1}^{n} w_i f\left(\frac{b-a}{2}t_i + \frac{b+a}{2}ight)$
Where $t_i$ and $w_i$ are the nodes and weights for the $n$-point Gauss-Legendre rule.

## Code Explanation
The provided code implements the **3-point Gauss-Legendre rule** to integrate $f(x) = e^x$ from $0$ to $1$.
Nodes ($t_i$): $0, \pm\sqrt{3/5}$
Weights ($w_i$): $8/9, 5/9, 5/9$
Analytical Result: $e^1 - e^0 = e - 1 \approx 1.718281828$.
The code demonstrates how a mere 3 evaluations can yield extremely high precision.
