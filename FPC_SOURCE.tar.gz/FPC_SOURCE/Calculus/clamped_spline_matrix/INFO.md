# Clamped Cubic Spline Interpolation

## Concept
A Clamped Cubic Spline is a piecewise cubic polynomial where the slopes (first derivatives) at the endpoints $x_0$ and $x_n$ are specified. This is often used in engineering when the entry and exit angles of a path are fixed.

## Formula
In addition to the standard continuity conditions, we enforce:
$S'_0(x_0) = f'(x_0)$
$S'_{n-1}(x_n) = f'(x_n)$
This modifies the first and last rows of the tridiagonal matrix system used to solve for the second derivatives ($c_i$ coefficients).
The first row becomes: $2h_0 c_0 + h_0 c_1 = 3[\frac{a_1-a_0}{h_0} - f'(x_0)]$
The last row becomes: $h_{n-1} c_{n-1} + 2h_{n-1} c_n = 3[f'(x_n) - \frac{a_n-a_{n-1}}{h_{n-1}}]$

## Code Explanation
The provided code interpolates points with specified boundary slopes.
It solves the resulting $(n+1) 	imes (n+1)$ tridiagonal system.
The implementation includes a tridiagonal solver and a function to evaluate the spline at any point within the range.
