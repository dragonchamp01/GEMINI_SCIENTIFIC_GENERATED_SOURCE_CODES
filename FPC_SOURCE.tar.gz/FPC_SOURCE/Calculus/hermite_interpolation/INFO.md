# Hermite Interpolation

## Concept
Hermite interpolation generalizes polynomial interpolation by matching not only the function values at the data points but also their derivatives. This results in a smoother approximation than Lagrange or Newton interpolation.

## Formula
Given points $(x_i, y_i, y'_i)$, the Hermite polynomial $H(x)$ is constructed using divided differences with repeated arguments.
Let $z_{2i} = z_{2i+1} = x_i$.
The divided differences table is initialized with $f[z_{2i}] = f[z_{2i+1}] = y_i$.
For the first derivative, $f[z_{2i}, z_{2i+1}] = y'_i$.
Higher order differences are computed normally.

## Code Explanation
The provided code approximates $f(x) = x^3$ using two points $x=0$ and $x=1$, along with their derivatives.
Data: $(0, 0, 0)$ and $(1, 1, 3)$ since $f(0)=0, f'(0)=0$ and $f(1)=1, f'(1)=3$.
Analytically, Hermite interpolation with 2 points (and derivatives) yields a cubic polynomial. Since the original function is cubic, the approximation should be exact.
