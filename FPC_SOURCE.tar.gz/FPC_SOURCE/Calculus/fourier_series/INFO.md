# Fourier Series

## Concept
A Fourier Series is a way to represent a periodic function as a sum of simple sine and cosine waves. It decomposes any periodic signal into its constituent frequencies, which is fundamental in signal processing, physics, and engineering.

## Formula
For a function $f(x)$ with period $2L$, the Fourier Series is:
$f(x) \approx \frac{a_0}{2} + \sum_{n=1}^{N} \left[ a_n \cos\left(\frac{n\pi x}{L}ight) + b_n \sin\left(\frac{n\pi x}{L}ight) ight]$
The coefficients are calculated using integrals:
$a_n = \frac{1}{L} \int_{-L}^{L} f(x) \cos\left(\frac{n\pi x}{L}ight) dx$
$b_n = \frac{1}{L} \int_{-L}^{L} f(x) \sin\left(\frac{n\pi x}{L}ight) dx$

## Code Explanation
The provided code approximates a **Square Wave** with period $2\pi$ ($L=\pi$).
Function definition: $f(x) = 1$ if $0 \le x < \pi$, and $f(x) = -1$ if $-\pi \le x < 0$.
Analytically, $a_n = 0$ for all $n$, and $b_n = \frac{4}{n\pi}$ for odd $n$.
The code numerically calculates the first few $a_n$ and $b_n$ coefficients using Simpson's Rule and reconstructs the signal at a point.
