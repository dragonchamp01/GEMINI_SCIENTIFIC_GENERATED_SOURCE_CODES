# Bairstow's Method

## Concept
Bairstow's Method is an iterative algorithm used to find all roots of a real polynomial. Unlike Newton's method, which finds one root at a time, Bairstow's method extracts a quadratic factor $x^2 - rx - s$ from the polynomial. This allows it to find complex conjugate pairs of roots using only real arithmetic.

## Formula
Given a polynomial $P(x)$, we divide it by $x^2 - rx - s$ to get a quotient $Q(x)$ and a remainder $b_1(x-r) + b_0$. We want the remainder to be zero. We use a Newton-Raphson approach to update $r$ and $s$:
$\begin{bmatrix} c_2 & c_3 \ c_1 & c_2 \end{bmatrix} \begin{bmatrix} \Delta r \ \Delta s \end{bmatrix} = \begin{bmatrix} b_1 \ b_0 \end{bmatrix}$
where $b_i$ and $c_i$ are coefficients obtained through synthetic division. After finding a quadratic factor, we solve for its roots and repeat the process on the quotient $Q(x)$.

## Code Explanation
The provided code finds all roots of the polynomial $P(x) = x^4 - 3x^3 + 5x^2 - x - 10$.
It iteratively extracts quadratic factors and solves them using the quadratic formula.
The implementation handles the synthetic division and the $2 	imes 2$ system solver for $\Delta r$ and $\Delta s$.
