# Sturm-Liouville Problem

## Concept
The Sturm-Liouville theory studies second-order linear ordinary differential equations of the form:
$-\frac{d}{dx} [p(x) \frac{dy}{dx}] + q(x)y = \lambda w(x)y$
where $\lambda$ is an eigenvalue.

## Formula
Using the Finite Difference Method, we can discretize the domain $[0, L]$ into $N$ intervals.
For the simplest case where $p(x)=1, q(x)=0, w(x)=1$ (i.e., $-y'' = \lambda y$) with boundary conditions $y(0)=y(L)=0$:
The discretized equation becomes:
$\frac{-y_{i-1} + 2y_i - y_{i+1}}{h^2} = \lambda y_i$
This reduces to a matrix eigenvalue problem $A\mathbf{y} = \lambda \mathbf{y}$.

## Code Explanation
The provided code solves the Sturm-Liouville problem $-y'' = \lambda y$ on $[0, \pi]$ with $y(0)=y(\pi)=0$.
Analytically, the eigenvalues are $\lambda_n = n^2$ ($1, 4, 9, \dots$) and eigenfunctions are $\sin(nx)$.
The code constructs the tridiagonal matrix and uses an eigenvalue solver (e.g., `numpy.linalg.eigh` in Python) to find the first few eigenvalues.
