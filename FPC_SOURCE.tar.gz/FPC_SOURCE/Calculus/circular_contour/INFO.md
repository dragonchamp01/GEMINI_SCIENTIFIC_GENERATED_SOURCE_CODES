# Circular Contour Integration (Generalized)

## Concept
Integrating a function around a circle is the most fundamental technique in complex analysis. It is used to define derivatives, calculate residues, and evaluate coefficients of Laurent series.

## Formula
A circle $C$ with center $z_0$ and radius $R$ is parameterized by:
$z(t) = z_0 + R e^{it}, \quad t \in [0, 2\pi]$
The derivative is $z'(t) = i R e^{it}$.
The integral of $f(z)$ around $C$ is:
$\oint_{C} f(z) dz = \int_{0}^{2\pi} f(z_0 + R e^{it}) i R e^{it} dt$

## Code Explanation
The provided code integrates $f(z) = z^2$ around a circle of radius 1 centered at $(1+i)$. 
Since $z^2$ is an **entire** function (it has no poles anywhere), according to Cauchy's Goursat Theorem, the integral around any closed path must be zero.
The implementation uses Simpson's rule to verify this property.
Analytical Result: 0.
