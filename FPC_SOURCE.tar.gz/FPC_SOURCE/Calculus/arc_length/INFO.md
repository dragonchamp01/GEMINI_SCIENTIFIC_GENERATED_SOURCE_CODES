# Arc Length

## Concept
The arc length of a curve is the distance between two points along a section of a curve. For a function $y = f(x)$ that is continuously differentiable on the interval $[a, b]$, the length of the curve is calculated using a definite integral.

## Formula
The arc length $L$ of the curve $y = f(x)$ from $x=a$ to $x=b$ is given by:
$L = \int_{a}^{b} \sqrt{1 + [f'(x)]^2} dx$
where $f'(x)$ is the derivative of the function.

## Code Explanation
The provided code calculates the arc length of the parabola $f(x) = x^2$ from $x=0$ to $x=1$.
Analytical derivative: $f'(x) = 2x$.
The integral to solve is: $\int_{0}^{1} \sqrt{1 + 4x^2} dx$.
The code uses Simpson's Rule to numerically evaluate this integral.
Analytical result: $\frac{1}{2}\sqrt{5} + \frac{1}{4}\ln(2 + \sqrt{5}) \approx 1.47894$.
