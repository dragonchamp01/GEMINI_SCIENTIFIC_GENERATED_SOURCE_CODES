# Double Integral (Numerical)

## Concept
Numerical double integration is used to find the volume under a surface $z = f(x, y)$ over a rectangular region $[a, b] 	imes [c, d]$. A common method is to use a nested integration approach where the inner integral is evaluated for each step of the outer integral.

## Formula
To approximate $I = \int_{a}^{b} \int_{c}^{d} f(x, y) dy dx$, we define $g(x) = \int_{c}^{d} f(x, y) dy$.
The double integral then becomes a single integral: $I = \int_{a}^{b} g(x) dx$.
Both $g(x)$ and the final integral of $g(x)$ are evaluated using numerical methods like Simpson's Rule.

## Code Explanation
The provided code approximates the double integral of $f(x, y) = x^2 + y^2$ over the region $x \in [0, 1], y \in [0, 1]$.
Analytical result: $\int_{0}^{1} \int_{0}^{1} (x^2 + y^2) dy dx = \int_{0}^{1} [x^2y + \frac{1}{3}y^3]_{0}^{1} dx = \int_{0}^{1} (x^2 + \frac{1}{3}) dx = [\frac{1}{3}x^3 + \frac{1}{3}x]_{0}^{1} = \frac{1}{3} + \frac{1}{3} = \frac{2}{3} \approx 0.666667$.
The implementation uses a nested Simpson's Rule with $N$ intervals in both $x$ and $y$ directions.
