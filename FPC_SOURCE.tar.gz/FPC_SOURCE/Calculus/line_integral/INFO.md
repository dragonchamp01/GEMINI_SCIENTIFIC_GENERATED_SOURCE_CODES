# Line Integral (Numerical)

## Concept
A line integral is an integral where the function is evaluated along a curve $C$. If $C$ is a curve parameterized by $\mathbf{r}(t) = [x(t), y(t)]$ for $t \in [a, b]$, the line integral of a scalar field $f(x, y)$ along $C$ is calculated by integrating the function with respect to the arc length.

## Formula
The line integral of $f$ over $C$ is given by:
$\int_{C} f ds = \int_{a}^{b} f(x(t), y(t)) \sqrt{\left(\frac{dx}{dt}ight)^2 + \left(\frac{dy}{dt}ight)^2} dt$

## Code Explanation
The provided code calculates the line integral of $f(x, y) = x + y$ along a circular path $C$ defined by:
$x(t) = \cos(t), y(t) = \sin(t)$ for $t \in [0, \pi/2]$ (a quarter circle).
The velocity magnitude $\sqrt{(dx/dt)^2 + (dy/dt)^2}$ for a unit circle is always 1.
Analytical result: $\int_{0}^{\pi/2} (\cos t + \sin t) (1) dt = [\sin t - \cos t]_{0}^{\pi/2} = (1 - 0) - (0 - 1) = 2.0$.
The implementation uses Simpson's Rule to evaluate the integral over $t$.
