# Calculus of Variations (Euler-Lagrange)

## Concept
The Calculus of Variations seeks to find functions $y(x)$ that minimize or maximize a functional (an integral depending on the function and its derivatives). The necessary condition for an extremum is that $y(x)$ must satisfy the Euler-Lagrange equation.

## Formula
For a functional $J[y] = \int_{a}^{b} F(x, y, y') dx$, the Euler-Lagrange equation is:
$\frac{\partial F}{\partial y} - \frac{d}{dx} \left( \frac{\partial F}{\partial y'} ight) = 0$
Numerically, we can discretize the interval $[a, b]$ into $N$ points and find the values $y_i$ that minimize the discretized integral using optimization techniques.

## Code Explanation
The provided code solves the "shortest path" problem between $(0, 0)$ and $(1, 1)$. We know the solution is a straight line $y = x$.
Functional to minimize: $J[y] = \int_{0}^{1} \sqrt{1 + (y')^2} dx$ (arc length).
The code discretizes $y(x)$ into $N$ variables and uses a gradient-based optimization (or simple iterative refinement) to minimize the total arc length while keeping endpoints fixed.
