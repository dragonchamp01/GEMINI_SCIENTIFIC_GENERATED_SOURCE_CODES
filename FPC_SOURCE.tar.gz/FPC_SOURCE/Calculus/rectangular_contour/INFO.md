# Rectangular Contour Integration

## Concept
Rectangular contour integration involves integrating a complex function $f(z)$ along a rectangular path in the complex plane. This is often used to evaluate integrals involving trigonometric functions or to isolate poles in a specific strip of the complex plane.

## Formula
A rectangular path $\Gamma$ consists of four linear segments:
1. Bottom: $z(t) = x_1 + i y_1$ to $x_2 + i y_1$
2. Right: $z(t) = x_2 + i y_1$ to $x_2 + i y_2$
3. Top: $z(t) = x_2 + i y_2$ to $x_1 + i y_2$
4. Left: $z(t) = x_1 + i y_2$ to $x_1 + i y_1$
The total integral is the sum of the line integrals along these four segments:
$\oint_{\Gamma} f(z) dz = \sum_{k=1}^{4} \int_{segment_k} f(z) dz$

## Code Explanation
The provided code integrates $f(z) = 1/z$ around a rectangle with corners at $(-1-i)$ and $(1+i)$. Since the origin (a simple pole with residue 1) is inside the rectangle, the result should be $2\pi i \approx 6.283185i$.
The implementation defines a generic line integral function and applies it to the four segments of the rectangle.
