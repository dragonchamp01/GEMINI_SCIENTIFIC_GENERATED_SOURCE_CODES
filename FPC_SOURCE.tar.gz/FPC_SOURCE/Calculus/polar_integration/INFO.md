# Polar Integration

## Concept
Integration in polar coordinates is used to calculate the area of a region bounded by a curve $r = f(	heta)$ and two rays $	heta = \alpha$ and $	heta = \beta$.

## Formula
The area $A$ of the region bounded by $r = f(	heta)$ from $	heta = \alpha$ to $	heta = \beta$ is:
$A = \int_{\alpha}^{\beta} \frac{1}{2} [f(	heta)]^2 d	heta$
This integral can be approximated using numerical methods like Simpson's Rule.

## Code Explanation
The provided code calculates the area of a cardioid defined by $r(	heta) = 1 - \cos(	heta)$ from $	heta = 0$ to $	heta = 2\pi$.
Analytical Area:
$A = \frac{1}{2} \int_{0}^{2\pi} (1 - \cos	heta)^2 d	heta = \frac{1}{2} \int_{0}^{2\pi} (1 - 2\cos	heta + \cos^2	heta) d	heta$
Using $\cos^2	heta = \frac{1 + \cos(2	heta)}{2}$, the integral evaluates to $\frac{3\pi}{2} \approx 4.712389$.
