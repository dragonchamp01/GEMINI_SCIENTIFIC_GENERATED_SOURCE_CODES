# Taylor Series (Sine Function)

## Concept
A Taylor series is an infinite sum of terms expressed in terms of the function's derivatives at a single point. For the sine function centered at $x=0$ (also known as a Maclaurin series), the series provides a polynomial approximation that becomes more accurate as more terms are added.

## Formula
The Taylor series for $\sin(x)$ is:
$\sin(x) = \sum_{n=0}^{\infty} (-1)^n \frac{x^{2n+1}}{(2n+1)!} = x - \frac{x^3}{3!} + \frac{x^5}{5!} - \frac{x^7}{7!} + \dots$

## Code Explanation
The provided code approximates $\sin(x)$ for a given $x$ using $N$ terms of the Taylor series.
It compares the result with the library's `sin(x)` function to show the approximation error.
The code demonstrates how the error decreases as the number of terms $N$ increases.
Note: For large $x$, the series converges slowly, and the values should be mapped to the $[-\pi, \pi]$ range using periodicity for better stability.
