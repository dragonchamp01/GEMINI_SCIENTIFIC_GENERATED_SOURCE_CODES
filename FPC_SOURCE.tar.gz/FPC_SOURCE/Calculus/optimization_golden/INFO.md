# Optimization (Golden Section Search)

## Concept
Golden Section Search is an optimization technique for finding the minimum or maximum of a unimodal function by successively narrowing the range of values in which the extremum exists. It uses the golden ratio $\phi \approx 1.618$ to ensure that the search interval reduces at a constant rate, regardless of which side is chosen.

## Formula
Let the search interval be $[a, b]$. Two internal points $x_1$ and $x_2$ are chosen:
$x_1 = b - (b - a) / \phi$
$x_2 = a + (b - a) / \phi$
where $\phi = (1 + \sqrt{5}) / 2 \approx 1.618$.
The function is evaluated at $x_1$ and $x_2$ to determine which sub-interval to keep, reducing the range in each iteration.

## Code Explanation
The provided code finds the minimum of the parabolic function $f(x) = (x - 2)^2 + 3$ within the interval $[0, 5]$.
Analytical minimum: $x = 2$, $f(x) = 3$.
The code performs iterations until the interval width is smaller than the specified tolerance.
