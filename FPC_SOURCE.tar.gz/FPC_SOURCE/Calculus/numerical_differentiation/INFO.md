# 數值微分 (Numerical Differentiation)

## 概念 (Concept)
數值微分是用於近似函數導數 (derivative) 的數值方法。當函數過於複雜或僅有離散數據點時，我們無法直接求得解析解，此時便需要使用數值微分。

## 公式 (Formulas)
最常用的三種近似方法（基於泰勒級數展開）：

1.  **前向差分 (Forward Difference)**:
    $f'(x) \approx \frac{f(x + h) - f(x)}{h}$
    誤差項：$O(h)$

2.  **後向差分 (Backward Difference)**:
    $f'(x) \approx \frac{f(x) - f(x - h)}{h}$
    誤差項：$O(h)$

3.  **中心差分 (Central Difference)**:
    $f'(x) \approx \frac{f(x + h) - f(x - h)}{2h}$
    誤差項：$O(h^2)$（通常更準確）

其中 $h$ 是一個非常小的步長。

## 程式碼說明 (Code Explanation)
提供的程式碼示範了如何計算 $f(x) = x^2$ 在 $x=2$ 時的導數。
理論上，$f'(x) = 2x$，因此 $f'(2) = 4$。
程式會顯示不同 $h$ 值下三種方法的準確度。
