# Steffensen's Method

## Concept
Steffensen's method is an iterative root-finding algorithm that achieves quadratic convergence, similar to Newton's method, but without requiring the derivative of the function. it is essentially an accelerated fixed-point iteration that uses Aitken's delta-squared process to speed up the convergence of a sequence.

## Formula
Given a function $f(x)$ and an initial guess $x_n$, the next approximation $x_{n+1}$ is:
$x_{n+1} = x_n - \frac{[f(x_n)]^2}{f(x_n + f(x_n)) - f(x_n)}$
This formula is derived by applying Aitken acceleration to the basic fixed-point iteration $x_{n+1} = x_n + f(x_n)$.

## Code Explanation
The provided code finds the root of $f(x) = x^2 - 2$ (to calculate $\sqrt{2}$).
The method starts with an initial guess and applies the formula until the difference between consecutive values is within the specified tolerance.
The implementation shows the rapid convergence characteristic of this method.
