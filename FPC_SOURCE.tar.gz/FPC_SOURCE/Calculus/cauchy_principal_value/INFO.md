# Cauchy Principal Value

## Concept
The Cauchy Principal Value (P.V.) is a method for assigning a value to certain improper integrals which would otherwise be undefined. This usually occurs when the integrand has a singularity within the range of integration. The principal value is found by taking a symmetric limit as we approach the singularity from both sides.

## Formula
For an integral with a singularity at $c \in (a, b)$:
$P.V. \int_{a}^{b} f(x) dx = \lim_{\epsilon 	o 0^+} \left( \int_{a}^{c-\epsilon} f(x) dx + \int_{c+\epsilon}^{b} f(x) dx ight)$

## Code Explanation
The provided code calculates the Cauchy Principal Value of $\int_{-1}^{2} \frac{1}{x} dx$.
The integrand has a singularity at $x=0$.
Analytical Result: $[\ln|x|]_{-1}^{2} = \ln(2) - \ln(1) = \ln(2) \approx 0.693147$.
The numerical implementation uses a small $\epsilon = 10^{-7}$ and sums the two sub-integrals calculated using Simpson's Rule.
