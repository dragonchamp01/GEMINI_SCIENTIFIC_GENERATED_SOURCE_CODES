# Complex Line Integral

## Concept
A complex line integral is an integral of a complex-valued function $f(z)$ along a contour $C$ in the complex plane. By parameterizing the contour as $z(t)$ for $t \in [a, b]$, the integral becomes a standard Riemann integral over a real variable.

## Formula
If $C$ is parameterized by $z(t)$, the integral is:
$\int_{C} f(z) dz = \int_{a}^{b} f(z(t)) z'(t) dt$
This results in a complex value. Numerical integration can be applied to the real and imaginary parts of the integrand $f(z(t)) z'(t)$.

## Code Explanation
The provided code calculates the integral of $f(z) = 1/z$ along a unit circle centered at the origin.
Contour: $z(t) = e^{it} = \cos(t) + i\sin(t)$ for $t \in [0, 2\pi]$.
Derivative: $z'(t) = ie^{it}$.
Analytical Result: $\oint_{C} \frac{1}{z} dz = 2\pi i \approx 6.283185i$.
This is a fundamental result from Cauchy's Residue Theorem. The implementation uses Simpson's Rule on complex values.
