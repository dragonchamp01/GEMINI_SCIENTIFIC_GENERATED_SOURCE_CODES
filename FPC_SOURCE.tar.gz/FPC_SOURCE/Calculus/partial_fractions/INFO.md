# Partial Fractions Expansion

## Concept
Partial fraction decomposition is the process of breaking down a complex rational function into a sum of simpler rational functions. This is extremely useful in calculus for integration and in control theory for inverse Laplace transforms.

## Formula
For a rational function $R(x) = \frac{P(x)}{Q(x)}$, if $Q(x)$ can be factored into linear factors, we can write:
$\frac{P(x)}{(x-a)(x-b)} = \frac{A}{x-a} + \frac{B}{x-b}$
The constants $A$ and $B$ can be found using the "Cover-up Method":
$A = \left. \frac{P(x)}{x-b} ight|_{x=a}, \quad B = \left. \frac{P(x)}{x-a} ight|_{x=b}$

## Code Explanation
The provided code performs the partial fraction decomposition for:
$R(x) = \frac{x + 7}{(x - 1)(x + 3)}$
The code calculates the coefficients $A$ and $B$ such that:
$\frac{x + 7}{(x - 1)(x + 3)} = \frac{A}{x - 1} + \frac{B}{x + 3}$
Analytical result: $A = (1+7)/(1+3) = 2$, $B = (-3+7)/(-3-1) = -1$.
The implementation handles simple linear factors.
