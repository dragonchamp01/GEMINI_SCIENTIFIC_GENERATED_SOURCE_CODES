# Triple Integral (Numerical)

## Concept
Numerical triple integration is used to find the integral of a function $f(x, y, z)$ over a 3D region, typically a rectangular box $[a, b] 	imes [c, d] 	imes [e, g]$. It is implemented as a nested integration where the inner integral is evaluated for each step of the outer integrals.

## Formula
To approximate $I = \int_{a}^{b} \int_{c}^{d} \int_{e}^{g} f(x, y, z) dz dy dx$, we define:
$h(x, y) = \int_{e}^{g} f(x, y, z) dz$
$g(x) = \int_{c}^{d} h(x, y) dy$
$I = \int_{a}^{b} g(x) dx$
Each step is evaluated using a 1D numerical integration method like Simpson's Rule.

## Code Explanation
The provided code approximates the triple integral of $f(x, y, z) = x + y + z$ over the unit cube $[0, 1] 	imes [0, 1] 	imes [0, 1]$.
Analytical result: $\int_{0}^{1} \int_{0}^{1} \int_{0}^{1} (x+y+z) dz dy dx = 1.5$.
The implementation uses nested Simpson's Rule with $N$ intervals in all directions.
