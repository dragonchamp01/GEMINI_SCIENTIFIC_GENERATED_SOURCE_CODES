# Contour Integration

## Concept
Contour integration is the process of integrating a complex-valued function $f(z)$ along a closed curve (contour) in the complex plane. According to the Residue Theorem, if a function is analytic inside and on a closed contour except for a finite number of isolated singularities (poles), the integral around the contour is $2\pi i$ times the sum of the residues at those poles.

## Formula
For a closed contour $\Gamma$:
$\oint_{\Gamma} f(z) dz = 2\pi i \sum 	ext{Res}(f, z_k)$
Numerically, we parameterize the contour $\Gamma$ by $z(t)$ for $t \in [a, b]$:
$\oint_{\Gamma} f(z) dz = \int_{a}^{b} f(z(t)) z'(t) dt$

## Code Explanation
The provided code integrates $f(z) = \frac{1}{z^2 + 1}$ along a circle of radius 1 centered at $z = i$. 
This contour encloses the pole at $z = i$ but not the pole at $z = -i$.
The residue at $z = i$ is $	ext{Res}(f, i) = \frac{1}{2i}$.
Analytical Result: $2\pi i \cdot \frac{1}{2i} = \pi \approx 3.14159$.
The implementation uses Simpson's rule to integrate the parameterized path.
