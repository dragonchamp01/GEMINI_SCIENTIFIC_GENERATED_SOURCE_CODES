# Neville's Iterated Interpolation

## Concept
Neville's algorithm is a method used for evaluating the interpolating polynomial at a specific point $x$ without explicitly calculating the polynomial's coefficients. It is based on the recursive property of Lagrange polynomials.

## Formula
Let $P_{i, j}(x)$ denote the polynomial interpolating the points $(x_i, y_i), \dots, (x_j, y_j)$.
The recurrence relation is:
$P_{i, i}(x) = y_i$
$P_{i, j}(x) = \frac{(x - x_j)P_{i, j-1}(x) - (x - x_i)P_{i+1, j}(x)}{x_i - x_j}$
The final result for $n$ points is $P_{0, n-1}(x)$.

## Code Explanation
The provided code interpolates the function $f(x) = \ln(x)$ using points at $x = 1.0, 1.5, 2.0$.
It evaluates the estimated value at $x = 1.25$.
Analytical value: $\ln(1.25) \approx 0.22314$.
The algorithm builds a "tableau" (table) of approximations, where the last entry is the most accurate.
