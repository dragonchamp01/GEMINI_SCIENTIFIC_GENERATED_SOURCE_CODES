# Trapezoidal Rule

## Concept
The Trapezoidal Rule is a numerical integration method used to approximate the definite integral of a function. It works by approximating the region under the graph of the function as a series of trapezoids rather than rectangles.

## Formula
For a function $f(x)$ on the interval $[a, b]$ divided into $n$ equal sub-intervals of width $h = \frac{b-a}{n}$:
$\int_{a}^{b} f(x) dx \approx \frac{h}{2} \left[ f(x_0) + 2f(x_1) + 2f(x_2) + \dots + 2f(x_{n-1}) + f(x_n) ight]$
where $x_i = a + i \cdot h$.

## Code Explanation
The provided code approximates the integral of $f(x) = x^2$ from $a=0$ to $b=1$.
Analytical result: $\int_{0}^{1} x^2 dx = [\frac{1}{3}x^3]_{0}^{1} = \frac{1}{3} \approx 0.333333$.
The program allows you to see how increasing the number of intervals ($n$) improves the approximation.
