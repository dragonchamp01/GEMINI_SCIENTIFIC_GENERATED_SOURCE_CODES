# Not-a-Knot Cubic Spline Interpolation

## Concept
The "Not-a-Knot" spline is a cubic spline where we assume the third derivative is continuous at the first and last internal knots ($x_1$ and $x_{n-1}$). This effectively means the first two intervals and the last two intervals are governed by the same cubic polynomial, hence the "knot" is not really a knot.

## Formula
For a spline with $n$ intervals, we have $n+1$ points. The not-a-knot conditions are:
$S'''_0(x_1) = S'''_1(x_1)$
$S'''_{n-2}(x_{n-1}) = S'''_{n-1}(x_{n-1})$
This eliminates the need for user-specified boundary conditions (like Natural or Clamped) while maintaining a smooth and accurate curve. It requires at least 4 data points.

## Code Explanation
The provided code implements the not-a-knot condition by adjusting the first and last rows of the tridiagonal system.
Because the not-a-knot condition involves 4 points ($x_0, x_1, x_2, x_3$), the resulting matrix is "almost" tridiagonal (the first and last rows have an extra non-zero element).
The code implements a solver for this specialized system to find the $c_i$ coefficients.
