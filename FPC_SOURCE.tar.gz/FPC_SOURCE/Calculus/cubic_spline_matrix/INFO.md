# Cubic Spline Interpolation (Natural)

## Concept
A cubic spline is a piecewise polynomial function of degree 3 that interpolates a set of data points. "Natural" means the second derivative at the endpoints is set to zero. This method constructs a smooth curve that passes through all data points.

## Formula
For $n+1$ points $(x_0, y_0), \dots, (x_n, y_n)$, we seek polynomials $S_i(x)$ on $[x_i, x_{i+1}]$ such that:
$S_i(x) = a_i + b_i(x-x_i) + c_i(x-x_i)^2 + d_i(x-x_i)^3$
The coefficients $c_i$ are found by solving a tridiagonal linear system $Ac = h$, where $A$ is a matrix derived from continuity conditions of $S''(x)$.
Once $c_i$ are known, $b_i$ and $d_i$ are computed directly.

## Code Explanation
The provided code interpolates the points $(0, 0), (1, 1), (2, 0), (3, 1)$ using a natural cubic spline.
It builds the tridiagonal matrix, solves for the curvature coefficients $c$, and evaluates the spline at $x=1.5$.
The code implements a tridiagonal solver (Thomas algorithm) for efficiency.
