# Simpson's 1/3 Rule

## Concept
Simpson's 1/3 rule is a method for numerical integration that provides a more accurate approximation of a definite integral than the Trapezoidal Rule. It approximates the function using quadratic polynomials (parabolas) over pairs of sub-intervals.

## Formula
For a function $f(x)$ on the interval $[a, b]$ divided into $n$ equal sub-intervals (where $n$ must be an **even** number) of width $h = \frac{b-a}{n}$:
$\int_{a}^{b} f(x) dx \approx \frac{h}{3} \left[ f(x_0) + 4 \sum_{i=1,3,\dots}^{n-1} f(x_i) + 2 \sum_{i=2,4,\dots}^{n-2} f(x_i) + f(x_n) ight]$

## Code Explanation
The provided code approximates the integral of $f(x) = \sin(x)$ from $a=0$ to $b=\pi$.
Analytical result: $\int_{0}^{\pi} \sin(x) dx = [-\cos(x)]_{0}^{\pi} = -(-1) - (-1) = 2.0$.
The program ensures $n$ is even and calculates the approximation and the error relative to the exact value.
