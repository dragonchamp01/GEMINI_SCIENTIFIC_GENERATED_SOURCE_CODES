# Periodic Cubic Spline Interpolation

## Concept
A Periodic Cubic Spline is used for periodic data where the function and its derivatives match at the boundary $x_0$ and $x_n$. This implies $S(x_0) = S(x_n)$, $S'(x_0) = S'(x_n)$, and $S''(x_0) = S''(x_n)$. 

## Formula
The periodicity condition $S''(x_0) = S''(x_n)$ means $c_0 = c_n$. The continuity of the first derivative at the boundary leads to a "cyclic" tridiagonal system:
$h_{n-1} c_{n-1} + 2(h_{n-1} + h_0) c_0 + h_0 c_1 = 3 \left( \frac{y_1 - y_0}{h_0} - \frac{y_0 - y_{n-1}}{h_{n-1}} ight)$
where $y_{n}$ is replaced by $y_0$. This results in a matrix with non-zero elements at the top-right and bottom-left corners.

## Code Explanation
The provided code interpolates a periodic dataset representing a simplified sine wave. It constructs the cyclic tridiagonal matrix and solves for the $c_i$ coefficients. The implementation includes a solver for cyclic tridiagonal systems (Sherman-Morrison formula or general solver).
