# Romberg Integration

## Concept
Romberg Integration is a powerful numerical integration method that combines the Trapezoidal Rule with Richardson Extrapolation to achieve high-order accuracy with fewer function evaluations. It builds a triangular "Romberg Table" where each row represents a higher order of accuracy.

## Formula
Starting with $R(n, 1)$ as the Trapezoidal Rule result with $2^{n-1}$ intervals, higher-order estimates are calculated as:
$R(n, m) = R(n, m-1) + \frac{R(n, m-1) - R(n-1, m-1)}{4^{m-1} - 1}$
where $m > 1$ is the order of extrapolation.

## Code Explanation
The provided code approximates the integral of $f(x) = \frac{4}{1+x^2}$ from $0$ to $1$.
Analytical result: $\int_{0}^{1} \frac{4}{1+x^2} dx = [4 \arctan(x)]_{0}^{1} = 4(\pi/4) = \pi \approx 3.1415926535$.
The code displays the Romberg table and the final approximation of $\pi$.
