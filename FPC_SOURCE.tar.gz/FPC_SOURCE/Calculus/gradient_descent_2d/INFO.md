# Gradient Descent (2D)

## Concept
Gradient descent is an iterative optimization algorithm used to find the minimum of a function. In 2D, the algorithm moves in the direction of the steepest descent (the negative of the gradient) from the current point.

## Formula
For a function $f(x, y)$, the update rule for the coordinates $(x, y)$ is:
$x_{new} = x_{old} - \alpha \frac{\partial f}{\partial x}$
$y_{new} = y_{old} - \alpha \frac{\partial f}{\partial y}$
where $\alpha$ is the learning rate.

## Code Explanation
The provided code finds the minimum of the function $f(x, y) = (x - 3)^2 + (y + 2)^2 + 5$.
The minimum is analytically at $(3, -2)$ with $f(3, -2) = 5$.
The partial derivatives are:
$\frac{\partial f}{\partial x} = 2(x - 3)$
$\frac{\partial f}{\partial y} = 2(y + 2)$
The code iterates until the gradient magnitude is below a threshold.
