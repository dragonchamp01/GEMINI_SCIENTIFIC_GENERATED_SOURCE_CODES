# Muller's Method

## Concept
Muller's method is an iterative root-finding algorithm that generalizes the Secant method. While the Secant method uses a linear interpolant (a line) through two points, Muller's method uses a quadratic interpolant (a parabola) through three points. This allows the method to find complex roots and typically converges faster than the Secant method.

## Formula
Given three points $(x_0, x_1, x_2)$, we find the coefficients $a, b, c$ of the parabola $P(x) = a(x - x_2)^2 + b(x - x_2) + c$ that passes through them. The next approximation $x_3$ is the root of this parabola closest to $x_2$:
$x_3 = x_2 - \frac{2c}{b \pm \sqrt{b^2 - 4ac}}$
The sign in the denominator is chosen to maximize the magnitude, ensuring stability.

## Code Explanation
The provided code finds a root of the polynomial $f(x) = x^3 - x - 1$.
It handles complex arithmetic to allow finding complex roots if necessary.
The implementation starts with three initial guesses and iterates until the change in $x$ is within the specified tolerance.
