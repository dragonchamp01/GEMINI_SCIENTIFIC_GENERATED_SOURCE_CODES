# Adaptive Simpson's Rule

## Concept
Adaptive Simpson's Rule is a recursive algorithm that automatically adjusts the step size to achieve a desired level of accuracy. It uses Simpson's Rule on the whole interval $[a, b]$ and compares it to the sum of Simpson's Rule on two halves $[a, c]$ and $[c, b]$.

## Formula
Let $S(a, b)$ be the Simpson's rule approximation on $[a, b]$.
Let $S(a, c) + S(c, b)$ be the approximation using two halves, where $c = (a+b)/2$.
If $|S(a, b) - (S(a, c) + S(c, b))| < 15 \cdot \epsilon$, then the approximation is considered accurate enough.
Otherwise, the function recursively subdivides the intervals.

## Code Explanation
The provided code approximates the integral of $f(x) = \sin(x^2)$ from $0$ to $\sqrt{\pi}$.
This is a Fresnel integral, which oscillates more rapidly as $x$ increases, making it a good candidate for adaptive methods.
Analytically, the result involves Fresnel functions, but numerically we aim for high precision.
