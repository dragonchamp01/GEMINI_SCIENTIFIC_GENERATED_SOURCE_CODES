# Newton Interpolation

## Concept
Newton Interpolation is a method for finding a polynomial that passes through a given set of data points $(x_i, y_i)$. It uses the concept of "Divided Differences" to construct the polynomial in a way that adding a new data point only requires adding one more term, making it more efficient than Lagrange interpolation for growing datasets.

## Formula
The Newton form of the interpolating polynomial $P_n(x)$ is:
$P_n(x) = f[x_0] + f[x_0, x_1](x - x_0) + f[x_0, x_1, x_2](x - x_0)(x - x_1) + \dots$
The coefficients $f[x_0, \dots, x_k]$ are calculated using divided differences:
$f[x_i, x_{i+1}, \dots, x_k] = \frac{f[x_{i+1}, \dots, x_k] - f[x_i, \dots, x_{k-1}]}{x_k - x_i}$

## Code Explanation
The provided code interpolates a set of 4 data points representing the function $f(x) = \sin(x)$ at $x = 0, \pi/4, \pi/2, 3\pi/4$.
It constructs the divided difference table and evaluates the polynomial at a test point $x = \pi/3 \approx 1.047$.
Analytical value: $\sin(\pi/3) = \sqrt{3}/2 \approx 0.866$.
The code shows how to store the table and compute the final value.
