# Numerical Limits

## Concept
In calculus, a limit is the value that a function (or sequence) approaches as the input (or index) approaches some value.
Numerically, we can approximate the limit of a function $f(x)$ as $x 	o a$ by evaluating the function at points getting closer and closer to $a$ (e.g., $a+h, a+h/2, a+h/4, \dots$ for small $h$).

## Formula
For a limit $L = \lim_{x 	o a} f(x)$, we can approximate it by computing:
$L \approx f(a + h)$
for a very small $h$. However, due to floating-point precision errors (cancellation error), making $h$ too small can lead to inaccuracies. A common approach is to compute a sequence of approximations with decreasing $h$ and observing convergence.

## Code Explanation
The provided code demonstrates how to numerically approximate the limit of:
$f(x) = \frac{\sin(x)}{x}$ as $x 	o 0$.
We know analytically that this limit is 1.

The code evaluates $f(x)$ at $x = 1.0, 0.1, 0.01, \dots$ to show the convergence towards 1.
