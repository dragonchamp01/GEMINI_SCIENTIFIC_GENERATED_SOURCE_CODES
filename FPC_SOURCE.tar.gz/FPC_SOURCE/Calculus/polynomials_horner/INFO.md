# Polynomials (Horner's Method)

## Concept
Horner's Method is an efficient algorithm for evaluating polynomials at a specific point. It significantly reduces the number of multiplications required by restructuring the polynomial. It can also be used to evaluate the derivative of a polynomial simultaneously.

## Formula
A polynomial $P(x) = a_n x^n + a_{n-1} x^{n-1} + \dots + a_1 x + a_0$ can be rewritten as:
$P(x) = a_0 + x(a_1 + x(a_2 + \dots + x(a_{n-1} + x a_n)\dots))$
The evaluation starts from the highest coefficient $a_n$ and moves downwards:
$b_n = a_n$
$b_k = a_k + b_{k+1} x$ for $k = n-1, \dots, 0$
Then $P(x) = b_0$.

## Code Explanation
The provided code evaluates the polynomial $P(x) = 2x^3 - 6x^2 + 2x - 1$ at $x = 3$.
It also calculates the derivative $P'(x)$ at the same point using the intermediate results of Horner's method.
The implementation shows how to handle coefficients as an array or list.
