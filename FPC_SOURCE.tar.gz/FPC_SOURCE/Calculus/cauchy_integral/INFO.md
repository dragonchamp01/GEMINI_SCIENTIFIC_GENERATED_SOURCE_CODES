# Cauchy's Integral Formula

## Concept
Cauchy's Integral Formula states that the values of a holomorphic function $f(z)$ inside a disk are completely determined by its values on the boundary of the disk. This formula is a cornerstone of complex analysis and demonstrates the extreme rigidity of complex-differentiable functions.

## Formula
If $f(z)$ is holomorphic in an open set containing a closed disk $D$ and $\Gamma$ is the boundary of $D$, then for any $a$ in the interior of $D$:
$f(a) = \frac{1}{2\pi i} \oint_{\Gamma} \frac{f(z)}{z - a} dz$

## Code Explanation
The provided code uses Cauchy's formula to calculate the value of $f(a) = e^a$ at $a = 0.5 + 0.5i$.
We integrate $\frac{e^z}{z - a}$ along a circle of radius 2 centered at the origin.
The numerical result is compared with the analytical value $e^{0.5 + 0.5i}$.
The code implements Simpson's integration on the complex function along the circular path.
