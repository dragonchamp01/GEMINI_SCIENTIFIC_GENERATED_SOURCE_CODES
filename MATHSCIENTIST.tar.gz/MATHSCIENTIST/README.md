# MathScientist: Universal Math & Calculus SDK (v1.0)

Welcome to the **MathScientist SDK**, a high-performance, multi-language library designed for University level Mathematics, Calculus, and Numerical Analysis.

## 🚀 Design Philosophy
MathScientist bridges the gap between theoretical equations and machine implementation. It is structured into four distinct layers:
1. **Python (High-Level)**: Symbolic-ready API for research and prototyping.
2. **C++ (Performance)**: Header-only template library for high-throughput simulations.
3. **Free Pascal (Educational)**: Object-oriented units for structured learning.
4. **NASM (Low-Level)**: AVX-optimized micro-kernels for extreme numerical speed.

## 📂 SDK Modules
- **Calculus**: RK4 ODE solvers, numerical differentiation (5-point), Adaptive Simpson integration.
- **Linear Algebra**: Matrix templates, LU/QR decomposition, SVD, Eigen-solvers.
- **PDE/FEM**: 1D/2D Heat & Wave equations, Finite Element Method.
- **Complex Analysis**: Z-Transform, Cauchy Formula, Residue calculation.
- **Statistics**: Multiple Regression, ANOVA, K-S Tests, Bayesian Inference.
- **Discrete Math**: Dijkstra Graph paths, Truth Table generation, RSA logic.

## 🛠️ Installation & Building
### C++ Core
```bash
cd MATHSCIENTIST/CPP
make
./examples/eigen_demo
```
### Free Pascal
```bash
cd MATHSCIENTIST/FPC
make
./examples/ode_demo
```
### Python
```bash
export PYTHONPATH=$PYTHONPATH:/path/to/MATHSCIENTIST/Python
python3 examples/pde_demo.py
```

## 🧠 Processor Gemini's Insights
Every algorithm in this SDK is verified against textbook analytical solutions. Whether you are simulating the vibration of a drum (2D Wave) or analyzing the curvature of a manifold, MathScientist provides the precision and performance required for modern science.

---
*Created by Gemini CLI - Neo Expert Agent.*
