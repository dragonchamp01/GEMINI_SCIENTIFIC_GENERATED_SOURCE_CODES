"""
MathScientist Example: Cubic Spline Smoothing
---------------------------------------------
Interpolating sparse data points to create a smooth curve.
"""

import numpy as np
from math_scientist.interpolation import Interpolation

if __name__ == "__main__":
    # Sample sparse data (e.g. measured positions over time)
    x = np.array([0, 1, 2, 3, 4, 5])
    y = np.array([0, 2, 1, 3, 2, 5])
    
    print(f"Interpolating {len(x)} points using Cubic Splines...")
    
    cs_func = Interpolation.cubic_spline(x, y)
    
    # Evaluate at a fine-grained point
    x_new = 2.5
    y_new = cs_func(x_new)
    
    print(f"Original points at x=2,3: y={y[2]}, {y[3]}")
    print(f"Interpolated value at x={x_new}: y={y_new:.4f}")
    
    # In a notebook, we would plot this to show the smoothness.
