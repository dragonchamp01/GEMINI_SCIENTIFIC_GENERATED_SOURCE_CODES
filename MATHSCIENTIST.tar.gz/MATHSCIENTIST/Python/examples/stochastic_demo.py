"""
MathScientist Example: Brownian Motion Simulation
--------------------------------------------------
Simulating a 1D random walk / Wiener process.
"""

import numpy as np

def simulate_wiener(T, N):
    """
    T: Total time, N: steps.
    """
    dt = T/N
    steps = np.random.normal(0, np.sqrt(dt), N)
    path = np.cumsum(steps)
    return np.insert(path, 0, 0)

if __name__ == "__main__":
    time_total = 1.0
    num_steps = 1000
    
    print(f"Simulating Brownian Motion path with {num_steps} steps...")
    traj = simulate_wiener(time_total, num_steps)
    
    print(f"Final displacement: {traj[-1]:.4f}")
    print(f"Theoretical variance (T): {time_total}")
    print(f"Empirical variance:       {np.var(traj):.4f}")
