"""
MathScientist Example: Medical Classification
---------------------------------------------
Classifying tumors based on size and age using Logistic Regression.
"""

import numpy as np
from math_scientist.stats_adv import LogisticRegression

if __name__ == "__main__":
    # Features: [Size (cm), Age]
    X = np.array([[1, 20], [2, 25], [1.5, 30], [5, 60], [6, 65], [5.5, 70]])
    # Labels: 0 (Benign), 1 (Malignant)
    y = np.array([0, 0, 0, 1, 1, 1])
    
    print("Training Logistic Regression on sample medical data...")
    w, b = LogisticRegression.fit(X, y, lr=0.01, iters=5000)
    
    # Predict for a new patient
    new_patient = np.array([4.5, 55])
    prob = LogisticRegression.sigmoid(np.dot(new_patient, w) + b)
    
    print(f"New patient features: {new_patient}")
    print(f"Probability of Malignancy: {prob:.4f}")
    print("Result: " + ("Malignant" if prob > 0.5 else "Benign"))
