"""
MathScientist Example: Quantum Expectation Value
-------------------------------------------------
Computing <x> for a normalized Gaussian wavepacket.
"""

import numpy as np
from math_scientist.calculus import Calculus

def psi_gauss(x):
    # Normalized Gaussian centered at x=2.0
    sigma = 0.5
    return (1.0 / (sigma * np.sqrt(2 * np.pi))**0.5) * np.exp(-(x - 2.0)**2 / (4 * sigma**2))

if __name__ == "__main__":
    # Integration range
    a, b = -5.0, 5.0
    
    # Integrand for expectation value <x>: x * |psi(x)|^2
    def integrand(x):
        return x * (np.abs(psi_gauss(x))**2)
    
    print("Calculating expectation value <x> for Gaussian centered at 2.0...")
    expect_x = Calculus.integrate_gauss(integrand, a, b)
    
    print(f"Calculated <x>: {expect_x:.6f}")
    print(f"Expected <x>:   2.000000")
    print(f"Error:          {abs(expect_x - 2.0):.2e}")
