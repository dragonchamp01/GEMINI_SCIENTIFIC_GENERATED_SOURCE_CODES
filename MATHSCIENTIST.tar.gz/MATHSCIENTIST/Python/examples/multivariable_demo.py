"""
MathScientist Example: Multivariable Analysis
---------------------------------------------
f(x, y) = x^2 + y^2 + xy
Gradient: [2x+y, 2y+x]
Hessian: [[2, 1], [1, 2]]
"""

import numpy as np
from math_scientist.multivariable import MultivariableCalculus

def f_scalar(p):
    x, y = p
    return x**2 + y**2 + x*y

if __name__ == "__main__":
    point = [1.0, 1.0]
    
    H = MultivariableCalculus.hessian(f_scalar, point)
    
    print(f"Analyzing scalar field at {point}")
    print("Hessian Matrix:
", H)
    
    # Check eigenvalues of Hessian for stability
    evals = np.linalg.eigvals(H)
    print("Eigenvalues of Hessian:", evals)
    if np.all(evals > 0):
        print("Point is a local minimum (Positive Definite).")
