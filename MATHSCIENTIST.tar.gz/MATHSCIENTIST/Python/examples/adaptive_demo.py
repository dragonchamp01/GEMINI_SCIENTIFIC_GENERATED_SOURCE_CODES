"""
MathScientist Example: Oscillatory Integration
----------------------------------------------
Function: f(x) = sin(1/x)
This function requires dense sampling near x=0.
"""

import numpy as np
from math_scientist.adaptive_integration import AdaptiveIntegrator

def tricky_func(x):
    return np.sin(1.0 / x)

if __name__ == "__main__":
    a, b = 0.1, 1.0
    tol = 1e-6
    
    print(f"Integrating sin(1/x) from {a} to {b}...")
    res = AdaptiveIntegrator.integrate(tricky_func, a, b, tol)
    
    print(f"Result: {res:.8f}")
    print("Adaptive Simpson automatically concentrated points where the oscillations are densest.")
