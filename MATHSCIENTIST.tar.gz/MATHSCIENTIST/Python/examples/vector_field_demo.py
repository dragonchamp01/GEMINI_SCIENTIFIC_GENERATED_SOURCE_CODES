"""
MathScientist Example: Vector Field Analysis
--------------------------------------------
Field F = (-y, x, 0)
Expected Curl: (0, 0, 2)
Expected Div: 0
"""

import numpy as np
from math_scientist.vector_calculus import VectorCalculus

def my_field(p):
    return np.array([-p[1], p[0], 0.0])

if __name__ == "__main__":
    pos = [1.0, 1.0, 0.0]
    
    div = VectorCalculus.divergence(my_field, pos)
    curl = VectorCalculus.curl_3d(my_field, pos)
    
    print(f"Analyzing Field F = (-y, x, 0) at {pos}")
    print(f"Divergence: {div:.4f} (Expected: 0.0)")
    print(f"Curl:       {curl} (Expected: [0, 0, 2])")
