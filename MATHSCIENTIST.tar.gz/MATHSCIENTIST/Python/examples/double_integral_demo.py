"""
MathScientist Example: Double Integral (Volume)
-----------------------------------------------
Calculating the volume of a hemisphere of radius 1.
Exact value: (2/3) * pi approx 2.0944
"""

import numpy as np
from math_scientist.multi_integral import MultiIntegrator

def hemisphere(x, y):
    r2 = x**2 + y**2
    return np.where(r2 <= 1.0, np.sqrt(1.0 - r2), 0.0)

if __name__ == "__main__":
    # Integration over a square [-1, 1] x [-1, 1]
    # The function handles the circular domain by returning 0 outside.
    res = MultiIntegrator.integrate_2d(hemisphere, -1, 1, -1, 1, nx=200, ny=200)
    
    theoretical = (2.0/3.0) * np.pi
    print(f"Numerical Integral: {res:.6f}")
    print(f"Theoretical Value:  {theoretical:.6f}")
    print(f"Absolute Error:     {abs(res - theoretical):.2e}")
