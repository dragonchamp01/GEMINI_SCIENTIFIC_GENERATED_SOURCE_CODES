"""
MathScientist Example: PDE Stability
------------------------------------
Finding the fastest stable simulation parameters for a copper rod.
"""

from math_scientist.stability import StabilityAnalysis

if __name__ == "__main__":
    # Thermal diffusivity of copper approx 1.11e-4 m^2/s
    alpha_copper = 1.11e-4
    dx = 0.01 # 1cm grid
    
    max_dt = StabilityAnalysis.get_max_dt_heat(alpha_copper, dx)
    
    print(f"Copper Rod Simulation (dx={dx}m)")
    print(f"Maximum stable time step: {max_dt:.4f} seconds")
    
    # Test a specific dt
    dt_test = 0.5
    stable, r = StabilityAnalysis.check_heat_stability(alpha_copper, dx, dt_test)
    print(f"Testing dt={dt_test}s: Stable={stable} (r={r:.4f})")
