"""
MathScientist Example: Perceptron Learning
------------------------------------------
Training a Perceptron to solve the OR gate logic.
"""

import numpy as np
from math_scientist.machine_learning import Perceptron

if __name__ == "__main__":
    # Training data: OR gate
    X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
    y = np.array([0, 1, 1, 1])
    
    print("Training Perceptron on OR gate data...")
    p = Perceptron(learning_rate=0.1, n_iters=10)
    p.fit(X, y)
    
    test_data = np.array([[0, 0], [1, 1]])
    predictions = p.predict(test_data)
    
    print(f"Prediction for {test_data[0]}: {predictions[0]} (Expected: 0)")
    print(f"Prediction for {test_data[1]}: {predictions[1]} (Expected: 1)")
