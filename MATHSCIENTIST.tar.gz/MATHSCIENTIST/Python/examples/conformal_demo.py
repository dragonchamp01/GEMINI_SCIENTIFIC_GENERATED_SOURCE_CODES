"""
MathScientist Example: Conformal Mapping (Joukowski)
----------------------------------------------------
Mapping a circle in the complex plane to an airfoil-like shape.
"""

import numpy as np
from math_scientist.conformal import ConformalMapping

if __name__ == "__main__":
    # Define a circle slightly offset from the origin
    theta = np.linspace(0, 2 * np.pi, 100)
    center = -0.1 + 0.1j
    radius = 1.1
    circle = center + radius * np.exp(1j * theta)
    
    print(f"Applying Joukowski transform to circle centered at {center}...")
    
    # Apply transform
    airfoil = ConformalMapping.joukowski_transform(circle)
    
    print("Transformation Complete.")
    print(f"First 3 points of transformed curve:
{airfoil[:3]}")
    print("In a visual environment, this would display a classic aerodynamic profile.")
