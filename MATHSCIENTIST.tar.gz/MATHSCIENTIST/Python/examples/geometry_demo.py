"""
MathScientist Example: Mesh Generation
--------------------------------------
Using Delaunay Triangulation to create a simulation mesh.
"""

import numpy as np
from math_scientist.geometry import GeometryCore

if __name__ == "__main__":
    # Random points in a unit square
    n_points = 50
    points = np.random.rand(n_points, 2)
    
    print(f"Generating mesh for {n_points} points...")
    triangles = GeometryCore.generate_triangulation(points)
    
    print(f"Mesh created with {len(triangles)} triangular elements.")
    print(f"First element node indices: {triangles[0]}")
    
    # In a visual environment, this would be plotted as a high-quality mesh.
