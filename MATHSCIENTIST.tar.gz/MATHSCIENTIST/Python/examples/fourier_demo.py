"""
MathScientist Example: Spectrum Analysis
----------------------------------------
Signal: sin(2*pi*5*t) + 0.5*sin(2*pi*12*t)
"""

import numpy as np
from math_scientist.fourier import FourierTransform

if __name__ == "__main__":
    fs = 100  # Sampling frequency
    t = np.linspace(0, 1, fs, endpoint=False)
    # 5Hz and 12Hz components
    signal = np.sin(2 * np.pi * 5 * t) + 0.5 * np.sin(2 * np.pi * 12 * t)
    
    print(f"Analyzing signal with {fs} samples...")
    X = FourierTransform.dft(signal)
    
    # Get magnitudes
    freqs = np.fft.fftfreq(fs, 1/fs)
    magnitudes = np.abs(X)
    
    # Find top 2 peaks
    indices = np.argsort(magnitudes)[-4:] # Double sided symmetric peaks
    top_freqs = sorted(np.abs(freqs[indices]))
    
    print("Detected primary frequencies:")
    for f in sorted(list(set(np.round(top_freqs)))):
        if f > 0: print(f" -> {f} Hz")
