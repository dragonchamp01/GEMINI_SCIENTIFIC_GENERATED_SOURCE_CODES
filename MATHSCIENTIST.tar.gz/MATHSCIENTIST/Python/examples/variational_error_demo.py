"""
MathScientist Example: Shortest Path Verification
-------------------------------------------------
Functional: S = Integral( sqrt(1 + y'^2) dx )
Lagrangian: L = sqrt(1 + y'^2)
"""

import numpy as np
from math_scientist.variational_analysis import VariationalValidator

def L_shortest_path(y, y_dot, x):
    return np.sqrt(1 + y_dot**2)

if __name__ == "__main__":
    x_grid = np.linspace(0, 1, 100)
    
    # Path 1: Straight line y = x (Ideal solution)
    y_straight = x_grid
    
    # Path 2: Parabola y = x^2 (Sub-optimal path)
    y_curved = x_grid**2
    
    err_ideal = VariationalValidator.compute_path_error(L_shortest_path, y_straight, x_grid)
    err_sub = VariationalValidator.compute_path_error(L_shortest_path, y_curved, x_grid)
    
    print(f"Residual analysis for path y=x:   {err_ideal:.2e} (Expected: 0)")
    print(f"Residual analysis for path y=x^2: {err_sub:.4f}")
    print("Lower residual indicates closer proximity to the optimal trajectory.")
