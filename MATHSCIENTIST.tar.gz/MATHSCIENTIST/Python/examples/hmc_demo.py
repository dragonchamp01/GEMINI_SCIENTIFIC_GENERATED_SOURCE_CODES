"""
MathScientist Example: HMC Sampling
-----------------------------------
Sampling from a multivariate normal distribution.
"""

import numpy as np
from math_scientist.hmc import HMCSampler

def log_p(q):
    return -0.5 * np.sum(q**2)

def grad_log_p(q):
    return -q

if __name__ == "__main__":
    current_q = np.array([1.0, 1.0])
    samples = []
    
    print("Running HMC Sampler for 1000 iterations...")
    for _ in range(1000):
        current_q = HMCSampler.sample(log_p, grad_log_p, current_q, 1.0, 0.1)
        samples.append(current_q)
        
    samples = np.array(samples)
    print(f"Sample Mean: {np.mean(samples, axis=0)}")
    print(f"Sample Std:  {np.std(samples, axis=0)}")
    print("Expected Mean: [0, 0], Std: [1, 1]")
