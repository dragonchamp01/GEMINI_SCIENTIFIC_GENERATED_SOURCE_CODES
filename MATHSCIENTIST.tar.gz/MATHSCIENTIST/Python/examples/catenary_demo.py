"""
MathScientist Example: Catenary Simulation
------------------------------------------
Modeling a 100m cable with a 20m sag.
"""

import numpy as np
from math_scientist.variational_adv import VariationalAdvanced

if __name__ == "__main__":
    span = 100.0
    sag = 20.0
    
    print(f"Calculating Catenary for span={span}m and sag={sag}m...")
    x, y = VariationalAdvanced.get_catenary_curve(span, sag)
    
    print(f"Cable center height: {np.min(y):.4f}m")
    print(f"Cable end height:    {np.max(y):.4f}m")
    
    # Verify the arc length
    dx = np.diff(x)
    dy = np.diff(y)
    length = np.sum(np.sqrt(dx**2 + dy**2))
    print(f"Total Cable Length:  {length:.4f}m")
