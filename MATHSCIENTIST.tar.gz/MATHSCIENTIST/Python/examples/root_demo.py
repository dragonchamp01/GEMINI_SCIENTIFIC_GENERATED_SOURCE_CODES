"""
MathScientist Example: Transcendental Equation
----------------------------------------------
Solving x - cos(x) = 0
Derivative: 1 + sin(x)
"""

import numpy as np
from math_scientist.root_finding import RootFinder

def f(x): return x - np.cos(x)
def df(x): return 1 + np.sin(x)

if __name__ == "__main__":
    x0 = 0.5
    root = RootFinder.newton_raphson(f, df, x0)
    
    print(f"Solving x = cos(x) with initial guess {x0}")
    print(f"Root found: {root:.10f}")
    print(f"Verification f(root): {f(root):.2e}")
