"""
MathScientist Example: 1D Heat Diffusion
----------------------------------------
Simulating heat spread in a 1-meter rod with a hot center.
"""

import numpy as np
from math_scientist.pde import PDESolver

if __name__ == "__main__":
    nx = 50
    L = 1.0
    u0 = np.zeros(nx)
    u0[nx//4 : 3*nx//4] = 100.0 # Hot middle section
    
    alpha = 0.01
    time = 0.5
    steps = 1000
    
    print(f"Starting Heat Simulation (L={L}m, alpha={alpha})...")
    u_final = PDESolver.solve_heat_1d(u0, alpha, L, time, nx, steps)
    
    print("Final Temperature at center:", round(u_final[nx//2], 2), "degrees")
    print("Edge temperatures (BC):", u_final[0], u_final[-1])
