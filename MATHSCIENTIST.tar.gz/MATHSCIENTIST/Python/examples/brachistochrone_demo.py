"""
MathScientist Example: Brachistochrone vs Straight Line
------------------------------------------------------
Comparing time taken for a particle to fall along different paths.
"""

import numpy as np
from math_scientist.mechanics import Mechanics

if __name__ == "__main__":
    target_x, target_y = 5.0, 2.0
    
    print(f"Generating optimal path to ({target_x}, {target_y})...")
    x_path, y_path = Mechanics.get_brachistochrone_path(target_x, target_y)
    
    # Calculate travel time T = integral( sqrt((1+y'^2)/2gy) dx )
    g = 9.81
    dy = np.diff(y_path)
    dx = np.diff(x_path)
    
    # Avoid y=0 singularity
    y_safe = y_path[1:]
    dt = np.sqrt((dx**2 + dy**2) / (2 * g * y_safe))
    total_time = np.sum(dt)
    
    # Compare with straight line
    straight_time = np.sqrt(2 * (target_x**2 + target_y**2) / (g * target_y))
    
    print(f"Time along Brachistochrone: {total_time:.4f} s")
    print(f"Time along Straight Line:   {straight_time:.4f} s")
    print(f"Time Saved:                 {straight_time - total_time:.4f} s")
