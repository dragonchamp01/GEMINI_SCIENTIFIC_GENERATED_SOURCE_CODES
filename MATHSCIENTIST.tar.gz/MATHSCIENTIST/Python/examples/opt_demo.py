"""
MathScientist Example: Function Minimization
--------------------------------------------
Minimizing f(x) = x^4 - 3x^3 + 2
Gradient f'(x) = 4x^3 - 9x^2
"""

from math_scientist.optimization import Optimizer

def grad_f(x):
    return 4 * x**3 - 9 * x**2

if __name__ == "__main__":
    start_point = 2.0
    # True minimum is at x = 2.25
    result = Optimizer.gradient_descent(grad_f, start_point, learning_rate=0.05)
    
    print(f"Starting point: {start_point}")
    print(f"Minimum found at x = {result:.4f}")
    print(f"Expected minimum: 2.2500")
