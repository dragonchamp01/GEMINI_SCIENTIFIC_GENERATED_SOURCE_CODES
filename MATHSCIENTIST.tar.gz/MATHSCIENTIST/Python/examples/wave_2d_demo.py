"""
MathScientist Example: 2D Wave Simulation
-----------------------------------------
Vibrating membrane with a Gaussian displacement in the center.
"""

import numpy as np
from math_scientist.pde_adv import PDEAdvanced

if __name__ == "__main__":
    nx, ny = 50, 50
    dx, dy = 0.1, 0.1
    c = 1.0 # Wave speed
    dt = 0.01
    
    # Initial Condition: Gaussian pluck
    x = np.linspace(0, 5, nx)
    y = np.linspace(0, 5, ny)
    X, Y = np.meshgrid(x, y)
    u_curr = np.exp(-((X-2.5)**2 + (Y-2.5)**2))
    u_prev = np.copy(u_curr) # Start from rest (v=0)
    
    print("Simulating 2D Wave propagation for 50 steps...")
    u_final = PDEAdvanced.solve_wave_2d(u_curr, u_prev, c, dx, dy, dt, 50)
    
    print(f"Simulation complete.")
    print(f"Max displacement after 50 steps: {np.max(u_final):.4f}")
    print(f"Min displacement after 50 steps: {np.min(u_final):.4f}")
