"""
MathScientist Example: K-Means Clustering
-----------------------------------------
Automatically grouping 2D data points into 3 clusters.
"""

import numpy as np
from math_scientist.clustering import KMeans

if __name__ == "__main__":
    # Create 3 synthetic clusters
    c1 = np.random.randn(10, 2) + [2, 2]
    c2 = np.random.randn(10, 2) + [-2, -2]
    c3 = np.random.randn(10, 2) + [2, -2]
    X = np.vstack([c1, c2, c3])
    
    print(f"Clustering {len(X)} data points...")
    model = KMeans(k=3)
    labels = model.fit(X)
    
    print("
Final Centroids:")
    for i, c in enumerate(model.centroids):
        print(f"Cluster {i}: {np.round(c, 2)}")
    
    print("
First 5 Labels:", labels[:5])
