"""
MathScientist Example: 4D Hypersphere Volume
--------------------------------------------
Calculating the volume of a unit 4-sphere using Monte Carlo.
"""

import numpy as np
from math_scientist.monte_carlo import MonteCarloIntegrator

def in_sphere(p):
    # Returns 1 if inside unit hypersphere, 0 otherwise
    return 1.0 if np.sum(p**2) <= 1.0 else 0.0

if __name__ == "__main__":
    # Bounds for 4D cube: [-1, 1] for all 4 dims
    bounds = [(-1, 1)] * 4
    n = 200000
    
    print(f"Estimating 4D Hypersphere volume with {n} samples...")
    volume = MonteCarloIntegrator.integrate(in_sphere, bounds, n)
    
    theoretical = (np.pi**2) / 2.0
    print(f"Calculated Volume: {volume:.4f}")
    print(f"Theoretical:       {theoretical:.4f}")
    print(f"Error:             {abs(volume - theoretical):.4f}")
