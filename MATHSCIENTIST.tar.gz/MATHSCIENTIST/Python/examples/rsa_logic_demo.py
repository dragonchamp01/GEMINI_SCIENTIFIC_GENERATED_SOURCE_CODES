"""
MathScientist Example: Primality Verification
---------------------------------------------
Checking large integers for primality using Miller-Rabin.
"""

from math_scientist.number_theory import NumberTheory

if __name__ == "__main__":
    # A known prime: 104729 (The 10,000th prime)
    p1 = 104729
    # A composite number
    p2 = 104731 
    
    print(f"Testing {p1} for primality: {NumberTheory.is_prime_miller_rabin(p1)}")
    print(f"Testing {p2} for primality: {NumberTheory.is_prime_miller_rabin(p2)}")
    
    # Very large prime candidate
    large_prime = 1000000000000000003 # approx 10^18
    print(f"Testing large candidate {large_prime}: {NumberTheory.is_prime_miller_rabin(large_prime)}")
