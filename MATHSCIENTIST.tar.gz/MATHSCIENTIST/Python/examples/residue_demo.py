"""
MathScientist Example: Residue Theorem Application
--------------------------------------------------
Evaluating Integral of 1/(x^2 + 1) from -inf to inf.
The function f(z) = 1/(z^2+1) has a pole at z = i.
"""

import numpy as np
from math_scientist.residues import ResidueTheory

def f_complex(z):
    return 1.0 / (z**2 + 1.0)

if __name__ == "__main__":
    pole = 1j # Pole in upper half plane
    
    res = ResidueTheory.calculate_residue(f_complex, pole)
    
    print(f"Calculated Residue at z=i: {res:.6f}")
    
    # Real integral = 2 * pi * i * Sum(Residues in UHP)
    integral_val = (2j * np.pi * res).real
    
    print(f"Real Integral Result: {integral_val:.6f}")
    print(f"Exact Value (pi):     {np.pi:.6f}")
    print(f"Error:                {abs(integral_val - np.pi):.2e}")
