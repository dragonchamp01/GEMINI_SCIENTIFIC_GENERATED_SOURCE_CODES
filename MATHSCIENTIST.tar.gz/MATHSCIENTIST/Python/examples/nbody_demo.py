"""
MathScientist Example: Three-Body Stability
-------------------------------------------
Simulating a stable hierarchical 3-body system.
"""

import numpy as np
from math_scientist.nbody import NBodySimulator

if __name__ == "__main__":
    # 3 Bodies: Star, Planet, Moon
    masses = np.array([1000.0, 1.0, 0.01])
    pos = np.array([
        [0.0, 0.0, 0.0],   # Star
        [10.0, 0.0, 0.0],  # Planet
        [10.5, 0.0, 0.0]   # Moon
    ])
    vel = np.array([
        [0.0, 0.0, 0.0],
        [0.0, 10.0, 0.0],  # Orbital velocity approx sqrt(GM/r)
        [0.0, 11.5, 0.0]
    ])
    
    dt = 0.01
    print("Simulating 3-body hierarchy for 100 steps...")
    for _ in range(100):
        pos, vel = NBodySimulator.step_leapfrog(pos, vel, masses, dt)
        
    print(f"Final Planet Position: {pos[1]}")
    print(f"Final Moon Position:   {pos[2]}")
