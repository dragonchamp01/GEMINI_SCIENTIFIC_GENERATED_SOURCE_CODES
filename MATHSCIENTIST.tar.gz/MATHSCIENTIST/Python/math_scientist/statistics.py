"""
MathScientist SDK - Statistics Module
-------------------------------------
Linear Regression and Predictive Modeling.
"""

import numpy as np

class StatisticalLearning:
    @staticmethod
    def linear_regression(x, y):
        """
        Fits y = ax + b using ordinary least squares.
        """
        n = len(x)
        x_mean = np.mean(x)
        y_mean = np.mean(y)
        
        numerator = np.sum((x - x_mean) * (y - y_mean))
        denominator = np.sum((x - x_mean)**2)
        
        slope = numerator / denominator
        intercept = y_mean - slope * x_mean
        
        return slope, intercept

if __name__ == "__main__":
    print("MathScientist Statistical Engine Online.")
