"""
MathScientist SDK - Numerical Stability Module
-----------------------------------------------
von Neumann Stability Analysis for Finite Difference Schemes.
"""

import numpy as np

class StabilityAnalysis:
    @staticmethod
    def check_heat_stability(alpha, dx, dt):
        """
        Checks stability for 1D Heat Equation (FTCS).
        Requirement: r = alpha * dt / dx^2 <= 0.5
        """
        r = alpha * dt / (dx**2)
        is_stable = r <= 0.5
        return is_stable, r

    @staticmethod
    def get_max_dt_heat(alpha, dx):
        """Returns the maximum stable time step for a given mesh."""
        return 0.5 * (dx**2) / alpha

if __name__ == "__main__":
    print("MathScientist Stability Engine Online.")
