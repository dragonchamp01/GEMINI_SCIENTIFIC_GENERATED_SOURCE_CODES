"""
MathScientist SDK - Polynomial Module
-------------------------------------
Durand-Kerner method for finding all complex roots of a polynomial.
"""

import numpy as np

class PolynomialRoots:
    @staticmethod
    def find_all_roots(coeffs, max_iter=100, tol=1e-10):
        """
        coeffs: [a_n, a_{n-1}, ..., a_0]
        """
        n = len(coeffs) - 1
        # Normalize: leading coefficient should be 1
        a = np.array(coeffs, dtype=complex) / coeffs[0]
        
        # Initial guesses: points on the complex unit circle
        roots = np.array([np.exp(1j * 2 * np.pi * i / n) for i in range(n)])
        
        for _ in range(max_iter):
            old_roots = np.copy(roots)
            for i in range(n):
                # p(z) = z^n + a1*z^{n-1} + ...
                p_z = np.polyval(a, roots[i])
                
                # denominator = product (z_i - z_j)
                denom = 1.0
                for j in range(n):
                    if i != j:
                        denom *= (roots[i] - roots[j])
                
                roots[i] = roots[i] - p_z / denom
            
            if np.linalg.norm(roots - old_roots) < tol:
                break
        return roots

if __name__ == "__main__":
    print("MathScientist Polynomial Engine Online.")
