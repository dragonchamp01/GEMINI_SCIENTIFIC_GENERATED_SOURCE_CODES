"""
MathScientist SDK - PDE Module
------------------------------
Numerical solvers for Partial Differential Equations.
"""

import numpy as np

class PDESolver:
    @staticmethod
    def solve_heat_1d(u0, alpha, L, T, nx, nt):
        """
        Solves du/dt = alpha * d2u/dx2 using FTCS scheme.
        u0: Initial temperature distribution.
        alpha: Thermal diffusivity.
        L: Length of the rod.
        T: Total time.
        """
        dx = L / (nx - 1)
        dt = T / nt
        r = alpha * dt / (dx**2)
        
        if r > 0.5:
            print("Warning: Stability criterion (r <= 0.5) not met!")
            
        u = np.copy(u0)
        u_new = np.copy(u0)
        
        for _ in range(nt):
            u_new[1:-1] = u[1:-1] + r * (u[2:] - 2*u[1:-1] + u[:-2])
            u = np.copy(u_new)
            # Dirichlet boundary conditions (ends at 0 degrees)
            u[0] = 0
            u[-1] = 0
            
        return u

if __name__ == "__main__":
    print("MathScientist PDE Engine Online.")
