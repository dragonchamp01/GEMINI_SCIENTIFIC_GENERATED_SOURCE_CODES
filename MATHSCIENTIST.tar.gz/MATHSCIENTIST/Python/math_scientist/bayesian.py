"""
MathScientist SDK - Bayesian Inference Module
---------------------------------------------
Tools for recursive probability updates.
"""

import numpy as np

class BayesianInference:
    @staticmethod
    def update_discrete(prior, likelihood):
        """
        Performs a Bayesian update on a discrete set of hypotheses.
        Posterior = (Likelihood * Prior) / Normalization
        """
        unnormalized = prior * likelihood
        evidence = np.sum(unnormalized)
        
        if evidence == 0:
            return prior
            
        return unnormalized / evidence

if __name__ == "__main__":
    print("MathScientist Bayesian Engine Online.")
