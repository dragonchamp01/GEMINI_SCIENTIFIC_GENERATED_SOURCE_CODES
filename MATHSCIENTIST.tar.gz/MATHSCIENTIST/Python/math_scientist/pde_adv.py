"""
MathScientist SDK - Advanced PDE Module
---------------------------------------
2D Wave Equation Solver using Finite Difference.
"""

import numpy as np

class PDEAdvanced:
    @staticmethod
    def solve_wave_2d(u_curr, u_prev, c, dx, dy, dt, nt):
        """
        Solves d2u/dt2 = c^2 * (d2u/dx2 + d2u/dy2)
        u_curr: current state (2D array)
        u_prev: previous state (2D array)
        """
        nx, ny = u_curr.shape
        u_next = np.copy(u_curr)
        
        # Courant numbers
        rx = (c * dt / dx)**2
        ry = (c * dt / dy)**2
        
        for _ in range(nt):
            # Vectorized Laplacian update
            u_next[1:-1, 1:-1] = (2 * u_curr[1:-1, 1:-1] - u_prev[1:-1, 1:-1] +
                rx * (u_curr[2:, 1:-1] - 2 * u_curr[1:-1, 1:-1] + u_curr[:-2, 1:-1]) +
                ry * (u_curr[1:-1, 2:] - 2 * u_curr[1:-1, 1:-1] + u_curr[1:-1, :-2]))
            
            # Update buffers
            u_prev = np.copy(u_curr)
            u_curr = np.copy(u_next)
            
            # Boundary Conditions: Fixed edges (Dirichlet)
            u_curr[0, :] = u_curr[-1, :] = u_curr[:, 0] = u_curr[:, -1] = 0
            
        return u_curr

if __name__ == "__main__":
    print("MathScientist Advanced PDE Engine Online.")
