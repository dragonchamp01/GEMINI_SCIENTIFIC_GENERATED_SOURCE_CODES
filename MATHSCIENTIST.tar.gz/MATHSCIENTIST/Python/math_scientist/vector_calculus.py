"""
MathScientist SDK - Vector Calculus Module
------------------------------------------
Operators for Vector Fields: Gradient, Divergence, and Curl.
"""

import numpy as np

class VectorCalculus:
    @staticmethod
    def gradient(f, pos, h=1e-5):
        """Computes grad(f) at position (x, y, z)."""
        grad = np.zeros(len(pos))
        for i in range(len(pos)):
            p_plus = np.array(pos, dtype=float); p_plus[i] += h
            p_minus = np.array(pos, dtype=float); p_minus[i] -= h
            grad[i] = (f(p_plus) - f(p_minus)) / (2 * h)
        return grad

    @staticmethod
    def divergence(F, pos, h=1e-5):
        """Computes div(F) at position (x, y, z)."""
        div = 0.0
        for i in range(len(pos)):
            p_plus = np.array(pos, dtype=float); p_plus[i] += h
            p_minus = np.array(pos, dtype=float); p_minus[i] -= h
            div += (F(p_plus)[i] - F(p_minus)[i]) / (2 * h)
        return div

    @staticmethod
    def curl_3d(F, pos, h=1e-5):
        """Computes curl(F) in 3D at position (x, y, z)."""
        # Curl components using finite difference
        # (dFz/dy - dFy/dz, dFx/dz - dFz/dx, dFy/dx - dFx/dy)
        def partial(func_idx, var_idx):
            p_plus = np.array(pos, dtype=float); p_plus[var_idx] += h
            p_minus = np.array(pos, dtype=float); p_minus[var_idx] -= h
            return (F(p_plus)[func_idx] - F(p_minus)[func_idx]) / (2 * h)
            
        return np.array([
            partial(2, 1) - partial(1, 2),
            partial(0, 2) - partial(2, 0),
            partial(1, 0) - partial(0, 1)
        ])

if __name__ == "__main__":
    print("MathScientist Vector Calculus Engine Online.")
