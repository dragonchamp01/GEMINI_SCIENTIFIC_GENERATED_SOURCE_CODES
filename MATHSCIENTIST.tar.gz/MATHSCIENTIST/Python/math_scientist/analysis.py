"""
MathScientist SDK - Complex Analysis Module
-------------------------------------------
Z-Transform and Complex Series expansion.
"""

import numpy as np

class ComplexAnalysis:
    @staticmethod
    def z_transform(sequence, z):
        """
        Computes the Z-transform X(z) = sum( x[n] * z^-n )
        """
        res = 0j
        for n, x in enumerate(sequence):
            res += x * (z ** (-n))
        return res

    @staticmethod
    def cauchy_integral_formula(f, z0, R, n=1000):
        """
        Numerically verifies Cauchy's Integral Formula for f(z0).
        f(z0) = (1 / 2pi*i) * integral( f(z) / (z-z0) dz )
        """
        theta = np.linspace(0, 2*np.pi, n)
        z = z0 + R * np.exp(1j * theta)
        dz = 1j * R * np.exp(1j * theta) * (theta[1] - theta[0])
        
        integral = np.sum(f(z) / (z - z0) * dz)
        return integral / (2j * np.pi)

if __name__ == "__main__":
    print("MathScientist Python SDK: Complex Analysis Engine Online.")
