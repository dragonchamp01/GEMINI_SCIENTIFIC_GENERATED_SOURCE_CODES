"""
MathScientist SDK - Global Optimization Module
----------------------------------------------
Particle Swarm Optimization (PSO) for non-convex landscapes.
"""

import numpy as np

class ParticleSwarm:
    @staticmethod
    def optimize(objective, n_particles=30, dim=2, iters=100):
        # Parameters
        w = 0.5  # inertia
        c1 = 0.8 # cognitive constant
        c2 = 0.9 # social constant
        
        pos = np.random.uniform(-5, 5, (n_particles, dim))
        vel = np.random.uniform(-1, 1, (n_particles, dim))
        p_best = np.copy(pos)
        p_best_val = np.array([objective(p) for p in pos])
        g_best = p_best[np.argmin(p_best_val)]
        g_best_val = np.min(p_best_val)
        
        for _ in range(iters):
            r1, r2 = np.random.rand(n_particles, dim), np.random.rand(n_particles, dim)
            vel = w * vel + c1 * r1 * (p_best - pos) + c2 * r2 * (g_best - pos)
            pos += vel
            
            curr_val = np.array([objective(p) for p in pos])
            better_mask = curr_val < p_best_val
            p_best[better_mask] = pos[better_mask]
            p_best_val[better_mask] = curr_val[better_mask]
            
            if np.min(p_best_val) < g_best_val:
                g_best_val = np.min(p_best_val)
                g_best = p_best[np.argmin(p_best_val)]
                
        return g_best, g_best_val

if __name__ == "__main__":
    print("MathScientist Global Optimization Engine Online.")
