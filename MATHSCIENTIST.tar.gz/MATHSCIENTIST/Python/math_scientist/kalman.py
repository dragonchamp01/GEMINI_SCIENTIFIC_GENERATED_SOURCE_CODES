"""
MathScientist SDK - Filtering Module
------------------------------------
1D Kalman Filter for state estimation under noise.
"""

class KalmanFilter1D:
    def __init__(self, process_var, sensor_var, estimate_var, initial_x):
        self.q = process_var   # Q: how fast state changes
        self.r = sensor_var    # R: sensor noise
        self.p = estimate_var  # P: estimate error covariance
        self.x = initial_x     # x: estimated state

    def update(self, measurement):
        # 1. Prediction (Time update)
        self.p = self.p + self.q
        
        # 2. Measurement Update (Correction)
        kalman_gain = self.p / (self.p + self.r)
        self.x = self.x + kalman_gain * (measurement - self.x)
        self.p = (1 - kalman_gain) * self.p
        
        return self.x

if __name__ == "__main__":
    print("MathScientist Kalman Engine Online.")
