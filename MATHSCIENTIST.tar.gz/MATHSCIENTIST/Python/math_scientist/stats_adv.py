"""
MathScientist SDK - Advanced Statistics Module
-----------------------------------------------
Logistic Regression for Binary Classification.
"""

import numpy as np

class LogisticRegression:
    @staticmethod
    def sigmoid(z):
        return 1.0 / (1.0 + np.exp(-z))

    @staticmethod
    def fit(X, y, lr=0.1, iters=1000):
        """
        Trains the model using Gradient Descent.
        """
        n_samples, n_features = X.shape
        weights = np.zeros(n_features)
        bias = 0

        for _ in range(iters):
            model = np.dot(X, weights) + bias
            predictions = LogisticRegression.sigmoid(model)

            dw = (1 / n_samples) * np.dot(X.T, (predictions - y))
            db = (1 / n_samples) * np.sum(predictions - y)

            weights -= lr * dw
            bias -= lr * db
            
        return weights, bias

if __name__ == "__main__":
    print("MathScientist Statistical Learning Engine Online.")
