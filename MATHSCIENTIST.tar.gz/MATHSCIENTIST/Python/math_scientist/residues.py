"""
MathScientist SDK - Advanced Complex Analysis
---------------------------------------------
Numerical Residue extraction using Cauchy's Integral Theorem.
"""

import numpy as np

class ResidueTheory:
    @staticmethod
    def calculate_residue(f, z0, radius=1e-4, n=1000):
        """
        Estimates Res(f, z0) = (1/2pi*i) * integral around z0.
        """
        theta = np.linspace(0, 2*np.pi, n)
        z = z0 + radius * np.exp(1j * theta)
        dz = 1j * radius * np.exp(1j * theta) * (theta[1] - theta[0])
        
        # Integral of f(z) around the pole
        integral = np.sum(f(z) * dz)
        return integral / (2j * np.pi)

if __name__ == "__main__":
    print("MathScientist Residue Engine Online.")
