"""
MathScientist SDK - Advanced Number Theory
------------------------------------------
Primality testing and RSA cryptographic foundations.
"""

import random

class NumberTheory:
    @staticmethod
    def is_prime_miller_rabin(n, k=5):
        """Miller-Rabin Primality Test."""
        if n <= 1: return False
        if n <= 3: return True
        if n % 2 == 0: return False

        # Find r, d such that n - 1 = 2^r * d
        r, d = 0, n - 1
        while d % 2 == 0:
            r += 1
            d //= 2

        for _ in range(k):
            a = random.randint(2, n - 2)
            x = pow(a, d, n)
            if x == 1 or x == n - 1:
                continue
            for _ in range(r - 1):
                x = pow(x, 2, n)
                if x == n - 1:
                    break
            else:
                return False
        return True

if __name__ == "__main__":
    print("MathScientist Number Theory Engine Online.")
