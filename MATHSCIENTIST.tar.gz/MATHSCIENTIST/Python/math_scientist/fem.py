"""
MathScientist SDK - Finite Element Method (FEM) Module
------------------------------------------------------
1D linear elements for solving -u'' = f(x).
"""

import numpy as np

class FEMSolver1D:
    @staticmethod
    def solve_poisson(L, N, f_source):
        """
        Solves -u'' = f on [0, L] with u(0)=u(L)=0.
        N: number of elements.
        """
        h = L / N
        nodes = np.linspace(0, L, N + 1)
        
        # 1. Global Stiffness Matrix K
        K = np.zeros((N-1, N-1))
        for i in range(N-1):
            K[i, i] = 2.0 / h
            if i > 0:
                K[i, i-1] = -1.0 / h
            if i < N-2:
                K[i, i+1] = -1.0 / h
                
        # 2. Load Vector F
        F = np.zeros(N-1)
        for i in range(N-1):
            # Midpoint approximation for source integral
            F[i] = f_source(nodes[i+1]) * h
            
        # 3. Solve K*u = F
        u_internal = np.linalg.solve(K, F)
        u_full = np.concatenate(([0], u_internal, [0]))
        
        return nodes, u_full

if __name__ == "__main__":
    print("MathScientist FEM Engine Online.")
