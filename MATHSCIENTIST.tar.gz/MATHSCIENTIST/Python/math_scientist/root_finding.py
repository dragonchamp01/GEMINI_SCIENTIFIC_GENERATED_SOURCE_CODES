"""
MathScientist SDK - Root Finding Module
---------------------------------------
Newton-Raphson and Secant methods for non-linear equations.
"""

import numpy as np

class RootFinder:
    @staticmethod
    def newton_raphson(f, df, x0, tol=1e-8, max_iter=100):
        """
        Finds a root of f(x) = 0 starting from x0.
        f: function, df: derivative of f.
        """
        x = x0
        for i in range(max_iter):
            fx = f(x)
            dfx = df(x)
            if abs(dfx) < 1e-12:
                break
            x_next = x - fx / dfx
            if abs(x_next - x) < tol:
                return x_next
            x = x_next
        return x

if __name__ == "__main__":
    print("MathScientist Root Finding Engine Online.")
