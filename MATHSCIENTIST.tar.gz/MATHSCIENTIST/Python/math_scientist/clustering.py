"""
MathScientist SDK - Clustering Module
-------------------------------------
K-Means Clustering implementation for data grouping.
"""

import numpy as np

class KMeans:
    def __init__(self, k=3, max_iters=100):
        self.k = k
        self.max_iters = max_iters
        self.centroids = None

    def fit(self, X):
        # 1. Randomly initialize centroids
        idx = np.random.choice(len(X), self.k, replace=False)
        self.centroids = X[idx]

        for _ in range(self.max_iters):
            # 2. Assign clusters
            distances = np.linalg.norm(X[:, np.newaxis] - self.centroids, axis=2)
            labels = np.argmin(distances, axis=1)

            # 3. Update centroids
            new_centroids = np.array([X[labels == i].mean(axis=0) for i in range(self.k)])
            
            if np.all(self.centroids == new_centroids):
                break
            self.centroids = new_centroids
        return labels

if __name__ == "__main__":
    print("MathScientist Clustering Engine Online.")
