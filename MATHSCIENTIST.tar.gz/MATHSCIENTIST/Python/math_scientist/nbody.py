"""
MathScientist SDK - N-Body Dynamics Module
------------------------------------------
Numerical integration for gravitational many-body systems.
"""

import numpy as np

class NBodySimulator:
    @staticmethod
    def get_accelerations(positions, masses, G=1.0, epsilon=1e-3):
        """
        Computes gravity acceleration for each body.
        epsilon: softening factor to avoid singularities.
        """
        n = len(masses)
        acc = np.zeros_like(positions)
        for i in range(n):
            for j in range(n):
                if i == j: continue
                r_vec = positions[j] - positions[i]
                r_mag = np.linalg.norm(r_vec) + epsilon
                acc[i] += G * masses[j] * r_vec / (r_mag**3)
        return acc

    @staticmethod
    def step_leapfrog(pos, vel, masses, dt, G=1.0):
        """
        Second-order Symplectic Integrator (Leapfrog).
        Preserves energy better than RK4 for orbital mechanics.
        """
        # 1. v(t + dt/2) = v(t) + a(t) * dt/2
        acc_t = NBodySimulator.get_accelerations(pos, masses, G)
        vel_half = vel + acc_t * (dt / 2.0)
        
        # 2. x(t + dt) = x(t) + v(t + dt/2) * dt
        pos_next = pos + vel_half * dt
        
        # 3. v(t + dt) = v(t + dt/2) + a(t + dt) * dt/2
        acc_next = NBodySimulator.get_accelerations(pos_next, masses, G)
        vel_next = vel_half + acc_next * (dt / 2.0)
        
        return pos_next, vel_next

if __name__ == "__main__":
    print("MathScientist N-Body Engine Online.")
