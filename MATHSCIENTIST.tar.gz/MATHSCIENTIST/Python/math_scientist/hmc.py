"""
MathScientist SDK - Advanced Sampling Module
---------------------------------------------
Hamiltonian Monte Carlo (HMC) Implementation.
Uses leapfrog integration to propose new states.
"""

import numpy as np

class HMCSampler:
    @staticmethod
    def sample(target_log_pdf, grad_log_pdf, current_q, path_len, step_size):
        """
        Performs one HMC step.
        target_log_pdf: function returning log(P(q))
        grad_log_pdf: function returning grad(log(P(q)))
        """
        q = np.copy(current_q)
        p = np.random.normal(0, 1, size=q.shape) # momentum
        current_p = np.copy(p)
        
        # 1. Half step for momentum
        p -= step_size * grad_log_pdf(q) / 2.0
        
        # 2. Alternate full steps for position and momentum
        num_steps = int(path_len / step_size)
        for _ in range(num_steps):
            q += step_size * p
            if _ != num_steps - 1:
                p -= step_size * grad_log_pdf(q)
                
        # 3. Half step for momentum at the end
        p -= step_size * grad_log_pdf(q) / 2.0
        
        # Negate momentum at the end of the trajectory to make the proposal symmetric
        p = -p
        
        # 4. Metropolis acceptance step
        current_U = -target_log_pdf(current_q)
        current_K = np.sum(current_p**2) / 2.0
        proposed_U = -target_log_pdf(q)
        proposed_K = np.sum(p**2) / 2.0
        
        if np.random.rand() < np.exp(current_U + current_K - proposed_U - proposed_K):
            return q
        return current_q

if __name__ == "__main__":
    print("MathScientist HMC Engine Online.")
