"""
MathScientist SDK - Multivariable Integration Module
-----------------------------------------------------
Numerical Double Integration using the Midpoint Rule.
"""

import numpy as np

class MultiIntegrator:
    @staticmethod
    def integrate_2d(f, ax, bx, ay, by, nx=100, ny=100):
        """
        Computes the double integral of f(x, y) over [ax, bx] x [ay, by].
        """
        dx = (bx - ax) / nx
        dy = (by - ay) / ny
        
        x = np.linspace(ax + dx/2, bx - dx/2, nx)
        y = np.linspace(ay + dy/2, by - dy/2, ny)
        X, Y = np.meshgrid(x, y)
        
        # Evaluate function on grid
        Z = f(X, Y)
        
        return np.sum(Z) * dx * dy

if __name__ == "__main__":
    print("MathScientist Multi-variable Integration Engine Online.")
