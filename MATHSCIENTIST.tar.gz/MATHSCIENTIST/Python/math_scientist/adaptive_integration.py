"""
MathScientist SDK - Adaptive Integration Module
-----------------------------------------------
Adaptive Simpson's Method for high-precision quadrature.
"""

import numpy as np

class AdaptiveIntegrator:
    @staticmethod
    def _simpson(f, a, b):
        """Standard Simpson's rule for a single interval."""
        c = (a + b) / 2.0
        return (b - a) / 6.0 * (f(a) + 4 * f(c) + f(b))

    @staticmethod
    def integrate(f, a, b, tol=1e-7):
        """
        Recursively subdivides the interval until the tolerance is met.
        """
        whole = AdaptiveIntegrator._simpson(f, a, b)
        mid = (a + b) / 2.0
        left = AdaptiveIntegrator._simpson(f, a, mid)
        right = AdaptiveIntegrator._simpson(f, mid, b)
        
        if abs(left + right - whole) <= 15 * tol:
            return left + right + (left + right - whole) / 15.0
        
        return (AdaptiveIntegrator.integrate(f, a, mid, tol / 2.0) + 
                AdaptiveIntegrator.integrate(f, mid, b, tol / 2.0))

if __name__ == "__main__":
    print("MathScientist Adaptive Integration Engine Online.")
