"""
MathScientist SDK - MCMC Module
-------------------------------
Metropolis-Hastings algorithm for sampling from complex PDFs.
"""

import numpy as np

class MCMC:
    @staticmethod
    def sample_metropolis(target_pdf, start_x, n_samples=1000, step_size=0.5):
        """
        Samples from target_pdf using Metropolis-Hastings.
        """
        samples = [start_x]
        curr_x = start_x
        
        for _ in range(n_samples):
            # Propose new point
            proposal = curr_x + np.random.normal(0, step_size)
            
            # Acceptance ratio
            ratio = target_pdf(proposal) / target_pdf(curr_x)
            
            if np.random.rand() < ratio:
                curr_x = proposal
            
            samples.append(curr_x)
            
        return np.array(samples)

if __name__ == "__main__":
    print("MathScientist MCMC Engine Online.")
