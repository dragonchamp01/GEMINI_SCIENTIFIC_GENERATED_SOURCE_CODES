"""
MathScientist SDK - Multivariable Calculus Module
--------------------------------------------------
Jacobian and Hessian matrix computation using Finite Difference.
"""

import numpy as np

class MultivariableCalculus:
    @staticmethod
    def jacobian(f, x, h=1e-5):
        """
        Computes the Jacobian matrix J of a vector-valued function f at x.
        J_ij = df_i / dx_j
        """
        x = np.asfarray(x)
        f0 = f(x)
        n = len(x)
        m = len(f0)
        J = np.zeros((m, n))
        for j in range(n):
            x_plus = np.copy(x); x_plus[j] += h
            x_minus = np.copy(x); x_minus[j] -= h
            df = (f(x_plus) - f(x_minus)) / (2 * h)
            J[:, j] = df
        return J

    @staticmethod
    def hessian(f, x, h=1e-4):
        """
        Computes the Hessian matrix H of a scalar function f at x.
        H_ij = d2f / (dx_i dx_j)
        """
        x = np.asfarray(x)
        n = len(x)
        H = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                if i == j:
                    # Diagonal: second derivative
                    x_p = np.copy(x); x_p[i] += h
                    x_m = np.copy(x); x_m[i] -= h
                    H[i, i] = (f(x_p) - 2*f(x) + f(x_m)) / (h**2)
                else:
                    # Off-diagonal: mixed partial derivative
                    x_pp = np.copy(x); x_pp[i] += h; x_pp[j] += h
                    x_pm = np.copy(x); x_pm[i] += h; x_pm[j] -= h
                    x_mp = np.copy(x); x_mp[i] -= h; x_mp[j] += h
                    x_mm = np.copy(x); x_mm[i] -= h; x_mm[j] -= h
                    H[i, j] = (f(x_pp) - f(x_pm) - f(x_mp) + f(x_mm)) / (4 * h**2)
        return H

if __name__ == "__main__":
    print("MathScientist Multivariable Engine Online.")
