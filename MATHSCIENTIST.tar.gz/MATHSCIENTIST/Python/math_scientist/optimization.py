"""
MathScientist SDK - Optimization Module
---------------------------------------
Gradient-based optimization for university calculus.
"""

import numpy as np

class Optimizer:
    @staticmethod
    def gradient_descent(f_grad, start_x, learning_rate=0.01, iters=1000, tol=1e-6):
        """
        Finds the local minimum of a function using Gradient Descent.
        f_grad: Gradient function df/dx
        """
        x = start_x
        for i in range(iters):
            grad = f_grad(x)
            new_x = x - learning_rate * grad
            if np.abs(new_x - x) < tol:
                break
            x = new_x
        return x

if __name__ == "__main__":
    print("MathScientist Optimization Engine Online.")
