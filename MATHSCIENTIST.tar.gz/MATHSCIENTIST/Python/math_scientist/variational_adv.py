"""
MathScientist SDK - Advanced Variational Module
-----------------------------------------------
Solving the Catenary problem (hanging chain).
Formula: y = a * cosh(x/a)
"""

import numpy as np

class VariationalAdvanced:
    @staticmethod
    def get_catenary_curve(span, sag, n_points=100):
        """
        Calculates the catenary curve for a given span and sag.
        a: catenary parameter (tension/weight ratio)
        """
        # x range from -span/2 to span/2
        x = np.linspace(-span/2, span/2, n_points)
        
        # Numerical approximation for 'a' based on sag
        # sag = a * (cosh(span/(2a)) - 1)
        # Simplified: for small sag, a approx span^2 / (8*sag)
        a = (span**2) / (8 * sag)
        
        # Iterative refinement for 'a' (Newton step)
        for _ in range(5):
            f = a * (np.cosh(span / (2 * a)) - 1) - sag
            df = np.cosh(span / (2 * a)) - (span / (2 * a)) * np.sinh(span / (2 * a)) - 1
            a = a - f / df
            
        y = a * np.cosh(x / a)
        # Shift y so that the lowest point is at the correct sag
        y = y - np.min(y)
        return x, y

if __name__ == "__main__":
    print("MathScientist Advanced Variational Engine Online.")
