"""
MathScientist SDK - Fourier Analysis Module
-------------------------------------------
Fast Fourier Transform (FFT) Implementation (Cooley-Tukey).
"""

import numpy as np

class FFT:
    @staticmethod
    def fft(x):
        """
        Recursive implementation of the 1D Cooley-Tukey FFT.
        Input size must be a power of 2.
        """
        N = len(x)
        if N <= 1:
            return x
        
        even = FFT.fft(x[0::2])
        odd = FFT.fft(x[1::2])
        
        T = [np.exp(-2j * np.pi * k / N) * odd[k] for k in range(N // 2)]
        return np.concatenate([even + T, even - T])

if __name__ == "__main__":
    print("MathScientist FFT Engine Online.")
