"""
MathScientist SDK - Monte Carlo Module
---------------------------------------
Random-sampling based numerical integration for N-dimensions.
"""

import numpy as np

class MonteCarloIntegrator:
    @staticmethod
    def integrate(f, bounds, n_samples=100000):
        """
        Integrates f over the given bounds.
        bounds: list of (min, max) for each dimension.
        """
        dims = len(bounds)
        lows = [b[0] for b in bounds]
        highs = [b[1] for b in bounds]
        
        # 1. Generate random samples in the hyperspace
        samples = np.random.uniform(lows, highs, (n_samples, dims))
        
        # 2. Evaluate function
        f_values = np.apply_along_axis(f, 1, samples)
        
        # 3. Volume * Average Value
        volume = np.prod([b[1] - b[0] for b in bounds])
        return volume * np.mean(f_values)

if __name__ == "__main__":
    print("MathScientist Monte Carlo Engine Online.")
