"""
MathScientist SDK - Fourier Analysis Module
-------------------------------------------
Discrete Fourier Transform (DFT) and Inverse DFT.
"""

import numpy as np

class FourierTransform:
    @staticmethod
    def dft(x):
        """
        Computes the Discrete Fourier Transform.
        X[k] = sum_{n=0}^{N-1} x[n] * exp(-i * 2pi * k * n / N)
        """
        N = len(x)
        n = np.arange(N)
        k = n.reshape((N, 1))
        e = np.exp(-2j * np.pi * k * n / N)
        return np.dot(e, x)

    @staticmethod
    def idft(X):
        """
        Computes the Inverse Discrete Fourier Transform.
        """
        N = len(X)
        n = np.arange(N)
        k = n.reshape((N, 1))
        e = np.exp(2j * np.pi * k * n / N)
        return np.dot(e, X) / N

if __name__ == "__main__":
    print("MathScientist Fourier Engine Online.")
