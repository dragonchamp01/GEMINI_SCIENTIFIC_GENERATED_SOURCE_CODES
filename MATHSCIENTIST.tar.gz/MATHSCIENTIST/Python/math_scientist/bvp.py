"""
MathScientist SDK - Boundary Value Problem (BVP) Module
--------------------------------------------------------
Numerical solvers for ODEs with boundary conditions.
"""

import numpy as np

class BVPSolver:
    @staticmethod
    def solve_poisson_1d(f, L, N, bc=(0, 0)):
        """
        Solves -u''(x) = f(x) on [0, L] with u(0)=bc[0], u(L)=bc[1].
        """
        h = L / (N - 1)
        x = np.linspace(0, L, N)
        
        # Finite difference matrix A (Tridiagonal)
        A = (np.diag(np.ones(N-1), -1) - 2 * np.diag(np.ones(N)) + np.diag(np.ones(N-1), 1)) / (h**2)
        
        # Source vector
        b = -f(x)
        
        # Apply Dirichlet Boundary Conditions
        A[0, :] = 0; A[0, 0] = 1; b[0] = bc[0]
        A[-1, :] = 0; A[-1, -1] = 1; b[-1] = bc[1]
        
        u = np.linalg.solve(A, b)
        return x, u

if __name__ == "__main__":
    print("MathScientist BVP Engine Online.")
