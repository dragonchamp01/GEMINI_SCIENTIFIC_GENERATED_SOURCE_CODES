"""
MathScientist SDK - Variational Analysis Module
-----------------------------------------------
Quantitative verification of the Principle of Least Action.
Computes the L2-norm of the Euler-Lagrange residual.
"""

import numpy as np
from .variational import VariationalCalculus

class VariationalValidator:
    @staticmethod
    def compute_path_error(L, q_path, t_grid):
        """
        Calculates the mean squared residual of the EL equation along a path.
        """
        h = t_grid[1] - t_grid[0]
        q_dot = np.gradient(q_path, h)
        q_ddot = np.gradient(q_dot, h)
        
        residuals = []
        # Skip boundaries for derivative stability
        for i in range(2, len(t_grid) - 2):
            res = VariationalCalculus.euler_lagrange_residual(
                L, q_path[i], q_dot[i], q_ddot[i], t_grid[i]
            )
            residuals.append(res**2)
            
        return np.sqrt(np.mean(residuals))

if __name__ == "__main__":
    print("MathScientist Variational Analysis Engine Online.")
