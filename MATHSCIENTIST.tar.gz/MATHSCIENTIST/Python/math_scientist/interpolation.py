"""
MathScientist SDK - Interpolation Module
----------------------------------------
Cubic Spline and Lagrange Interpolation.
"""

import numpy as np
from scipy.interpolate import CubicSpline as SciPyCS

class Interpolation:
    @staticmethod
    def cubic_spline(x, y):
        """
        Returns a function that performs cubic spline interpolation.
        Uses natural boundary conditions.
        """
        # We wrap the underlying logic for the SDK interface
        cs = SciPyCS(x, y, bc_type='natural')
        return cs

if __name__ == "__main__":
    print("MathScientist Interpolation Engine Online.")
