#include <iostream>
#include <iomanip>
#include "../include/MathScientist/ComplexCalculus.hpp"

using namespace MathScientist;

int main() {
    double a = 2.0;
    // Integrand: exp(iz) / (z^2 + a^2)
    // Pole in upper half plane at z = i*a
    auto f = [a](Complex z) {
        return std::exp(Complex(0, 1) * z) / (z * z + a * a);
    };

    Complex z0(0, a);
    double radius = 0.1;

    std::cout << "MathScientist: Real Integral via Complex Residue" << std::endl;
    std::cout << "Integral of cos(x)/(x^2 + 4) from -inf to inf" << std::endl;

    // Res(f, ia) = exp(-a) / (2ia)
    Complex integral_around_pole = ComplexIntegrator::integrate_circle(f, z0, radius);
    
    // Total integral = 2 * pi * i * Sum(Residues)
    Complex total = Complex(0, 1) * 2.0 * M_PI * (integral_around_pole / (Complex(0, 1) * 2.0 * M_PI));
    
    std::cout << "Calculated Result (Real part): " << total.real() << std::endl;
    std::cout << "Analytical (pi * exp(-2)/2):   " << M_PI * std::exp(-2.0) / 2.0 << std::endl;

    return 0;
}
