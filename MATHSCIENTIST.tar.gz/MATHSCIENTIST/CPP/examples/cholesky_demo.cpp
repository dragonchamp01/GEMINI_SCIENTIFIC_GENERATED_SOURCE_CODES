#include <iostream>
#include <iomanip>
#include "../include/MathScientist/Cholesky.hpp"

int main() {
    using namespace MathScientist;

    // Symmetric Positive-Definite Matrix A = [[4, 12], [12, 37]]
    Matrix<double> A(2, 2);
    A(0, 0) = 4; A(0, 1) = 12;
    A(1, 0) = 12; A(1, 1) = 37;

    std::cout << "MathScientist: Cholesky Decomposition A = LL^T" << std::endl;
    Matrix<double> L = Cholesky<double>::decompose(A);

    std::cout << "Lower Matrix L:" << std::endl;
    L.print();
    
    // Verification: L[0,0]^2 should be 4
    std::cout << "
Verification L(0,0)^2: " << L(0,0) * L(0,0) << " (Expected: 4.0)" << std::endl;

    return 0;
}
