#include <iostream>
#include "../include/MathScientist/EigenSolver.hpp"

int main() {
    using namespace MathScientist;

    // Matrix A = [[2, 1], [1, 2]] -> Eigenvalues are 3 and 1.
    Matrix<double> A(2, 2);
    A(0, 0) = 2; A(0, 1) = 1;
    A(1, 0) = 1; A(1, 1) = 2;

    std::cout << "MathScientist: Dominant Eigenvalue Calculation" << std::endl;
    double l_max = EigenSolver<double>::power_iteration(A);

    std::cout << "Calculated dominant eigenvalue: " << l_max << std::endl;
    std::cout << "Expected: 3.0" << std::endl;

    return 0;
}
