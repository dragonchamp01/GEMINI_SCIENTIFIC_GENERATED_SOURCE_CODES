#include <iostream>
#include <iomanip>
#include "../include/MathScientist/FluidDynamics.hpp"

int main() {
    using namespace MathScientist;

    double strength = 10.0;
    double x0 = 0, y0 = 0;

    std::cout << "MathScientist: Potential Flow Analysis" << std::endl;
    std::cout << "Point Source at (0,0) with strength " << strength << std::endl;
    std::cout << "---------------------------------------" << std::endl;
    std::cout << "  X  |  Y  | Potential (Phi)" << std::endl;

    for (double x = 1.0; x <= 3.0; x += 1.0) {
        double phi = PotentialFlow::get_source_potential(strength, x, 0, x0, y0);
        std::cout << std::fixed << std::setprecision(4) << x << "  | 0.0 | " << phi << std::endl;
    }

    return 0;
}
