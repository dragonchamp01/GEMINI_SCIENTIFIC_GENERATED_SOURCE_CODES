#include <iostream>
#include <iomanip>
#include "../include/MathScientist/ComplexCalculus.hpp"

int main() {
    using namespace MathScientist;

    // f(z) = 1 / (z^2 + 1)
    // Poles at z = i and z = -i
    auto f = [](Complex z) { return 1.0 / (z * z + 1.0); };

    Complex z0(0, 1); // Pole at +i
    double R = 0.1;

    std::cout << "MathScientist: Complex Residue Analysis" << std::endl;
    std::cout << "Target function: 1 / (z^2 + 1)" << std::endl;
    std::cout << "Analyzing pole at z = +i" << std::endl;

    // Numerical residue extraction via Cauchy's integral formula
    Complex res = ComplexIntegrator::integrate_circle(f, z0, R);
    // Residue = result / (2 * pi * i)
    res /= (Complex(0, 1) * 2.0 * M_PI);

    std::cout << std::fixed << std::setprecision(6);
    std::cout << "Calculated Residue: " << res.real() << " + " << res.imag() << "i" << std::endl;
    std::cout << "Expected Residue:   0.000000 - 0.500000i (1/2i)" << std::endl;

    return 0;
}
