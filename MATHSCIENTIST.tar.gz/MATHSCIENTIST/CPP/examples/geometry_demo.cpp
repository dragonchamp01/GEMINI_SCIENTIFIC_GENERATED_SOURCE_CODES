#include <iostream>
#include "../include/MathScientist/SurfaceGeometry.hpp"

int main() {
    using namespace MathScientist;

    // For a sphere of radius R:
    // E=R^2, F=0, G=R^2*sin^2(th)
    // L=R, M=0, N=R*sin^2(th)
    double R = 2.0;
    double E = R*R, F = 0, G = R*R; // simplified at equator
    double L = R, M = 0, N = R;

    std::cout << "MathScientist: Surface Curvature Analysis (Sphere R=2)" << std::endl;
    
    CurvatureResult res = SurfaceGeometry::calculate_at_point(E, F, G, L, M, N);

    std::cout << "Gaussian Curvature K: " << res.Gaussian << " (Expected: 1/R^2 = 0.25)" << std::endl;
    std::cout << "Mean Curvature H:     " << res.Mean << " (Expected: 1/R = 0.5)" << std::endl;

    return 0;
}
