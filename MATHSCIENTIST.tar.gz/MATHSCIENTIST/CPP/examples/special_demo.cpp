#include <iostream>
#include "../include/MathScientist/SpecialFunctions.hpp"

int main() {
    using namespace MathScientist;

    std::cout << "MathScientist: Bessel J0(x) calculation" << std::endl;
    std::cout << "---------------------------------------" << std::endl;
    
    for (double x = 0.0; x <= 5.0; x += 1.0) {
        std::cout << "x: " << x << " | J0(x): " << SpecialFunctions::bessel_j0(x) << std::endl;
    }

    std::cout << "
Note: J0(2.4048) approx 0 (First root)." << std::endl;
    std::cout << "Calculated J0(2.4048): " << SpecialFunctions::bessel_j0(2.4048) << std::endl;

    return 0;
}
