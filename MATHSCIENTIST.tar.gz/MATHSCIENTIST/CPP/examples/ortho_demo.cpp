#include <iostream>
#include "../include/MathScientist/GramSchmidt.hpp"

int main() {
    using namespace MathScientist;

    std::vector<std::vector<double>> V = {
        {1, 1, 0},
        {1, 0, 1},
        {0, 1, 1}
    };

    std::cout << "MathScientist: Gram-Schmidt Orthonormalization" << std::endl;
    Orthonormalization<double>::process(V);

    for (const auto& vec : V) {
        std::cout << "[ ";
        for (double x : vec) std::cout << x << " ";
        std::cout << "]" << std::endl;
    }

    return 0;
}
