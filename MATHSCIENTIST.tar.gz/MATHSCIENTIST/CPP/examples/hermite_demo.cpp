#include <iostream>
#include <iomanip>
#include "../include/MathScientist/QuantumFunctions.hpp"

int main() {
    using namespace MathScientist;

    std::cout << "MathScientist: Hermite Polynomials H_n(x)" << std::endl;
    std::cout << "----------------------------------------" << std::endl;
    
    double x = 0.5;
    for (int n = 0; n <= 4; n++) {
        std::cout << "H_" << n << "(" << x << ") = " << std::fixed << std::setprecision(4) 
                  << QuantumFunctions::hermite(n, x) << std::endl;
    }

    std::cout << "
Analytical Check H_2(x) = 4x^2 - 2" << std::endl;
    std::cout << "H_2(0.5) = " << 4.0 * 0.25 - 2.0 << " (Expected: -1.0)" << std::endl;

    return 0;
}
