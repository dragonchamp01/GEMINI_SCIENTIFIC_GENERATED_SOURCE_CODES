#include <iostream>
#include "../include/MathScientist/TridiagonalSolver.hpp"

int main() {
    using namespace MathScientist;

    // Solve Ax = d where A is 3x3 tridiagonal:
    // [[2, -1, 0], [-1, 2, -1], [0, -1, 2]] * x = [1, 0, 1]
    std::vector<double> a = {-1.0, -1.0};
    std::vector<double> b = {2.0, 2.0, 2.0};
    std::vector<double> c = {-1.0, -1.0};
    std::vector<double> d = {1.0, 0.0, 1.0};

    std::cout << "MathScientist: Solving Tridiagonal System..." << std::endl;
    std::vector<double> x = ThomasSolver<double>::solve(a, b, c, d);

    std::cout << "Solution x: [ ";
    for (double val : x) std::cout << val << " ";
    std::cout << "]" << std::endl;
    std::cout << "Expected: [ 1 1 1 ]" << std::endl;

    return 0;
}
