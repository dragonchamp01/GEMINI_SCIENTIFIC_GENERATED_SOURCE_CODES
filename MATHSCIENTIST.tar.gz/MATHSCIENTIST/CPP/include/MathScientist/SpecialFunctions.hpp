/**
 * MathScientist SDK - C++ Special Functions
 * -----------------------------------------
 * Mathematical functions common in Physics and Engineering.
 */

#ifndef MATHSCIENTIST_SPECIAL_HPP
#define MATHSCIENTIST_SPECIAL_HPP

#include <cmath>
#include <vector>

namespace MathScientist {

    class SpecialFunctions {
    public:
        /**
         * @brief Zeroth order Bessel function J0(x) using series approximation.
         */
        static double bessel_j0(double x) {
            double sum = 1.0;
            double term = 1.0;
            for (int k = 1; k < 20; ++k) {
                term *= -x * x / (4.0 * k * k);
                sum += term;
                if (std::abs(term) < 1e-12) break;
            }
            return sum;
        }
    };
}

#endif
