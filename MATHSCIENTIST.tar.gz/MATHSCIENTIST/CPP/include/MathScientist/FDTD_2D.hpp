/**
 * MathScientist SDK - C++ FDTD 2D
 * --------------------------------
 * 2D Finite Difference Time Domain for EM waves.
 */

#ifndef MATHSCIENTIST_FDTD_HPP
#define MATHSCIENTIST_FDTD_HPP

#include <vector>
#include <iostream>

namespace MathScientist {

    class FDTD2D {
        size_t nx, ny;
        std::vector<std::vector<double>> ez, hx, hy;

    public:
        FDTD2D(size_t w, size_t h) : nx(w), ny(h), 
            ez(w, std::vector<double>(h, 0.0)),
            hx(w, std::vector<double>(h, 0.0)),
            hy(w, std::vector<double>(h, 0.0)) {}

        void update_h() {
            for (size_t i = 0; i < nx - 1; ++i)
                for (size_t j = 0; j < ny - 1; ++j) {
                    hx[i][j] -= 0.5 * (ez[i][j+1] - ez[i][j]);
                    hy[i][j] += 0.5 * (ez[i+1][j] - ez[i][j]);
                }
        }

        void update_e() {
            for (size_t i = 1; i < nx - 1; ++i)
                for (size_t j = 1; j < ny - 1; ++j) {
                    ez[i][j] += 0.5 * ((hy[i][j] - hy[i-1][j]) - (hx[i][j] - hx[i][j-1]));
                }
        }

        void set_source(size_t i, size_t j, double val) { ez[i][j] = val; }
        double get_field(size_t i, size_t j) { return ez[i][j]; }
    };
}

#endif
