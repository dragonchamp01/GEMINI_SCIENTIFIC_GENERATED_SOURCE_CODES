/**
 * MathScientist SDK - C++ Complex Calculus
 * ----------------------------------------
 * Numerical integration in the complex plane.
 */

#ifndef MATHSCIENTIST_COMPLEX_HPP
#define MATHSCIENTIST_COMPLEX_HPP

#include <complex>
#include <vector>
#include <functional>

namespace MathScientist {

    using Complex = std::complex<double>;

    class ComplexIntegrator {
    public:
        /**
         * @brief Circular contour integration.
         */
        static Complex integrate_circle(std::function<Complex(Complex)> f, Complex center, double radius, int n = 1000) {
            Complex sum(0, 0);
            double dt = 2.0 * M_PI / n;
            for (int i = 0; i < n; ++i) {
                double t = i * dt;
                Complex z = center + std::polar(radius, t);
                Complex dz = std::polar(radius, t + M_PI/2.0) * dt; // i*R*exp(it)dt
                sum += f(z) * dz;
            }
            return sum;
        }
    };
}

#endif
