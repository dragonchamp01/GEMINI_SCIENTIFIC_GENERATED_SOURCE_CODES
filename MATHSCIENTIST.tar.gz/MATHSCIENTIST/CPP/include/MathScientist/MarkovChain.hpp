/**
 * MathScientist SDK - C++ Markov Chain Module
 * -------------------------------------------
 * Stochastic processes and state transitions.
 */

#ifndef MATHSCIENTIST_MARKOV_HPP
#define MATHSCIENTIST_MARKOV_HPP

#include "LinearAlgebra.hpp"
#include <vector>
#include <iostream>

namespace MathScientist {

    class MarkovChain {
    public:
        /**
         * @brief Predicts the state distribution after N steps.
         * p_n = p_0 * P^n
         */
        template<typename T>
        static std::vector<T> predict_state(const std::vector<T>& initial_prob, const Matrix<T>& P, int steps) {
            std::vector<T> current = initial_prob;
            size_t n = initial_prob.size();

            for (int s = 0; s < steps; ++s) {
                std::vector<T> next(n, 0);
                for (size_t j = 0; j < n; ++j) {
                    for (size_t i = 0; i < n; ++i) {
                        next[j] += current[i] * P(i, j);
                    }
                }
                current = next;
            }
            return current;
        }
    };
}

#endif
