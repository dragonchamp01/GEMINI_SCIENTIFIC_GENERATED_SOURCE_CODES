/**
 * MathScientist SDK - C++ Quantum Special Functions
 * --------------------------------------------------
 * Orthogonal Polynomials used in Quantum Mechanics.
 */

#ifndef MATHSCIENTIST_QUANTUM_HPP
#define MATHSCIENTIST_QUANTUM_HPP

#include <vector>
#include <cmath>

namespace MathScientist {

    class QuantumFunctions {
    public:
        /**
         * @brief Generates Physicist's Hermite Polynomial H_n(x).
         * Uses the recurrence relation: H_{n+1}(x) = 2xH_n(x) - 2nH_{n-1}(x)
         */
        static double hermite(int n, double x) {
            if (n == 0) return 1.0;
            if (n == 1) return 2.0 * x;
            
            double h_prev = 1.0;
            double h_curr = 2.0 * x;
            double h_next = 0;
            
            for (int i = 1; i < n; i++) {
                h_next = 2.0 * x * h_curr - 2.0 * i * h_prev;
                h_prev = h_curr;
                h_curr = h_next;
            }
            return h_curr;
        }
    };
}

#endif
