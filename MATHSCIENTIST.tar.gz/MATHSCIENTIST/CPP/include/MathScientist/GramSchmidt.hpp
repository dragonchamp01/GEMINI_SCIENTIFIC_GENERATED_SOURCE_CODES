/**
 * MathScientist SDK - C++ Orthonormalization
 * -------------------------------------------
 * Modified Gram-Schmidt process for numerical stability.
 */

#ifndef MATHSCIENTIST_ORTHO_HPP
#define MATHSCIENTIST_ORTHO_HPP

#include <vector>
#include <cmath>
#include <iostream>

namespace MathScientist {

    template<typename T>
    class Orthonormalization {
    public:
        /**
         * @brief Standard Modified Gram-Schmidt.
         * @param basis List of vectors to be orthonormalized.
         */
        static void process(std::vector<std::vector<T>>& basis) {
            for (size_t i = 0; i < basis.size(); ++i) {
                // Normalize current vector
                T norm = 0;
                for (T val : basis[i]) norm += val * val;
                norm = std::sqrt(norm);
                for (T& val : basis[i]) val /= norm;

                // Project out from remaining vectors
                for (size_t j = i + 1; j < basis.size(); ++j) {
                    T dot = 0;
                    for (size_t k = 0; k < basis[i].size(); ++k)
                        dot += basis[i][k] * basis[j][k];
                    for (size_t k = 0; k < basis[i].size(); ++k)
                        basis[j][k] -= dot * basis[i][k];
                }
            }
        }
    };
}

#endif
