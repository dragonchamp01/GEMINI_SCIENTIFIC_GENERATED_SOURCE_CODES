/**
 * MathScientist SDK - C++ Eigenvalue Solver
 * -----------------------------------------
 * Power Iteration for finding the largest eigenvalue.
 */

#ifndef MATHSCIENTIST_EIGEN_HPP
#define MATHSCIENTIST_EIGEN_HPP

#include "LinearAlgebra.hpp"
#include <vector>
#include <cmath>

namespace MathScientist {

    template<typename T>
    class EigenSolver {
    public:
        /**
         * @brief Finds dominant eigenvalue using Power Iteration.
         */
        static T power_iteration(const Matrix<T>& A, int iters = 100) {
            size_t n = 2; // Fixed for 2x2 demo
            std::vector<T> b(n, 1.0); // Initial guess
            
            T eigenvalue = 0;
            for (int k = 0; k < iters; ++k) {
                std::vector<T> b_next(n, 0);
                // b_next = A * b
                for (size_t i = 0; i < n; ++i)
                    for (size_t j = 0; j < n; ++j)
                        b_next[i] += A(i, j) * b[j];
                
                // Normalize
                T norm = 0;
                for (T val : b_next) norm += val * val;
                norm = std::sqrt(norm);
                for (size_t i = 0; i < n; ++i) b[i] = b_next[i] / norm;
                
                eigenvalue = norm;
            }
            return eigenvalue;
        }
    };
}

#endif
