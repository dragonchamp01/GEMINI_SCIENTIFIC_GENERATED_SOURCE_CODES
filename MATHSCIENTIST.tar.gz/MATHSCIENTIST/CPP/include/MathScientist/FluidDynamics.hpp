/**
 * MathScientist SDK - C++ Fluid Dynamics
 * ---------------------------------------
 * Stream functions and Potential Flow solvers.
 */

#ifndef MATHSCIENTIST_FLUIDS_HPP
#define MATHSCIENTIST_FLUIDS_HPP

#include <cmath>
#include <vector>

namespace MathScientist {

    struct VelocityField {
        double u, v;
    };

    class PotentialFlow {
    public:
        /**
         * @brief Source/Sink potential at point (x, y)
         */
        static double get_source_potential(double strength, double x, double y, double x0, double y0) {
            double r = std::sqrt(std::pow(x - x0, 2) + std::pow(y - y0, 2));
            if (r < 1e-9) return 0;
            return (strength / (2.0 * M_PI)) * std::log(r);
        }

        /**
         * @brief Uniform flow velocity components
         */
        static VelocityField get_uniform_flow(double U, double alpha_deg) {
            double alpha = alpha_deg * M_PI / 180.0;
            return { U * std::cos(alpha), U * std::sin(alpha) };
        }
    };
}

#endif
