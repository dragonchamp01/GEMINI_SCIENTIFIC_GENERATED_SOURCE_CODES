/**
 * MathScientist SDK - C++ Tridiagonal Solver
 * -------------------------------------------
 * Thomas Algorithm (TDMA) for solving Ax = d.
 */

#ifndef MATHSCIENTIST_THOMAS_HPP
#define MATHSCIENTIST_THOMAS_HPP

#include <vector>
#include <iostream>

namespace MathScientist {

    template<typename T>
    class ThomasSolver {
    public:
        /**
         * @brief Solves tridiagonal system.
         * @param a lower diagonal (size n-1)
         * @param b main diagonal (size n)
         * @param c upper diagonal (size n-1)
         * @param d RHS vector (size n)
         */
        static std::vector<T> solve(std::vector<T> a, std::vector<T> b, std::vector<T> c, std::vector<T> d) {
            size_t n = b.size();
            std::vector<T> x(n);

            // Forward elimination
            for (size_t i = 1; i < n; i++) {
                T m = a[i-1] / b[i-1];
                b[i] = b[i] - m * c[i-1];
                d[i] = d[i] - m * d[i-1];
            }

            // Backward substitution
            x[n-1] = d[n-1] / b[n-1];
            for (int i = n - 2; i >= 0; i--) {
                x[i] = (d[i] - c[i] * x[i+1]) / b[i];
            }

            return x;
        }
    };
}

#endif
