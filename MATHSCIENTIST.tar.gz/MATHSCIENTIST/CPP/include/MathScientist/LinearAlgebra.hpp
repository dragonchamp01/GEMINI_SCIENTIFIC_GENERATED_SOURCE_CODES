/**
 * MathScientist SDK - C++ Linear Algebra
 * --------------------------------------
 * Template-based high-performance matrix and vector operations.
 */

#ifndef MATHSCIENTIST_LA_HPP
#define MATHSCIENTIST_LA_HPP

#include <vector>
#include <iostream>
#include <cmath>
#include <stdexcept>

namespace MathScientist {

    template<typename T>
    class Matrix {
        size_t rows, cols;
        std::vector<T> data;

    public:
        Matrix(size_t r, size_t c) : rows(r), cols(c), data(r * c, 0) {}

        T& operator()(size_t r, size_t c) { return data[r * cols + c]; }
        const T& operator()(size_t r, size_t c) const { return data[r * cols + c]; }

        Matrix operator*(const Matrix& other) const {
            if (cols != other.rows) throw std::runtime_error("Dimension mismatch");
            Matrix res(rows, other.cols);
            for (size_t i = 0; i < rows; ++i)
                for (size_t j = 0; j < other.cols; ++j)
                    for (size_t k = 0; k < cols; ++k)
                        res(i, j) += (*this)(i, k) * other(k, j);
            return res;
        }

        void print() const {
            for (size_t i = 0; i < rows; ++i) {
                for (size_t j = 0; j < cols; ++j)
                    std::cout << (*this)(i, j) << " ";
                std::cout << std::endl;
            }
        }
    };
}

#endif
