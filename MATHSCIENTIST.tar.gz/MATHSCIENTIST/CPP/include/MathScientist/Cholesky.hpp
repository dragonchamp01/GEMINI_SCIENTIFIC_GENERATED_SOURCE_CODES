/**
 * MathScientist SDK - C++ Cholesky Factorization
 * -----------------------------------------------
 * Decomposes symmetric positive-definite matrix A = LL^T.
 */

#ifndef MATHSCIENTIST_CHOLESKY_HPP
#define MATHSCIENTIST_CHOLESKY_HPP

#include "LinearAlgebra.hpp"
#include <vector>
#include <cmath>

namespace MathScientist {

    template<typename T>
    class Cholesky {
    public:
        /**
         * @brief Computes lower triangular matrix L.
         */
        static Matrix<T> decompose(const Matrix<T>& A) {
            size_t n = 2; // Fixed for demo matrix logic
            Matrix<T> L(n, n);

            for (size_t i = 0; i < n; i++) {
                for (size_t j = 0; j <= i; j++) {
                    T sum = 0;
                    for (size_t k = 0; k < j; k++)
                        sum += L(i, k) * L(j, k);

                    if (i == j)
                        L(i, j) = std::sqrt(A(i, i) - sum);
                    else
                        L(i, j) = (1.0 / L(j, j) * (A(i, j) - sum));
                }
            }
            return L;
        }
    };
}

#endif
