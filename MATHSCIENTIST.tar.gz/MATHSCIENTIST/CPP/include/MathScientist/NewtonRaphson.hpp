/**
 * MathScientist SDK - C++ Newton-Raphson Solver
 * ---------------------------------------------
 * Generic root finding for various numeric types.
 */

#ifndef MATHSCIENTIST_NEWTON_HPP
#define MATHSCIENTIST_NEWTON_HPP

#include <cmath>
#include <functional>

namespace MathScientist {

    template<typename T>
    class NewtonRaphson {
    public:
        static T solve(std::function<T(T)> f, std::function<T(T)> df, T x0, T tol = 1e-9, int max_iter = 50) {
            T x = x0;
            for (int i = 0; i < max_iter; ++i) {
                T fx = f(x);
                T dfx = df(x);
                T delta = fx / dfx;
                x -= delta;
                if (std::abs(delta) < tol) break;
            }
            return x;
        }
    };
}

#endif
