/**
 * MathScientist SDK - C++ Romberg Integration
 * --------------------------------------------
 * High-precision integration using Richardson extrapolation.
 */

#ifndef MATHSCIENTIST_ROMBERG_HPP
#define MATHSCIENTIST_ROMBERG_HPP

#include <vector>
#include <cmath>
#include <functional>

namespace MathScientist {

    class Romberg {
    public:
        /**
         * @brief Integrates f from a to b with accuracy levels k.
         */
        static double integrate(std::function<double(double)> f, double a, double b, int k = 5) {
            std::vector<std::vector<double>> R(k, std::vector<double>(k));
            double h = b - a;

            // R(0,0) = h/2 * (f(a) + f(b))
            R[0][0] = 0.5 * h * (f(a) + f(b));

            for (int i = 1; i < k; ++i) {
                h /= 2.0;
                double sum_f = 0;
                for (int j = 1; j <= std::pow(2, i - 1); ++j) {
                    sum_f += f(a + (2 * j - 1) * h);
                }
                R[i][0] = 0.5 * R[i-1][0] + h * sum_f;

                for (int j = 1; j <= i; ++j) {
                    R[i][j] = R[i][j-1] + (R[i][j-1] - R[i-1][j-1]) / (std::pow(4, j) - 1.0);
                }
            }
            return R[k-1][k-1];
        }
    };
}

#endif
