"""
[Alpha Quantum SDK - Error Mitigation]
Topic: Zero-Noise Extrapolation (ZNE)
Purpose: Estimating the noise-free expectation value of an observable.
"""

import numpy as np
from QUANTUM_SDK.Python.gemini_noise import DensityMatrixSimulator, NoiseModel

def simulate_with_noise(p_error):
    """Simulates a noisy H-gate preparation and Z-measurement."""
    sim = DensityMatrixSimulator(1)
    
    # Ideal H
    H = np.array([[1, 1], [1, -1]]) / np.sqrt(2)
    sim.apply_unitary(H)
    
    # Apply Noise
    if p_error > 0:
        kraus = NoiseModel.depolarizing_error(p_error)
        sim.apply_kraus(kraus, 0)
        
    # Expectation <Z> = Tr(rho * Z)
    Z = np.array([[1, 0], [0, -1]])
    return np.trace(sim.rho @ Z).real

def run_zne():
    print("--- Zero-Noise Extrapolation (ZNE) Simulation ---")
    
    # Noise levels (scaling factors)
    noise_levels = [0.01, 0.02, 0.03]
    results = []
    
    for p in noise_levels:
        val = simulate_with_noise(p)
        results.append(val)
        print(f"Noise p={p:.3f} -> <Z> = {val:.6f}")
        
    # Richardson Extrapolation (Linear fit to zero)
    # Estimate value at p=0
    z = np.polyfit(noise_levels, results, 1)
    noiseless_estimate = z[1] # Intercept
    
    ideal = simulate_with_noise(0.0)
    
    print(f"
Ideal <Z> (p=0):      {ideal:.6f}")
    print(f"ZNE Estimate (p->0): {noiseless_estimate:.6f}")
    print(f"Error Reduction:     {np.abs(results[0]-ideal)/np.abs(noiseless_estimate-ideal):.2f}x improvement over lowest noise run")

if __name__ == "__main__":
    run_zne()
