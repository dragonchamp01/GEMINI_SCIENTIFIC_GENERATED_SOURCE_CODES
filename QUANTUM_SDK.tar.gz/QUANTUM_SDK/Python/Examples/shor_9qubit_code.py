"""
[Alpha Quantum SDK - Error Correction]
Topic: Shor's 9-Qubit Code (The First Fault-Tolerant Code)
Purpose: Protecting a logical qubit against any single-qubit error (bit/phase flip).
"""

import numpy as np
from ..gemini_circuit import QuantumCircuit

class ShorCode:
    def __init__(self):
        print("Shor 9-Qubit Code (QEC) initialized.")

    def encode(self, initial_state_idx=0):
        """
        Encodes 1 logical qubit into 9 physical qubits using the standard Shor circuit.
        """
        # 9 qubits total
        qc = QuantumCircuit(9)
        
        # 1. Start with initial state (e.g., |1> or |0>)
        if initial_state_idx == 1:
            qc.x(0)
            
        # 2. Phase-flip (Outer) Encoding
        qc.cx(0, 3)
        qc.cx(0, 6)
        qc.h(0)
        qc.h(3)
        qc.h(6)
        
        # 3. Bit-flip (Inner) Encoding on each of the 3 blocks
        # Block 1 (0,1,2)
        qc.cx(0, 1)
        qc.cx(0, 2)
        # Block 2 (3,4,5)
        qc.cx(3, 4)
        qc.cx(3, 5)
        # Block 3 (6,7,8)
        qc.cx(6, 7)
        qc.cx(6, 8)
        
        # 4. Simulate the statevector
        state = qc.simulate()
        return state

if __name__ == "__main__":
    qec = ShorCode()
    
    # Encode |0>L
    print("Encoding Logical |0> into 9-qubit state...")
    state0 = qec.encode(0)
    
    # Encode |1>L
    print("Encoding Logical |1> into 9-qubit state...")
    state1 = qec.encode(1)
    
    # Check if they are orthogonal
    overlap = np.vdot(state0, state1)
    print(f"Logical States Overlap (<0L|1L>): {np.abs(overlap):.3f}")
    
    # Check some state amplitudes
    # |0>L should have components in indices where bits are flipped in triplets
    print("\nNon-zero amplitude indices for |0>L:")
    for i, amp in enumerate(state0):
        if np.abs(amp) > 1e-6:
            # Format index as 9-bit binary
            binary = format(i, '09b')
            print(f"| {binary} > : {np.round(amp, 3)}")

