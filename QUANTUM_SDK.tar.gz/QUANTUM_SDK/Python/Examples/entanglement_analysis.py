"""
[Alpha Quantum SDK]
Topic: Entanglement Analysis via Partial Trace (Python)
Purpose: Verifying the mixedness of a subsystem of an entangled state.
"""

import numpy as np
from QUANTUM_SDK.Python.gemini_noise import DensityMatrixSimulator

def analyze_bell_entanglement():
    print("--- Bell State Entanglement Analysis (Python) ---")
    
    # 1. Prepare Bell State |Phi+> = (|00> + |11>) / sqrt(2)
    sim = DensityMatrixSimulator(2)
    
    # H on q0
    H = np.array([[1, 1], [1, -1]]) / np.sqrt(2)
    H_full = np.kron(np.eye(2), H) # Target bit 0
    sim.apply_unitary(H_full)
    
    # CX from q0 to q1
    CX = np.array([
        [1, 0, 0, 0],
        [0, 1, 0, 0],
        [0, 0, 0, 1],
        [0, 0, 1, 0]
    ])
    sim.apply_unitary(CX)
    
    print("Created Bell State |Phi+>.")
    print(f"Full state purity: {sim.get_purity():.4f} (Expected: 1.0)")
    
    # 2. Compute reduced density matrix for qubit 0
    rho_0 = sim.partial_trace([0])
    print("
Reduced Density Matrix rho_0 (Tracing out q1):")
    print(np.round(rho_0, 3))
    
    # 3. Analyze Purity
    purity_0 = np.trace(rho_0 @ rho_0).real
    print(f"
Subsystem Purity: {purity_0:.4f} (Expected: 0.5 for max entanglement)")
    
    if np.isclose(purity_0, 0.5):
        print("SUCCESS: Subsystem is maximally mixed, confirming maximal entanglement.")

if __name__ == "__main__":
    analyze_bell_entanglement()
