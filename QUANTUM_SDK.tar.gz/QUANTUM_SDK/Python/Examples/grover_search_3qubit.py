"""
[Alpha Quantum SDK]
Topic: 3-Qubit Grover Search Algorithm
Target State: |7> (|111>)
Purpose: Demonstrating the use of Multi-Control Phase (MCP) gates.
"""

import numpy as np
from QUANTUM_SDK.Python.gemini_circuit import QuantumCircuit

def grover_search_3qubit():
    n = 3
    qc = QuantumCircuit(n)
    
    # 1. Superposition
    for i in range(n):
        qc.h(i)
        
    # Number of iterations: approx sqrt(2^n) = sqrt(8) ~ 2
    iterations = 2
    
    for _ in range(iterations):
        # 2. Oracle (Flip |111> phase)
        # Using MCP with q0, q1 as controls and q2 as target
        qc.mcp([0, 1], 2, np.pi)
        
        # 3. Diffuser
        for i in range(n): qc.h(i)
        for i in range(n): qc.x(i)
        
        # Multi-controlled Z on all bits
        qc.mcp([0, 1], 2, np.pi)
        
        for i in range(n): qc.x(i)
        for i in range(n): qc.h(i)
        
    state = qc.simulate()
    probs = qc.get_probabilities()
    
    return state, probs

if __name__ == "__main__":
    print("--- 3-Qubit Grover Search (|111>) ---")
    state, probabilities = grover_search_3qubit()
    
    for i, p in enumerate(probabilities):
        print(f"| {format(i, '03b')} > : {p:.4f}")
        
    if probabilities[7] > 0.9:
        print("
SUCCESS: Target state |111> found with high probability!")
