"""
[Alpha Quantum SDK - Time Dynamics]
Topic: Trotter-Suzuki Time Evolution
System: 1D Transverse Field Ising Model (TFIM)
Hamiltonian: H = -J * sum(Zi * Zi+1) - h * sum(Xi)
"""

import numpy as np
from QUANTUM_SDK.Python.gemini_circuit import QuantumCircuit

class TFIMSimulation:
    def __init__(self, n_qubits, J=1.0, h=1.0):
        self.n = n_qubits
        self.J = J
        self.h = h

    def trotter_step(self, qc, dt):
        """Applies a single first-order Trotter step for e^-iHdt."""
        # 1. ZZ Interaction: e^i J dt ZZ
        # H_int = -J * ZZ => e^-i H_int dt = e^i J dt ZZ
        # Angle for RZ is -2 * (J * dt)
        phi_zz = -2 * self.J * dt
        for i in range(self.n - 1):
            qc.cx(i, i+1)
            qc.rz(i+1, phi_zz)
            qc.cx(i, i+1)
            
        # 2. Transverse Field: e^i h dt X
        # H_field = -h * X => e^-i H_field dt = e^i h dt X
        # Angle for RX is -2 * (h * dt)
        phi_x = -2 * self.h * dt
        for i in range(self.n):
            qc.rx(i, phi_x)

    def simulate(self, t_final, steps):
        dt = t_final / steps
        qc = QuantumCircuit(self.n)
        
        # Start in |00...0> (Ferromagnetic state)
        
        for _ in range(steps):
            self.trotter_step(qc, dt)
            
        return qc.simulate()

if __name__ == "__main__":
    n = 4
    sim = TFIMSimulation(n, J=1.0, h=0.5)
    
    t_total = 1.0
    n_steps = 20
    
    print(f"--- TFIM Time Evolution ({n} Qubits) ---")
    print(f"Parameters: J={sim.J}, h={sim.h}, T={t_total}")
    
    final_state = sim.simulate(t_total, n_steps)
    probs = np.abs(final_state)**2
    
    print("
Final State Sample Probabilities:")
    for i in [0, 1, 8, 15]: # Some basis states
        print(f"| {format(i, '04b')} > : {probs[i]:.4f}")
        
    magnetization = 0
    for i, p in enumerate(probs):
        # Count bits set to 1
        n_ones = bin(i).count('1')
        n_zeros = n - n_ones
        # Magnetization per qubit: (zeros - ones) / n
        magnetization += p * (n_zeros - n_ones) / n
        
    print(f"
Average Magnetization <Z>: {magnetization:.4f}")
