"""
[Alpha Quantum SDK - Quantum Algorithms]
Topic: Deutsch-Jozsa Algorithm
Purpose: Determining if a function is constant or balanced in one query.
"""

import numpy as np
from QUANTUM_SDK.Python.gemini_circuit import QuantumCircuit

def run_deutsch_jozsa(n_bits, oracle_type='balanced'):
    total_qubits = n_bits + 1
    qc = QuantumCircuit(total_qubits)
    
    # 1. Initialize qubits
    # Input qubits to |+>, Ancilla to |->
    for i in range(n_bits):
        qc.h(i)
    qc.x(n_bits)
    qc.h(n_bits)
    
    # 2. Apply Oracle
    if oracle_type == 'balanced':
        # Balanced oracle: f(x) = x_0 (simplified)
        qc.cx(0, n_bits)
    elif oracle_type == 'constant':
        # Constant oracle: f(x) = 1
        # (For f(x)=0, we do nothing)
        qc.x(n_bits)
        
    # 3. Final Hadamard on input qubits
    for i in range(n_bits):
        qc.h(i)
        
    # 4. Simulate and measure
    qc.simulate()
    measured_idx = qc.measure()
    
    # Check input register (bits 0 to n_bits-1)
    input_state = measured_idx & ((1 << n_bits) - 1)
    
    return input_state == 0 # True if constant, False if balanced

if __name__ == "__main__":
    n = 3
    print(f"--- Deutsch-Jozsa Algorithm ({n} bits) ---")
    
    res_c = run_deutsch_jozsa(n, 'constant')
    print(f"Oracle: Constant -> Result: {'Constant' if res_c else 'Balanced'}")
    
    res_b = run_deutsch_jozsa(n, 'balanced')
    print(f"Oracle: Balanced -> Result: {'Constant' if res_b else 'Balanced'}")
