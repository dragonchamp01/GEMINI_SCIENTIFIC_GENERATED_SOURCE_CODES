"""
[Alpha Quantum SDK - Benchmarking]
Topic: Quantum Volume (QV)
Purpose: Measuring the capability of the simulated quantum engine.
Algorithm: Heavy Output Generation from Random Circuits.
"""

import numpy as np
from QUANTUM_SDK.Python.gemini_circuit import QuantumCircuit

def get_heavy_outputs(probabilities):
    """Indices of states with probability greater than the median."""
    median = np.median(probabilities)
    return [i for i, p in enumerate(probabilities) if p > median]

def run_qv_test(n_qubits, n_trials=100):
    print(f"--- Quantum Volume Benchmark: {n_qubits} Qubits ---")
    
    heavy_output_count = 0
    
    for trial in range(n_trials):
        qc = QuantumCircuit(n_qubits)
        
        # 1. Generate Random Unitaries (Simplified as random gates)
        for layer in range(n_qubits):
            # Random permutations/rotations
            for q in range(n_qubits):
                qc.ry(q, np.random.rand() * 2 * np.pi)
            
            # Entanglement layer
            perm = np.random.permutation(n_qubits)
            for i in range(0, n_qubits - 1, 2):
                qc.cx(int(perm[i]), int(perm[i+1]))
        
        # 2. Simulate
        qc.simulate()
        probs = qc.get_probabilities()
        
        # 3. Check Heavy Output
        heavy_indices = get_heavy_outputs(probs)
        
        # In a real test, we would measure and see if the outcome is 'heavy'
        # Here we sum the probability of the heavy outcomes
        heavy_prob_total = sum(probs[i] for i in heavy_indices)
        
        if heavy_prob_total > 2/3:
            heavy_output_count += 1
            
    success_rate = heavy_output_count / n_trials
    print(f"Success Rate: {success_rate:.2f} (Threshold: 2/3)")
    return success_rate > 2/3

if __name__ == "__main__":
    for n in range(2, 6):
        passed = run_qv_test(n, n_trials=50)
        if passed:
            print(f"PASSED: Log2(QV) >= {n}")
        else:
            print(f"FAILED: Max volume reached at {n-1} qubits.")
            break
