"""
[Alpha Quantum SDK - Cryptography]
Topic: BB84 Quantum Key Distribution Protocol
Purpose: Realizing secure QKD via the QuantumCircuit simulator.
"""

import numpy as np
from ..gemini_circuit import QuantumCircuit

class BB84Simulation:
    def __init__(self, n_bits):
        self.n = n_bits
        self.alice_bases = np.random.randint(0, 2, n_bits)
        self.alice_bits = np.random.randint(0, 2, n_bits)
        self.bob_bases = np.random.randint(0, 2, n_bits)

    def prepare_qubit(self, bit, basis):
        """Alice prepares a qubit: 0/1 in Z (0) or X (1) basis."""
        qc = QuantumCircuit(1)
        if bit == 1:
            qc.x(0)
        if basis == 1: # X basis (Diagonal)
            qc.h(0)
        return qc

    def bob_measures(self, qc, basis):
        """Bob measures a qubit in his chosen basis."""
        if basis == 1: # X basis
            qc.h(0)
        qc.simulate()
        return qc.measure()

    def simulate_transmission(self):
        """Alice sends qubits, Bob measures them."""
        bob_bits = []
        for i in range(self.n):
            qc = self.prepare_qubit(self.alice_bits[i], self.alice_bases[i])
            bit = self.bob_measures(qc, self.bob_bases[i])
            bob_bits.append(bit)
        return np.array(bob_bits)

    def sift_keys(self, bob_bits):
        """Keep bits where Alice's and Bob's bases matched."""
        matching = (self.alice_bases == self.bob_bases)
        return self.alice_bits[matching], bob_bits[matching]

if __name__ == "__main__":
    n = 50
    sim = BB84Simulation(n)
    bob_raw_bits = sim.simulate_transmission()
    a_key, b_key = sim.sift_keys(bob_raw_bits)
    
    print(f"--- BB84 Protocol with Gemini SDK ---")
    print(f"Bits sent: {n}")
    print(f"Sifted key length: {len(a_key)}")
    print(f"Alice Key: {a_key}")
    print(f"Bob   Key: {b_key}")
    print(f"Keys match? {np.array_equal(a_key, b_key)}")

