"""
[Alpha Quantum SDK - Quantum Chemistry]
Topic: VQE Molecular Model for H2
Purpose: Finding the ground state energy of Hydrogen molecule using 2 qubits.
Hamiltonian: Jordan-Wigner mapped H2 at 0.75 Angstrom.
"""

import numpy as np
from scipy.optimize import minimize
from QUANTUM_SDK.Python.gemini_circuit import QuantumCircuit

class H2VQE:
    def __init__(self):
        # Hamiltonian coefficients for H2 at 0.75A (simplified)
        self.g0 = -0.8126
        self.g1 = 0.1712
        self.g2 = 0.1712
        self.g3 = 0.1205
        self.g4 = 0.0453
        self.g5 = 0.0453

    def get_hamiltonian_matrix(self):
        """Constructs the 4x4 Hamiltonian matrix."""
        I = np.eye(2)
        X = np.array([[0, 1], [1, 0]])
        Y = np.array([[0, -1j], [1j, 0]])
        Z = np.array([[1, 0], [0, -1]])
        
        II = np.kron(I, I)
        ZI = np.kron(Z, I)
        IZ = np.kron(I, Z)
        ZZ = np.kron(Z, Z)
        XX = np.kron(X, X)
        YY = np.kron(Y, Y)
        
        H = (self.g0 * II + self.g1 * ZI + self.g2 * IZ + 
             self.g3 * ZZ + self.g4 * XX + self.g5 * YY)
        return H

    def ansatz(self, theta):
        """Simple chemistry-inspired ansatz: |01> -> rotations -> entanglement."""
        qc = QuantumCircuit(2)
        # Start in |01> (one electron per orbital in simplified model)
        qc.x(0) 
        
        qc.ry(0, theta[0])
        qc.ry(1, theta[1])
        qc.cx(0, 1)
        qc.ry(0, theta[2])
        
        return qc.simulate()

    def energy_expectation(self, theta, H):
        psi = self.ansatz(theta)
        return np.vdot(psi, H @ psi).real

    def solve(self):
        H = self.get_hamiltonian_matrix()
        # Initial guess for 3 parameters
        x0 = np.random.rand(3) * 0.1
        
        print("Optimizing H2 Molecular Energy...")
        res = minimize(self.energy_expectation, x0, args=(H,), method='COBYLA')
        
        exact = np.min(np.linalg.eigvalsh(H))
        
        return res.fun, exact

if __name__ == "__main__":
    vqe_h2 = H2VQE()
    computed_energy, exact_energy = vqe_h2.solve()
    
    print("
--- H2 Molecule VQE Results ---")
    print(f"Computed Ground State Energy: {computed_energy:.6f} Hartree")
    print(f"Exact Diagonalization:       {exact_energy:.6f} Hartree")
    print(f"Error:                       {np.abs(computed_energy - exact_energy):.6e}")
    print(f"Chemical Accuracy (1.6e-3):  {'MET' if np.abs(computed_energy - exact_energy) < 1.6e-3 else 'NOT MET'}")
