"""
[Alpha Quantum SDK - Advanced Research]
Topic: Variational Quantum Eigensolver (VQE) with Gemini SDK
Purpose: Finding the ground state energy of a 2-qubit Hamiltonian.
"""

import numpy as np
from scipy.optimize import minimize
from ..gemini_circuit import QuantumCircuit

class VQESimulator:
    def __init__(self, Hamiltonian):
        self.H = Hamiltonian
        self.n_qubits = int(np.log2(Hamiltonian.shape[0]))

    def ansatz_circuit(self, theta):
        """Hardware-efficient ansatz: 2-qubit rotation and entanglement."""
        qc = QuantumCircuit(self.n_qubits)
        
        # 1. Initial rotations
        qc.ry(0, theta[0])
        qc.ry(1, theta[1])
        
        # 2. Entanglement
        qc.cx(0, 1)
        
        # 3. Final rotations
        qc.ry(0, theta[2])
        qc.ry(1, theta[3])
        
        # 4. Simulate
        state = qc.simulate()
        return state

    def expectation_value(self, theta):
        """Calculates <psi(theta) | H | psi(theta)> using SDK simulator."""
        psi = self.ansatz_circuit(theta)
        # H is the target Hamiltonian matrix
        return np.vdot(psi, np.dot(self.H, psi)).real

    def solve(self, initial_guess):
        """Classic optimization loop using COBYLA."""
        res = minimize(self.expectation_value, x0=initial_guess, method='COBYLA')
        return res.fun, res.x

if __name__ == "__main__":
    # Mock Hamiltonian for a 2-qubit system (e.g., Ising model H = -Z0Z1 - X0 - X1)
    # 4x4 matrix for 2 qubits
    H_mock = np.array([
        [-1.0, -0.5, -0.5,  0.0],
        [-0.5,  1.0,  0.0, -0.5],
        [-0.5,  0.0,  1.0, -0.5],
        [ 0.0, -0.5, -0.5, -1.0]
    ], dtype=complex)
    
    vqe = VQESimulator(H_mock)
    
    # 4 parameters for our 2-qubit ansatz
    initial_guess = np.random.rand(4) * np.pi
    
    print("--- 2-Qubit VQE Optimization with Gemini SDK ---")
    energy, opt_params = vqe.solve(initial_guess)
    
    exact_energy = np.min(np.linalg.eigvalsh(H_mock))
    
    print(f"VQE Optimized Energy: {energy:.6f}")
    print(f"Exact Ground State:  {exact_energy:.6f}")
    print(f"Accuracy: {np.abs(energy - exact_energy):.6f}")
    print(f"Optimized Parameters (theta): {np.round(opt_params, 3)}")

