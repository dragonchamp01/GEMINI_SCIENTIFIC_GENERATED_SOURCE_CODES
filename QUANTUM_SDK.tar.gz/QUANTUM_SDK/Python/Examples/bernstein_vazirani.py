"""
[Alpha Quantum SDK - Quantum Algorithms]
Topic: Bernstein-Vazirani Algorithm
Purpose: Finding a hidden bitstring 's' in one query.
Function: f(x) = s . x mod 2
"""

import numpy as np
from QUANTUM_SDK.Python.gemini_circuit import QuantumCircuit

def run_bernstein_vazirani(hidden_s):
    n_bits = len(hidden_s)
    total_qubits = n_bits + 1
    qc = QuantumCircuit(total_qubits)
    
    # 1. Initialize
    for i in range(n_bits): qc.h(i)
    qc.x(n_bits)
    qc.h(n_bits)
    
    # 2. Oracle: f(x) = s . x
    for i, char in enumerate(reversed(hidden_s)):
        if char == '1':
            qc.cx(i, n_bits)
            
    # 3. Final Hadamard
    for i in range(n_bits): qc.h(i)
    
    # 4. Simulate and measure
    qc.simulate()
    measured_idx = qc.measure()
    
    # Extract hidden string from input bits
    found_s = bin(measured_idx & ((1 << n_bits) - 1))[2:].zfill(n_bits)
    # Reverse back if necessary (depends on indexing convention)
    return found_s[::-1]

if __name__ == "__main__":
    secret = "1011"
    print(f"--- Bernstein-Vazirani Algorithm ---")
    print(f"Secret String: {secret}")
    
    found = run_bernstein_vazirani(secret)
    print(f"Result Found:  {found}")
