"""
[Alpha Quantum SDK]
Topic: Grover Search Algorithm (2-qubit)
Search Target: |11> (binary 3)
"""

import numpy as np
from QUANTUM_SDK.Python.gemini_circuit import QuantumCircuit

def grover_search_2qubit():
    # 1. Initialize a 2-qubit circuit
    qc = QuantumCircuit(2)
    
    # 2. Superposition
    qc.h(0)
    qc.h(1)
    
    # 3. Oracle (flip |11>)
    qc.cz(0, 1)
    
    # 4. Diffuser
    qc.h(0)
    qc.h(1)
    qc.x(0)
    qc.x(1)
    qc.cz(0, 1)
    qc.x(0)
    qc.x(1)
    qc.h(0)
    qc.h(1)
    
    # 5. Simulate the state
    state = qc.simulate()
    probabilities = qc.get_probabilities()
    
    return state, probabilities

if __name__ == "__main__":
    state, probabilities = grover_search_2qubit()
    
    print("--- 2-Qubit Grover Search Target |11> ---")
    print(f"Statevector: {np.round(state, 3)}")
    print(f"Probabilities: {np.round(probabilities, 3)}")
    
    # Expected: Prob(|11>) = 1.0 (statevector should be -1.0 or 1.0 at index 3)
    target_prob = probabilities[3]
    print(f"Success Probability for |11>: {target_prob:.2f}")
