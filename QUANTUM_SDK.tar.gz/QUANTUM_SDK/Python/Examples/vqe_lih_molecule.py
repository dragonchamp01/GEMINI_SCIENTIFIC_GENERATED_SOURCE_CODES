"""
[Alpha Quantum SDK - Quantum Chemistry]
Topic: VQE Molecular Model for LiH
Purpose: Finding the ground state energy of Lithium Hydride using 4 qubits.
Hamiltonian: Jordan-Wigner mapped LiH at 1.45 Angstrom (Active Space reduced).
"""

import numpy as np
from scipy.optimize import minimize
from QUANTUM_SDK.Python.gemini_circuit import QuantumCircuit

class LiHVQE:
    def __init__(self):
        # Hamiltonian coefficients for LiH at 1.45A (Simplified 4-qubit model)
        # These are representative mock values for demonstration
        self.coeffs = {
            "IIII": -7.882,
            "ZIII": 0.172,
            "IZII": 0.172,
            "IIZI": -0.022,
            "IIIZ": -0.022,
            "ZZII": 0.011,
            "IIZZ": 0.011,
            "XXXX": 0.005,
            "YYYY": 0.005
        }

    def get_pauli_matrix(self, label):
        I = np.eye(2)
        X = np.array([[0, 1], [1, 0]])
        Y = np.array([[0, -1j], [1j, 0]])
        Z = np.array([[1, 0], [0, -1]])
        
        m_dict = {'I': I, 'X': X, 'Y': Y, 'Z': Z}
        res = 1
        for char in label:
            res = np.kron(res, m_dict[char])
        return res

    def get_hamiltonian_matrix(self):
        dim = 2**4
        H = np.zeros((dim, dim), dtype=complex)
        for label, val in self.coeffs.items():
            H += val * self.get_pauli_matrix(label)
        return H

    def ansatz(self, theta):
        """Hardware-efficient 4-qubit ansatz."""
        qc = QuantumCircuit(4)
        # Hartree-Fock starting state |1100>
        qc.x(0)
        qc.x(1)
        
        # Layer 1: Rotations
        for i in range(4):
            qc.ry(i, theta[i])
            
        # Layer 2: Entanglement (Linear chain)
        qc.cx(0, 1)
        qc.cx(1, 2)
        qc.cx(2, 3)
        
        # Layer 3: Final Rotations
        for i in range(4):
            qc.ry(i, theta[i+4])
            
        return qc.simulate()

    def energy_expectation(self, theta, H):
        psi = self.ansatz(theta)
        return np.vdot(psi, H @ psi).real

    def solve(self):
        H = self.get_hamiltonian_matrix()
        # 8 parameters for our 4-qubit ansatz
        x0 = np.random.rand(8) * 0.05
        
        print("Optimizing LiH Molecular Energy (4 Qubits)...")
        res = minimize(self.energy_expectation, x0, args=(H,), method='COBYLA')
        
        exact = np.min(np.linalg.eigvalsh(H))
        return res.fun, exact

if __name__ == "__main__":
    vqe_lih = LiHVQE()
    computed, exact = vqe_lih.solve()
    
    print("
--- LiH Molecule VQE Results ---")
    print(f"Computed Ground State: {computed:.6f} Hartree")
    print(f"Exact Diagonalization: {exact:.6f} Hartree")
    print(f"Accuracy:              {np.abs(computed - exact):.6e}")
