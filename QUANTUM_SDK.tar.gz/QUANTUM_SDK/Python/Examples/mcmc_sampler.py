"""
[Alpha Quantum SDK - Advanced Statistics]
Topic: Markov Chain Monte Carlo (MCMC) - Metropolis-Hastings
Purpose: Sampling from a target distribution when direct sampling is impossible.
"""

import numpy as np

def target_distribution(x):
    """Target: Mixture of two Gaussians (Conceptual energy surface)."""
    return 0.3 * np.exp(-0.5 * (x - 2)**2) + 0.7 * np.exp(-0.5 * (x - 7)**2)

def run_mcmc(iterations, start_x, step_size=1.0):
    samples = [start_x]
    current_x = start_x
    
    for _ in range(iterations):
        # 1. Propose a new state
        proposed_x = current_x + np.random.normal(0, step_size)
        
        # 2. Calculate acceptance ratio
        acceptance = min(1, target_distribution(proposed_x) / target_distribution(current_x))
        
        # 3. Accept or reject
        if np.random.rand() < acceptance:
            current_x = proposed_x
            
        samples.append(current_x)
        
    return np.array(samples)

if __name__ == "__main__":
    print("Running MCMC Sampler (10,000 steps)...")
    data = run_mcmc(10000, 5.0)
    print(f"Mean of samples: {np.mean(data):.4f}")
    print(f"Standard deviation: {np.std(data):.4f}")
