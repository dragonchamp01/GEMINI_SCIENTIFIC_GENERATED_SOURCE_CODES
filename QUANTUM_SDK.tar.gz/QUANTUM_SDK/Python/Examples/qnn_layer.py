"""
[Alpha Quantum SDK - Quantum Machine Learning]
Topic: Parameterized Quantum Circuit (QNN Layer)
Purpose: A variational layer where gate angles (theta) are trainable parameters.
"""

import numpy as np

class QNNLayer:
    def __init__(self, n_qubits):
        self.n = n_qubits
        self.params = np.random.uniform(0, 2*np.pi, n_qubits)

    def forward(self, input_state):
        """
        Applies R_y(theta) rotations to each qubit.
        """
        # Theta-dependent unitary
        U = 1
        for theta in self.params:
            Ry = np.array([[np.cos(theta/2), -np.sin(theta/2)],
                           [np.sin(theta/2),  np.cos(theta/2)]])
            U = np.kron(U, Ry)
            
        output_state = np.dot(U, input_state)
        return output_state

if __name__ == "__main__":
    n = 2
    layer = QNNLayer(n)
    init_state = np.zeros(2**n); init_state[0] = 1.0 # |00>
    
    out = layer.forward(init_state)
    print(f"QNN Layer Output State (theta={layer.params}):")
    print(np.round(out, 4))
