"""
[Alpha Quantum SDK - Quantum Algorithms]
Topic: Simon's Algorithm
Purpose: Finding a secret bitstring 's' such that f(x) = f(y) iff x ^ y in {0, s}.
"""

import numpy as np
from QUANTUM_SDK.Python.gemini_circuit import QuantumCircuit

def run_simon(n_bits, secret_s):
    """
    Executes one iteration of Simon's algorithm to find a vector y 
    such that y . s = 0 (mod 2).
    """
    total_qubits = 2 * n_bits
    qc = QuantumCircuit(total_qubits)
    
    # 1. Apply Hadamard gates to the first n qubits
    for i in range(n_bits):
        qc.h(i)
        
    # 2. Apply Simon's Oracle
    # Oracle: |x>|0> -> |x>|f(x)>
    # For a simple oracle, we can use:
    # If s=0, f(x)=x (one-to-one)
    # If s!=0, let k be the index of the first '1' in s. 
    # f(x) = x if x_k = 0, and f(x) = x ^ s if x_k = 1.
    
    if secret_s != 0:
        # Find the index of the first 1 in s
        k = 0
        while not ((secret_s >> k) & 1):
            k += 1
            
        # Implementation of f(x) = x if x_k=0, else x ^ s
        # This can be done by copying x to register 2, 
        # then if x_k=1, XORing s into register 2.
        
        # Copy x to second register
        for i in range(n_bits):
            qc.cx(i, n_bits + i)
            
        # If x_k=1, XOR s into second register
        for i in range(n_bits):
            if (secret_s >> i) & 1:
                qc.cx(k, n_bits + i)
    else:
        # s=0: f(x)=x
        for i in range(n_bits):
            qc.cx(i, n_bits + i)
            
    # 3. Apply Hadamard gates to the first n qubits again
    for i in range(n_bits):
        qc.h(i)
        
    # 4. Simulate and measure the first register
    qc.simulate()
    measured_idx = qc.measure()
    
    # The first n bits are the result
    y = measured_idx & ((1 << n_bits) - 1)
    return y

def solve_simon(n_bits, secret_s):
    """
    Collect enough y vectors and solve the system to find s.
    (Simplified for demonstration purposes)
    """
    print(f"Secret s: {bin(secret_s)[2:].zfill(n_bits)}")
    found_ys = []
    
    # Collect n-1 linearly independent vectors
    for _ in range(n_bits * 2): # Try a few times
        y = run_simon(n_bits, secret_s)
        if y not in found_ys and y != 0:
            found_ys.append(y)
            print(f"Found y: {bin(y)[2:].zfill(n_bits)}")
        if len(found_ys) >= n_bits - 1:
            break
            
    print(f"Collected {len(found_ys)} vectors.")
    # In a full implementation, we would use Gaussian elimination over GF(2).
    # For this example, we just verify the property y . s = 0 (mod 2).
    for y in found_ys:
        dot_product = 0
        for i in range(n_bits):
            dot_product ^= ((y >> i) & 1) & ((secret_s >> i) & 1)
        assert dot_product == 0, f"Error: y={y} does not satisfy y.s=0"
    
    print("Verification successful: All found y vectors satisfy y . s = 0 (mod 2).")

if __name__ == "__main__":
    n = 3
    s = 0b110 # Secret s
    print(f"--- Simon's Algorithm ({n} bits) ---")
    solve_simon(n, s)
