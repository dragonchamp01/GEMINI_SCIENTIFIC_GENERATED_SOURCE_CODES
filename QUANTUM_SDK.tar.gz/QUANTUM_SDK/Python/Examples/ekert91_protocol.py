"""
[Alpha Quantum SDK - Quantum Cryptography]
Topic: Ekert91 (E91) Protocol Simulation
Purpose: Secure key distribution using EPR pairs and the Gemini SDK.
"""

import numpy as np
from ..gemini_circuit import QuantumCircuit

class E91Simulation:
    def __init__(self, n_pairs):
        self.n = n_pairs
        # Bases for Alice (0, pi/8, pi/4) and Bob (0, pi/8, -pi/8)
        self.alice_bases = np.random.randint(0, 3, n_pairs)
        self.bob_bases = np.random.randint(0, 3, n_pairs)
        self.angles = [0, np.pi/8, np.pi/4, -np.pi/8]
        
    def measure_epr_pair(self, basis_a, basis_b):
        """Simulates measurement of an entangled singlet state |psi-> using SDK."""
        qc = QuantumCircuit(2)
        
        # 1. Create singlet state (|01> - |10>) / sqrt(2)
        qc.x(0)
        qc.h(0)
        qc.cx(0, 1)
        qc.z(1) # Final touch for singlet state
        
        # 2. Rotate to chosen bases
        qc.ry(0, self.angles[basis_a])
        qc.ry(1, self.angles[basis_b])
        
        # 3. Measure
        qc.simulate()
        idx = qc.measure()
        
        # idx is binary: 00 -> 0, 01 -> 1, 10 -> 2, 11 -> 3
        bit_a = (idx >> 1) & 1
        bit_b = idx & 1
        return bit_a, bit_b

    def run(self):
        a_results = []
        b_results = []
        
        for i in range(self.n):
            ra, rb = self.measure_epr_pair(self.alice_bases[i], self.bob_bases[i])
            a_results.append(ra)
            b_results.append(rb)
            
        return np.array(a_results), np.array(b_results)

if __name__ == "__main__":
    n = 20
    sim = E91Simulation(n)
    a_res, b_res = sim.run()
    
    # Sifting: Keep bits where bases matched
    matches = (sim.alice_bases == sim.bob_bases)
    key_a = a_res[matches]
    key_b = b_res[matches]
    
    print(f"--- E91 Protocol with Gemini SDK ---")
    print(f"EPR pairs processed: {n}")
    print(f"Matching Bases: {len(key_a)}")
    print(f"Alice Key: {key_a}")
    print(f"Bob   Key: {key_b}")

