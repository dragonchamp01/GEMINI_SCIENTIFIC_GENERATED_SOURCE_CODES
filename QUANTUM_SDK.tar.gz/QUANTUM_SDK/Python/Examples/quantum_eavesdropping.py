"""
[Alpha Quantum SDK - Quantum Security]
Topic: Eavesdropping Detection Logic
Purpose: Analyzing Quantum Bit Error Rate (QBER) to detect intercept-resend attacks.
"""

import numpy as np

def simulate_eve_impact(n_qubits):
    """
    Simulates Eve measuring every qubit in a random basis before Bob.
    """
    # 0 for Z, 1 for X
    alice_bases = np.random.randint(0, 2, n_qubits)
    alice_bits = np.random.randint(0, 2, n_qubits)
    
    eve_bases = np.random.randint(0, 2, n_qubits)
    bob_bases = np.random.randint(0, 2, n_qubits)
    
    errors = 0
    sifted_count = 0
    
    for i in range(n_qubits):
        if alice_bases[i] == bob_bases[i]:
            sifted_count += 1
            # If Eve picked wrong basis, she forces a random outcome for Bob
            if alice_bases[i] != eve_bases[i]:
                if np.random.randint(0, 2) != alice_bits[i]:
                    errors += 1
                    
    qber = errors / sifted_count if sifted_count > 0 else 0
    return qber

if __name__ == "__main__":
    n = 1000
    qber = simulate_eve_impact(n)
    print(f"BB84 Eavesdropping Analysis (Eve intercepts everything)")
    print(f"Observed QBER: {qber*100:.2f}%")
    print(f"Threshold for Secure Key: 11% (Standard)")
    if qber > 0.11:
        print("RESULT: ALARM! High QBER detected. Eavesdropper present.")
