"""
[Alpha Quantum SDK]
Topic: Multi-Controlled Unitary (MCU) Verification
Purpose: Ensuring any unitary can be controlled by multiple qubits.
"""

import numpy as np
from QUANTUM_SDK.Python.gemini_circuit import QuantumCircuit

def verify_mcu():
    print("--- Multi-Controlled Unitary (MCU) Verification ---")
    
    # Custom Unitary: e.g., an RX(pi) gate
    RX_pi = np.array([[0, -1j], [-1j, 0]], dtype=complex)
    
    # Test case: q0=1, q1=1 -> apply RX(pi) to q2
    qc = QuantumCircuit(3)
    qc.x(0)
    qc.x(1)
    
    qc.mcu([0, 1], 2, RX_pi)
    
    state = qc.simulate()
    probs = qc.get_probabilities()
    
    # Binary indices: 011 -> 3, 111 -> 7
    # Initial state was |011> (index 3)
    # After MCU(0,1,2) with RX(pi), it should be |111> (index 7)
    print(f"Prob(|011>): {probs[3]:.4f}")
    print(f"Prob(|111>): {probs[7]:.4f}")
    
    if probs[7] > 0.99:
        print("
SUCCESS: MCU correctly applied the unitary when controls were set.")
    else:
        print("
FAILURE: MCU logic error.")

if __name__ == "__main__":
    verify_mcu()
