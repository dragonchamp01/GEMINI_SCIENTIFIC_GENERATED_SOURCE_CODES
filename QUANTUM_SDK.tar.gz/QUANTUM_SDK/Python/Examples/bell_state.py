"""
[Alpha Quantum SDK]
Topic: Bell State Generation using QuantumCircuit
State: (|00> + |11>) / sqrt(2)
"""

import numpy as np
from QUANTUM_SDK.Python.gemini_circuit import QuantumCircuit

def generate_bell_phi_plus():
    # 1. Initialize a 2-qubit circuit
    qc = QuantumCircuit(2)
    
    # 2. Add H to q0
    qc.h(0)
    
    # 3. Add CX from q0 to q1
    qc.cx(0, 1)
    
    # 4. Simulate the state
    psi = qc.simulate()
    probs = qc.get_probabilities()
    
    return psi, probs

if __name__ == "__main__":
    state, probabilities = generate_bell_phi_plus()
    print("Generated Bell State |Phi+> using SDK:")
    print(f"Statevector: {state}")
    print(f"Probabilities: {probabilities}")

