"""
[Alpha Quantum SDK]
Topic: 10-Qubit Quantum Phase Estimation (QPE)
Purpose: High-precision eigenvalue estimation using a large counting register.
Target: Estimate theta = 0.3456...
"""

import numpy as np
from QUANTUM_SDK.Python.gemini_circuit import QuantumCircuit
from QUANTUM_SDK.Python.Physics.qft_logic import apply_qft

def run_qpe_10qubit(target_theta):
    n_count = 10 # 10 counting qubits
    total_qubits = n_count + 1
    qc = QuantumCircuit(total_qubits)
    
    # 1. Initialize counting register to superposition
    for i in range(n_count):
        qc.h(i)
        
    # 2. Prepare eigenstate |1> on target qubit
    qc.x(n_count)
    
    # 3. Apply controlled-U^(2^j) operations
    # U = PhaseGate(2*pi*theta)
    print(f"Applying {2**n_count - 1} controlled rotations...")
    for i in range(n_count):
        # Angle for U^(2^i) is theta * 2^pi * 2^i
        angle = 2 * np.pi * target_theta * (2**i)
        qc.cp(i, n_count, angle)
        
    # 4. Inverse QFT on counting register
    # We need an Inverse QFT function. For now, let's use the manual loop
    # or implement a helper in qft_logic.
    for i in range(n_count // 2):
        # Swaps are often needed before IQFT if using standard textbook QFT
        pass 

    for i in range(n_count - 1, -1, -1):
        for j in range(n_count - 1, i, -1):
            phi = -np.pi / (2**(j - i))
            qc.cp(j, i, phi)
        qc.h(i)
        
    # 5. Simulate
    state = qc.simulate()
    probs = qc.get_probabilities()
    
    # Marginalize over target bit
    count_probs = np.zeros(2**n_count)
    for i in range(2**total_qubits):
        count_probs[i & (2**n_count - 1)] += probs[i]
        
    best_idx = np.argmax(count_probs)
    estimated_theta = best_idx / (2**n_count)
    
    return estimated_theta, count_probs[best_idx]

if __name__ == "__main__":
    target = 0.345678
    print(f"--- 10-Qubit QPE Benchmark ---")
    print(f"Target Theta: {target}")
    
    est, prob = run_qpe_10qubit(target)
    
    print(f"
Estimated Theta: {est:.6f}")
    print(f"Confidence:      {prob:.4f}")
    print(f"Precision:       {1 / (2**10):.6f} (1/1024)")
    print(f"Error:           {abs(target - est):.6e}")
