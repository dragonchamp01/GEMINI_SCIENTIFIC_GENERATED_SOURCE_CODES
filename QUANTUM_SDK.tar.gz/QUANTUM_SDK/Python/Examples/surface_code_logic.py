"""
[Alpha Quantum SDK - Error Correction]
Topic: Surface Code (Distance-3 Rotated Surface Code)
Purpose: Implementation of a syndrome measurement cycle for 17 qubits.
"""

import numpy as np
from ..gemini_circuit import QuantumCircuit

class SurfaceCode:
    def __init__(self, d=3):
        self.d = d
        self.n_data = d * d
        self.n_ancilla = d * d - 1
        self.total_qubits = self.n_data + self.n_ancilla
        print(f"Rotated Surface Code (d={d}) initialized. Total Qubits: {self.total_qubits}")

    def run_syndrome_cycle(self, error_indices=None):
        """
        Executes one cycle of syndrome extraction for 9 data + 8 ancilla qubits.
        Data: 0-8, Ancilla: 9-16.
        """
        qc = QuantumCircuit(self.total_qubits)
        
        # 1. Inject errors on data qubits if specified
        if error_indices:
            for idx in error_indices:
                qc.x(idx)
        
        # 2. X-Stabilizer Measurements (Ancilla 9-12)
        # Using H-CX-H pattern to measure X parity
        for anc in range(9, 13):
            qc.h(anc)
            
        # Mock connections for d=3 rotated surface code (simplified)
        # X0 measures D0, D1, D3, D4
        qc.cx(9, 0); qc.cx(9, 1); qc.cx(9, 3); qc.cx(9, 4)
        # X1 measures D1, D2, D4, D5
        qc.cx(10, 1); qc.cx(10, 2); qc.cx(10, 4); qc.cx(10, 5)
        # X2 measures D3, D4, D6, D7
        qc.cx(11, 3); qc.cx(11, 4); qc.cx(11, 6); qc.cx(11, 7)
        # X3 measures D4, D5, D7, D8
        qc.cx(12, 4); qc.cx(12, 5); qc.cx(12, 7); qc.cx(12, 8)
        
        for anc in range(9, 13):
            qc.h(anc)
            
        # 3. Z-Stabilizer Measurements (Ancilla 13-16)
        # Measures parity in Z basis
        # Z0 measures D0, D1, D3, D4
        qc.cx(0, 13); qc.cx(1, 13); qc.cx(3, 13); qc.cx(4, 13)
        # Z1 measures D1, D2, D4, D5
        qc.cx(1, 14); qc.cx(2, 14); qc.cx(4, 14); qc.cx(5, 14)
        # Z2 measures D3, D4, D6, D7
        qc.cx(3, 15); qc.cx(4, 15); qc.cx(6, 15); qc.cx(7, 15)
        # Z3 measures D4, D5, D7, D8
        qc.cx(4, 16); qc.cx(5, 16); qc.cx(7, 16); qc.cx(8, 16)
        
        # 4. Simulate
        qc.simulate()
        
        # 5. Measure Ancillas
        # Note: In a real simulation, we'd sample only ancilla results.
        probs = qc.get_probabilities()
        return probs

if __name__ == "__main__":
    code = SurfaceCode(d=3)
    
    # Inject bit-flip (X) on Data Qubit 4 (The center qubit)
    print("\nInjecting X-error on Data Qubit 4...")
    results = code.run_syndrome_cycle(error_indices=[4])
    
    # Find most probable measurement outcomes (simplified)
    max_idx = np.argmax(results)
    binary = format(max_idx, f'0{code.total_qubits}b')
    
    # Ancilla bits are the higher indices
    syndrome = binary[:8] # Indices 16 down to 9
    print(f"Measured Syndrome (Ancilla 16..9): {syndrome}")
    print("If Data 4 is flipped, all 4 X-syndromes and 4 Z-syndromes might trigger depending on lattice mapping.")

