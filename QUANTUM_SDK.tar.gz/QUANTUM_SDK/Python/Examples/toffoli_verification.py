"""
[Alpha Quantum SDK]
Topic: Toffoli (CCX) Gate Verification
Purpose: Ensuring CCX logic is correct across all states.
"""

import numpy as np
from QUANTUM_SDK.Python.gemini_circuit import QuantumCircuit

def verify_toffoli():
    print("--- 3-Qubit Toffoli Gate Verification ---")
    
    # Test cases: (c1, c2, t) -> expected_target_flip
    test_cases = [
        (0, 0, 0), # No flip
        (1, 0, 0), # No flip
        (0, 1, 0), # No flip
        (1, 1, 1), # FLIP!
    ]
    
    for c1_val, c2_val, expected_t in test_cases:
        qc = QuantumCircuit(3)
        
        # Prepare controls
        if c1_val: qc.x(0)
        if c2_val: qc.x(1)
        
        # Apply CCX(0, 1, 2)
        qc.ccx(0, 1, 2)
        
        state = qc.simulate()
        probs = qc.get_probabilities()
        
        # Measure
        measured_idx = qc.measure()
        # Binary representation: (bit2, bit1, bit0)
        m2 = (measured_idx >> 2) & 1
        m1 = (measured_idx >> 1) & 1
        m0 = measured_idx & 1
        
        print(f"Input |{c2_val}{c1_val}0> -> Measured |{m2}{m1}{m0}> (Target Bit: {m2}, Expected: {expected_t})")
        assert m2 == expected_t, f"Toffoli failed for input {c1_val}{c2_val}"

if __name__ == "__main__":
    verify_toffoli()
    print("Verification Successful!")
