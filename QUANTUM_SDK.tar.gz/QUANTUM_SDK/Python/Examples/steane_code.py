"""
[Alpha Quantum SDK - Error Correction]
Topic: Steane 7-Qubit Code
Purpose: Implementation of the [[7, 1, 3]] CSS code encoding circuit.
"""

import numpy as np
from ..gemini_circuit import QuantumCircuit

class SteaneCode:
    def __init__(self):
        print("Steane 7-Qubit Code initialized.")

    def encode(self, initial_state_idx=0):
        """
        Encodes 1 logical qubit into 7 physical qubits.
        Resulting state is a superposition of Hamming codewords.
        """
        # 7 qubits total
        qc = QuantumCircuit(7)
        
        # 1. Prepare logical |1> if needed
        if initial_state_idx == 1:
            for i in range(7):
                qc.x(i)
        
        # 2. Encode into Steane |0>L superposition
        # H on bits 4, 5, 6
        qc.h(4)
        qc.h(5)
        qc.h(6)
        
        # Parity checks as CX gates
        # d3=d0+d1+d2 (Indices: 3=0+1+2)
        qc.cx(6, 1)
        qc.cx(6, 2)
        qc.cx(6, 3)
        
        qc.cx(5, 0)
        qc.cx(5, 2)
        qc.cx(5, 3)
        
        qc.cx(4, 0)
        qc.cx(4, 1)
        qc.cx(4, 3)
        
        # 3. Simulate the statevector
        state = qc.simulate()
        return state

if __name__ == "__main__":
    qec = SteaneCode()
    
    # Encode |0>L
    print("Encoding Logical |0> into 7-qubit Steane state...")
    state0 = qec.encode(0)
    
    # Check some state amplitudes
    # |0>L should have 8 non-zero components (codewords of Hamming [7,4])
    print("\nNon-zero amplitude indices for |0>L (expected Hamming codewords):")
    for i, amp in enumerate(state0):
        if np.abs(amp) > 1e-6:
            binary = format(i, '07b')
            print(f"| {binary} > : {np.round(amp, 3)}")
            
    # Check orthogonality
    state1 = qec.encode(1)
    overlap = np.vdot(state0, state1)
    print(f"\nLogical States Overlap (<0L|1L>): {np.abs(overlap):.3f}")

