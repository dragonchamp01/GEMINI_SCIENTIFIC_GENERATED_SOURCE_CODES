"""
[Alpha Quantum SDK - Tensor Algebra]
Topic: Einstein Notation (Einsum) Logic
Purpose: Generalized tensor contractions for physics.
"""

import numpy as np

def contract_metric(Ricci, g_inv):
    """
    Computes R = R_uv * g^uv (Ricci Scalar).
    """
    return np.einsum('uv,uv->', Ricci, g_inv)

def compute_gradient_tensor(T, grad):
    """
    Computes T_uv;a = d_a T_uv (Covariant derivative concept).
    """
    return np.einsum('uv,a->uva', T, grad)

if __name__ == "__main__":
    R_uv = np.array([[0.5, 0.1], [0.1, -0.2]])
    g_up = np.array([[1.0, 0], [0, -1.0]]) # Minkowski-like
    
    scalar = contract_metric(R_uv, g_up)
    print(f"Contracted Ricci Scalar: {scalar:.4f}")
    
    # Tensor rank check
    A = np.random.rand(3, 3, 3)
    B = np.random.rand(3, 3)
    C = np.einsum('ijk,kl->ijl', A, B)
    print(f"Contraction Shape (rank 3 * rank 2 -> rank 3): {C.shape}")
