"""
[Alpha Quantum SDK - Group Theory]
Topic: Group Homomorphism Verification
Purpose: Algorithmic check for structure-preserving mappings between groups.
"""

def check_homomorphism(G_elements, G_op, H_op, f_map):
    """
    Args:
        G_elements: All elements of group G.
        G_op: Multiplication function for G.
        H_op: Multiplication function for H.
        f_map: Mapping dictionary from G to H.
    """
    for a in G_elements:
        for b in G_elements:
            # f(a * b)
            lhs = f_map[G_op(a, b)]
            # f(a) * f(b)
            rhs = H_op(f_map[a], f_map[b])
            
            if lhs != rhs:
                return False, (a, b)
    return True, None

if __name__ == "__main__":
    # Group G: Z4 under addition (+ mod 4)
    # Group H: {1, -1, i, -i} under multiplication (* )
    G_elems = [0, 1, 2, 3]
    def G_op(a, b): return (a + b) % 4
    def H_op(a, b): return a * b
    
    # Map f(n) = i^n
    f_map = {0: 1+0j, 1: 1j, 2: -1+0j, 3: -1j}
    
    is_homo, fail_pair = check_homomorphism(G_elems, G_op, H_op, f_map)
    print(f"Is Z4 -> C4 a Homomorphism? {is_homo}")
