"""
[Alpha Quantum SDK - Statistics]
Topic: Kolmogorov-Smirnov (KS) Test
Purpose: Non-parametric test for distribution comparison.
Formula: D = max | F_empirical(x) - F_theoretical(x) |
"""

import numpy as np

def ks_test_normal(data, mu=0, sigma=1):
    """
    Checks if data follows a Normal distribution N(mu, sigma).
    """
    data = np.sort(data)
    n = len(data)
    
    # 1. Empirical CDF
    F_emp = np.arange(1, n + 1) / n
    
    # 2. Theoretical CDF (Standard Normal approx)
    from scipy.stats import norm
    F_theory = norm.cdf(data, loc=mu, scale=sigma)
    
    # 3. KS Statistic D
    D = np.max(np.abs(F_emp - F_theory))
    return D

if __name__ == "__main__":
    # Case 1: Data from Normal(0, 1)
    samples_normal = np.random.normal(0, 1, 100)
    # Case 2: Data from Uniform(0, 1)
    samples_uniform = np.random.uniform(0, 1, 100)
    
    print("Kolmogorov-Smirnov Test Analysis")
    print("--------------------------------")
    
    d_norm = ks_test_normal(samples_normal)
    d_unif = ks_test_normal(samples_uniform)
    
    print(f"KS Statistic (Normal samples vs Normal):  {d_norm:.4f} (Lower is better)")
    print(f"KS Statistic (Uniform samples vs Normal): {d_unif:.4f} (Higher indicates mismatch)")
