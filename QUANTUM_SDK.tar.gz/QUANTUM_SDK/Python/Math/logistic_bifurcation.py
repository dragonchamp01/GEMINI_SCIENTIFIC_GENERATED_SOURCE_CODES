"""
[Alpha Quantum SDK - Non-linear Dynamics]
Topic: Logistic Map Bifurcation Analysis
Purpose: Visualizing the transition to chaos as parameter r increases.
"""

import numpy as np

def get_bifurcation_data(r_range, iterations=1000, last=100):
    """
    Computes steady-state values for each r.
    """
    x = 0.5 * np.ones_like(r_range)
    results = []
    
    # 1. Reach attractor
    for _ in range(iterations - last):
        x = r_range * x * (1 - x)
        
    # 2. Collect points on attractor
    for _ in range(last):
        x = r_range * x * (1 - x)
        results.append((r_range, x))
        
    return results

if __name__ == "__main__":
    r_pts = np.linspace(2.5, 4.0, 1000)
    print("Generating Bifurcation Data for r in [2.5, 4.0]...")
    data = get_bifurcation_data(r_pts)
    
    # Summary of a specific r
    r_test = 3.5
    x_test = 0.5
    for _ in range(100): x_test = r_test * x_test * (1 - x_test)
    print(f"Steady state at r=3.5: x_final approx {x_test:.4f}")
