"""
[Alpha Quantum SDK - Advanced Statistics]
Topic: HMM Forward Algorithm
Purpose: Calculating the likelihood of an observation sequence.
"""

import numpy as np

def hmm_forward(obs, A, B, pi):
    """
    Args:
        obs: observation sequence (indices)
        A: transition matrix
        B: emission matrix
        pi: initial state distribution
    """
    N = A.shape[0]
    T = len(obs)
    alpha = np.zeros((T, N))

    # Initialization
    alpha[0, :] = pi * B[:, obs[0]]

    # Recursion
    for t in range(1, T):
        for j in range(N):
            alpha[t, j] = np.dot(alpha[t-1, :], A[:, j]) * B[j, obs[t]]

    return alpha, np.sum(alpha[T-1, :])

if __name__ == "__main__":
    # 2 States (e.g. Fair/Biased coin), 2 Observations (H/T)
    A = np.array([[0.7, 0.3], [0.4, 0.6]])
    B = np.array([[0.5, 0.5], [0.8, 0.2]])
    pi = np.array([0.5, 0.5])
    
    observations = [0, 1, 0] # H, T, H
    
    _, total_prob = hmm_forward(observations, A, B, pi)
    print(f"Observation Likelihood: {total_prob:.6f}")
