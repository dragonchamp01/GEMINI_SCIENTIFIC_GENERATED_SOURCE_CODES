"""
[Alpha Quantum SDK - Representation Theory]
Topic: Group Characters and Representation Reduction
Purpose: Decomposing a reducible representation into irreducible ones.
"""

import numpy as np

def is_irreducible(char_vector, group_order, class_sizes):
    """
    Verifies the irreducibility using the inner product rule: (chi, chi) = 1.
    """
    inner_product = np.sum(class_sizes * np.abs(char_vector)**2) / group_order
    return np.isclose(inner_product, 1.0)

if __name__ == "__main__":
    # Example: C2v Group (Order 4)
    # Symmetry Classes: E, C2, sigma_v, sigma_v' (Sizes are all 1)
    class_sizes = np.array([1, 1, 1, 1])
    h = 4
    
    # Irreducible Representation A1: [1, 1, 1, 1]
    chi_A1 = np.array([1, 1, 1, 1])
    
    # A Reducible Representation: [3, 1, 1, 1]
    chi_red = np.array([3, 1, 1, 1])
    
    print("Group Theory Analysis (C2v Group)")
    print(f"Is A1 Irreducible? {is_irreducible(chi_A1, h, class_sizes)}")
    print(f"Is Reducible [3,1,1,1] Irreducible? {is_irreducible(chi_red, h, class_sizes)}")
    
    # Decomposition: count = (1/h) * sum( chi_red * chi_irrep * sizes )
    n_A1 = np.sum(chi_red * chi_A1 * class_sizes) / h
    print(f"Number of times A1 irrep appears in reducible representation: {n_A1}")
