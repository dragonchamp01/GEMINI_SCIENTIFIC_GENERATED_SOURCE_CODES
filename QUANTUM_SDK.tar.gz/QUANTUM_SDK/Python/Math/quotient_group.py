"""
[Alpha Quantum SDK - Group Theory]
Topic: Quotient Group G/H
Purpose: Computing the structure of G/H given G and normal subgroup H.
"""

def get_quotient_group(G_elements, G_op, H_subgroup):
    """
    Computes cosets of H in G.
    """
    cosets = []
    seen = set()
    
    for g in G_elements:
        if g in seen: continue
        
        # Create coset gH
        coset = sorted([(G_op(g, h)) for h in H_subgroup])
        cosets.append(tuple(coset))
        for item in coset: seen.add(item)
        
    return cosets

if __name__ == "__main__":
    # G: Z6 under addition mod 6
    G = list(range(6))
    def op(a, b): return (a + b) % 6
    # H: {0, 3} (Normal subgroup)
    H = [0, 3]
    
    print(f"Group G: {G}")
    print(f"Normal Subgroup H: {H}")
    
    q_group = get_quotient_group(G, op, H)
    
    print("
Quotient Group G/H Cosets:")
    for i, coset in enumerate(q_group):
        print(f" Coset {i}: {coset}")
        
    print(f"
Order of G/H: {len(q_group)} (Expected: 6/2 = 3)")
