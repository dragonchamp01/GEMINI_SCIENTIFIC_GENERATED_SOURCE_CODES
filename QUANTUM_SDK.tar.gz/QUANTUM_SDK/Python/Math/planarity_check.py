"""
[Alpha Quantum SDK - Graph Theory]
Topic: Planarity Check (Kuratowski's Theorem Basis)
Purpose: Checking if a graph can be embedded in a 2D plane.
"""

def simple_planarity_test(V, E):
    """
    Necessary condition for planar graphs: E <= 3V - 6
    """
    if V < 3: return True
    return E <= (3 * V - 6)

if __name__ == "__main__":
    # Case 1: Complete Graph K5 (Not planar)
    v_k5, e_k5 = 5, 10
    # 10 <= 3*5 - 6 = 9 -> False
    
    print("Graph Planarity Basic Test")
    print(f"K5 (V=5, E=10) Planar? {simple_planarity_test(v_k5, e_k5)}")
    
    # Case 2: Square graph
    v_sq, e_sq = 4, 4
    print(f"Square (V=4, E=4) Planar? {simple_planarity_test(v_sq, e_sq)}")
