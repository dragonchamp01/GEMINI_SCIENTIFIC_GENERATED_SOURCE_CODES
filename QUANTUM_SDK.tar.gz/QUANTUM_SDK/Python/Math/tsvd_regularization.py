"""
[Alpha Quantum SDK - Linear Algebra]
Topic: Truncated SVD (TSVD) Regularization
Purpose: Solving ill-conditioned linear systems by filtering small singular values.
"""

import numpy as np

def tsvd_solve(A, b, k):
    """
    Solves Ax = b using only the first k singular values.
    """
    U, s, Vt = np.linalg.svd(A, full_matrices=False)
    
    # 1. Invert singular values (only up to k)
    s_inv = np.zeros_like(s)
    s_inv[:k] = 1.0 / s[:k]
    
    # 2. Reconstruct solution: x = V * s_inv * U^T * b
    x = Vt.T @ (np.diag(s_inv) @ (U.T @ b))
    return x

if __name__ == "__main__":
    # Create an ill-conditioned matrix
    A = np.array([[1, 1], [1, 1.0001]])
    b = np.array([2, 2.0001])
    
    print("Solving ill-conditioned system PA=b...")
    x_exact = np.linalg.solve(A, b)
    x_tsvd = tsvd_solve(A, b, k=1) # Regularize by taking only the dominant component
    
    print(f"Exact Solution: {x_exact}")
    print(f"TSVD Solution (k=1): {x_tsvd}")
    print("TSVD reduces sensitivity to noise in the data.")
