"""
[Alpha Quantum SDK - Complex Analysis]
Topic: Cauchy Integral Formula Verification
Purpose: Numerically calculating f(z0) via contour integration.
Formula: f(z0) = (1 / 2pi*i) * Integral( f(z) / (z - z0) dz )
"""

import numpy as np

def cauchy_integral_formula(f, z0, R, n_points=1000):
    """
    Args:
        f: The analytic function f(z).
        z0: The point inside the contour.
        R: Radius of the circular contour.
    """
    theta = np.linspace(0, 2 * np.pi, n_points)
    # Parametrized circle: z(theta) = z0 + R * exp(i*theta)
    z = z0 + R * np.exp(1j * theta)
    # dz = i * R * exp(i*theta) d_theta
    dz = 1j * R * np.exp(1j * theta) * (theta[1] - theta[0])
    
    # Integrand: f(z) / (z - z0)
    integrand = f(z) / (z - z0)
    
    integral = np.sum(integrand * dz)
    return integral / (2j * np.pi)

if __name__ == "__main__":
    # Test with f(z) = z^2
    # At z0 = 1+1j, f(z0) = (1+1j)^2 = 1 - 1 + 2j = 2j
    def f_test(z): return z**2
    z0 = 1.0 + 1.0j
    
    print(f"Verifying Cauchy Integral Formula for f(z) = z^2 at z0 = {z0}")
    calc_f_z0 = cauchy_integral_formula(f_test, z0, R=0.5)
    
    print(f"Direct Calculation f(z0): {f_test(z0)}")
    print(f"Integral Result f(z0):    {calc_f_z0}")
    print(f"Error Magnitude:          {abs(calc_f_z0 - f_test(z0)):.2e}")
