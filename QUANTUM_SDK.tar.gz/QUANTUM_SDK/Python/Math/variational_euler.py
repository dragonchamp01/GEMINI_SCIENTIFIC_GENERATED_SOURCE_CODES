"""
[Alpha Quantum SDK - Calculus]
Topic: Euler-Lagrange Solver (Variational Principle)
Purpose: Finding the path of least action for a given Lagrangian.
"""

import numpy as np

def euler_lagrange_residual(q, q_dot, q_ddot, L_func, t, h=1e-5):
    """
    Checks the EL equation: d/dt (dL/dq_dot) - dL/dq = 0
    """
    # 1. dL/dq
    dL_dq = (L_func(q + h, q_dot, t) - L_func(q - h, q_dot, t)) / (2 * h)
    
    # 2. dL/dq_dot (momentum p)
    def momentum(curr_q, curr_q_dot, curr_t):
        return (L_func(curr_q, curr_q_dot + h, curr_t) - L_func(curr_q, curr_q_dot - h, curr_t)) / (2 * h)
    
    # 3. Total time derivative d/dt (p)
    # Uses chain rule: dp/dt = dp/dq * q_dot + dp/dq_dot * q_ddot + dp/dt
    p_t_plus = momentum(q, q_dot, t + h)
    p_t_minus = momentum(q, q_dot, t - h)
    dp_dt = (p_t_plus - p_t_minus) / (2 * h)
    
    return dp_dt - dL_dq

if __name__ == "__main__":
    # Example: Harmonic Oscillator L = 0.5*m*v^2 - 0.5*k*x^2
    def L_harmonic(x, v, t):
        m, k = 1.0, 1.0
        return 0.5 * m * v**2 - 0.5 * k * x**2
        
    # Test a known solution: x(t) = cos(t), v(t) = -sin(t), a(t) = -cos(t)
    t_test = 1.0
    x = np.cos(t_test)
    v = -np.sin(t_test)
    a = -np.cos(t_test)
    
    residual = euler_lagrange_residual(x, v, a, L_harmonic, t_test)
    print(f"Euler-Lagrange Residual for Harmonic Oscillator: {residual:.2e}")
    print("If residual is near zero, the path satisfies the principle of least action.")
