"""
[Alpha Quantum SDK - Group Theory]
Topic: Representation Reduction Formula
Purpose: Decomposing a reducible representation into Irreducible Representations (Irreps).
Formula: a_i = (1/h) * sum( g_j * chi_red(g_j) * chi_irrep_i(g_j) )
"""

import numpy as np

def reduce_representation(chi_red, irreps_dict, class_sizes, group_order):
    """
    Args:
        chi_red: Character vector of the reducible representation.
        irreps_dict: Map of Irrep Name -> Character Vector.
        class_sizes: Number of elements in each symmetry class.
        group_order: Total elements in group (h).
    """
    decomposition = {}
    
    for name, chi_irrep in irreps_dict.items():
        # Standard inner product of characters
        count = np.sum(class_sizes * chi_red * np.conj(chi_irrep)) / group_order
        count = int(np.round(count.real))
        if count > 0:
            decomposition[name] = count
            
    return decomposition

if __name__ == "__main__":
    # Example: C2v Point Group
    h = 4
    sizes = np.array([1, 1, 1, 1]) # Classes: E, C2, sigma_v, sigma_v'
    
    # Irreps table
    irreps = {
        "A1": [1, 1, 1, 1],
        "A2": [1, 1, -1, -1],
        "B1": [1, -1, 1, -1],
        "B2": [1, -1, -1, 1]
    }
    
    # A specific reducible representation (e.g. displacement of 3 atoms)
    chi_total = np.array([9, -1, 3, 1]) 
    
    result = reduce_representation(chi_total, irreps, sizes, h)
    
    print("Group Representation Decomposition:")
    for irrep, count in result.items():
        print(f" -> {count} x {irrep}")
