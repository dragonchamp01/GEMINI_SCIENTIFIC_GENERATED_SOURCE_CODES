"""
[Alpha Quantum SDK - Machine Learning]
Topic: Support Vector Machine (SVM) Margin Logic
Purpose: Conceptualizing the decision boundary and margin calculation.
"""

import numpy as np

def calculate_margin(w, b, points, labels):
    """
    Args:
        w: Weight vector.
        b: Bias.
        points: Dataset.
        labels: True classes (+1 or -1).
    """
    # Decision function: f(x) = sign(w.x + b)
    # Distance to hyperplane: |w.x + b| / ||w||
    w_norm = np.linalg.norm(w)
    
    # Calculate functional margins for each point: label * (w.x + b)
    functional_margins = labels * (np.dot(points, w) + b)
    
    # Geometric margin: functional margin / ||w||
    geometric_margins = functional_margins / w_norm
    
    return np.min(geometric_margins)

if __name__ == "__main__":
    # 2D Data points
    X = np.array([[1, 2], [2, 3], [3, 1], [6, 7], [7, 8], [8, 6]])
    y = np.array([-1, -1, -1, 1, 1, 1])
    
    # Mock optimal hyperplane parameters
    w_opt = np.array([1.0, 1.0])
    b_opt = -9.0
    
    margin = calculate_margin(w_opt, b_opt, X, y)
    
    print(f"Hyperplane: {w_opt[0]}x + {w_opt[1]}y + {b_opt} = 0")
    print(f"Minimum Geometric Margin: {margin:.4f}")
    print("Optimization Goal: Maximize this margin by adjusting w and b.")
