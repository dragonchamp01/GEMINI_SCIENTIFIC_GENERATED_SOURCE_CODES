"""
[Alpha Quantum SDK - Statistical Mechanics]
Topic: Quantum Partition Function (Z)
Purpose: Connecting quantum energy levels to thermodynamic observables.
Formula: Z = sum( exp(-beta * En) )
"""

import numpy as np

def calculate_partition_function(energies, temperature):
    """
    Args:
        energies (array): Eigenvalues of the Hamiltonian.
        temperature: Temperature in Kelvin.
    """
    kb = 1.380649e-23 # Boltzmann constant (J/K)
    # Using atomic units for simplicity if needed, otherwise SI
    # beta = 1 / (kb * T)
    beta = 1.0 / (temperature + 1e-15) # Simplified beta
    
    # Z = sum( exp(-beta * E_i) )
    exp_terms = np.exp(-beta * (energies - np.min(energies))) # Shift for stability
    Z = np.sum(exp_terms)
    
    # Internal Energy <E> = -d(ln Z)/d(beta)
    avg_energy = np.sum(energies * exp_terms) / Z
    
    return Z, avg_energy

if __name__ == "__main__":
    # Example: 1D Harmonic Oscillator levels E_n = (n + 0.5)
    levels = np.arange(0, 100) + 0.5
    temp = 1.0
    
    print(f"Analyzing Quantum Statistics at T={temp}")
    Z, E_avg = calculate_partition_function(levels, temp)
    print(f"Partition Function Z: {Z:.4f}")
    print(f"Average Energy <E>:   {E_avg:.4f}")
