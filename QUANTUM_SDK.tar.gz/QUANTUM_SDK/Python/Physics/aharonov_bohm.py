"""
[Alpha Quantum SDK - Quantum Topology]
Topic: Aharonov-Bohm Effect
Purpose: Simulating the phase shift Delta_phi = (q/hbar) * Integral(A . dl)
"""

import numpy as np

def calculate_ab_phase(magnetic_flux, charge=1.0):
    """
    Calculates the phase shift due to an enclosed magnetic flux.
    Args:
        magnetic_flux: Enclosed Phi_B.
        charge: Particle charge.
    """
    hbar = 1.0 # Atomic units
    # Phase shift phi = q * Phi_B / hbar
    delta_phi = (charge * magnetic_flux) / hbar
    return delta_phi % (2 * np.pi)

if __name__ == "__main__":
    phi_b = 3.14159265
    print(f"Aharonov-Bohm Effect Analysis (Flux={phi_b})")
    shift = calculate_ab_phase(phi_b)
    print(f"Phase Shift: {shift:.4f} rad")
    print(f"Interference Pattern Offset: {np.cos(shift):.4f}")
