"""
[Alpha Quantum SDK - QFT]
Topic: Feynman Parameterization logic.
Purpose: Combining denominators 1/(A*B) = integral_0^1 dx / [x*A + (1-x)*B]^2.
"""

import numpy as np

def combine_denominators(A, B):
    """
    Returns the integrand function for combining two denominators.
    """
    def integrand(x):
        # Resulting combined denominator: [x*A + (1-x)*B]^-2
        return 1.0 / (x * A + (1 - x) * B)**2
    return integrand

if __name__ == "__main__":
    # Example: A = p^2, B = (p-k)^2
    p_sq = 10.0
    pk_sq = 12.0
    
    integrand = combine_denominators(p_sq, pk_sq)
    
    print(f"Feynman Parameter Integrand at x=0.5 for A={p_sq}, B={pk_sq}:")
    print(f"Value: {integrand(0.5):.6f}")
    
    # Simple midpoint integral
    x_pts = np.linspace(0, 1, 100)
    integral_val = np.mean([integrand(x) for x in x_pts])
    
    print(f"Integrated Result (approx): {integral_val:.6f}")
    print(f"Analytical Result (1/(A*B)): {1.0 / (p_sq * pk_sq):.6f}")
