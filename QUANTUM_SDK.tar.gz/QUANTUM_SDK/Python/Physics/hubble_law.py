"""
[Alpha Quantum SDK - Cosmology]
Topic: Hubble's Law and Redshift
Purpose: Simulating velocity-distance relationship in FLRW Spacetime.
Formula: v = H0 * d
"""

import numpy as np

def compute_redshift(distance_mpc, H0=70.0):
    """
    Args:
        distance_mpc: Distance in Megaparsecs.
        H0: Hubble constant (km/s/Mpc).
    """
    c = 299792.0 # km/s
    v_recession = H0 * distance_mpc
    z = v_recession / c
    return v_recession, z

if __name__ == "__main__":
    # Nearby to distant galaxies
    distances = np.array([10, 50, 100, 500, 1000]) # Mpc
    
    print("Hubble Law and Cosmological Redshift")
    print("------------------------------------")
    print(" Distance (Mpc) | Recessions (km/s) | Redshift (z)")
    print("----------------|-------------------|------------")
    
    for d in distances:
        v, z = compute_redshift(d)
        print(f" {d:14.1f} | {v:17.1f} | {z:10.4f}")
        
    print("
Note: At very high z, relativistic redshift formulas are required.")
