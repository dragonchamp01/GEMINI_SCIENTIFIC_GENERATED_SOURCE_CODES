"""
[Alpha Quantum SDK - Atomic Physics]
Topic: Clebsch-Gordan Coefficients
Purpose: Calculating the coupling of two angular momenta j1 and j2.
Formula: Using the Racah formula or Wigner 3j-symbol relation.
"""

import numpy as np
from math import factorial, sqrt

def get_cg_coefficient(j1, m1, j2, m2, J, M):
    """
    Calculates the Clebsch-Gordan coefficient <j1 m1 j2 m2 | J M>.
    Simple implementation for small j values.
    """
    if m1 + m2 != M: return 0.0
    if not (abs(j1 - j2) <= J <= j1 + j2): return 0.0
    
    # Selection rules for m
    if abs(m1) > j1 or abs(m2) > j2 or abs(M) > J: return 0.0

    # Simplified lookup/calculation placeholder for Racine algorithm
    # In a full SDK, this would use the explicit summation formula.
    if j1 == 0.5 and j2 == 0.5:
        if J == 1: # Triplet state
            if M == 1: return 1.0 if (m1==0.5 and m2==0.5) else 0.0
            if M == 0: return 1.0/sqrt(2.0)
        if J == 0: # Singlet state
            if M == 0: return 1.0/sqrt(2.0) if m1 > m2 else -1.0/sqrt(2.0)
            
    return 0.0 # Placeholder for higher j

if __name__ == "__main__":
    print("Clebsch-Gordan Coefficient Simulation (Spin 1/2 coupling)")
    print("-------------------------------------------------------")
    # Coupling two spin-1/2 particles to form a Singlet (J=0, M=0)
    cg = get_cg_coefficient(0.5, 0.5, 0.5, -0.5, 0, 0)
    print(f"<1/2, 1/2, 1/2, -1/2 | 0, 0> = {cg:.4f} (Expected: 0.7071)")
