"""
[Alpha Quantum SDK - Astro-Physics]
Topic: Hawking Temperature Calculation
Formula: T = (hbar * c^3) / (8 * pi * G * M * kB)
"""

import numpy as np

def calculate_hawking_temp(mass_solar):
    """
    Args:
        mass_solar: Mass of the black hole in Solar Masses.
    """
    # Constants (SI Units)
    G = 6.67430e-11
    hbar = 1.05457e-34
    c = 299792458.0
    kB = 1.38065e-23
    M_sun = 1.989e30
    
    M = mass_solar * M_sun
    
    # Hawking Temperature
    T = (hbar * c**3) / (8 * np.pi * G * M * kB)
    return T

if __name__ == "__main__":
    masses = [1.0, 5.0, 1e6] # 1 Sun, 5 Suns, Supermassive BH
    
    print("Black Hole Hawking Temperature Analysis")
    print("---------------------------------------")
    print(" Mass (Solar) | Temperature (Kelvin)")
    print("--------------|---------------------")
    
    for m in masses:
        temp = calculate_hawking_temp(m)
        print(f" {m:12.1e} | {temp:16.4e}")
        
    print("
Note: Smaller black holes are much hotter.")
