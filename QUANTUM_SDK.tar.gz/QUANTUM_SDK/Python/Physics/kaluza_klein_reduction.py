"""
[Alpha Quantum SDK - Unified Theory]
Topic: Kaluza-Klein Dimensional Reduction
Purpose: Extracting 4D fields (Gravity + EM) from a 5D metric.
"""

import numpy as np

def reduce_5d_metric(g5):
    """
    Args:
        g5 (5x5 array): 5D spacetime metric.
    Returns:
        g4: 4D spacetime metric.
        A: 4D Vector potential.
        phi: Scalar dilaton field.
    """
    # 5th dimension is at index 4
    phi_sq = g5[4, 4]
    phi = np.sqrt(phi_sq)
    
    # Vector potential A_mu = g_5mu / g_55
    A = g5[:4, 4] / phi_sq
    
    # 4D Metric g_uv = g5_uv - phi^2 * A_u * A_v
    g4 = g5[:4, :4] - phi_sq * np.outer(A, A)
    
    return g4, A, phi

if __name__ == "__main__":
    # Define a mock 5D metric with non-zero 5th components
    g5_mock = np.eye(5)
    g5_mock[0, 4] = g5_mock[4, 0] = 0.1 # Coupling between time and 5th dim
    g5_mock[4, 4] = 1.2 # Scale of 5th dim
    
    print("Performing Kaluza-Klein Reduction (5D -> 4D)...")
    g4, A, phi = reduce_5d_metric(g5_mock)
    
    print(f"Dilaton Field phi: {phi:.4f}")
    print(f"Effective 4D Vector Potential A: {A}")
    print("This shows how EM emerges from extra-dimensional geometry.")
