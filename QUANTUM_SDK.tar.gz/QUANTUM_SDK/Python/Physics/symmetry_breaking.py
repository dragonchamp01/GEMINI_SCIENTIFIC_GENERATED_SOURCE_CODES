"""
[Alpha Quantum SDK - QFT]
Topic: Spontaneous Symmetry Breaking (Mexican Hat Potential)
Purpose: Modeling the Higgs mechanism ground state selection.
Potential: V(phi) = -mu^2 |phi|^2 + lambda |phi|^4
"""

import numpy as np

def mexican_hat_potential(phi_real, phi_imag, mu_sq, lam):
    """
    Computes the potential energy surface for a complex scalar field.
    """
    phi_abs_sq = phi_real**2 + phi_imag**2
    return -mu_sq * phi_abs_sq + lam * phi_abs_sq**2

def find_vacuum_expectation_value(mu_sq, lam):
    """
    The VEV (v) is the radius where the potential is minimized.
    v = sqrt(mu^2 / 2*lambda)
    """
    return np.sqrt(mu_sq / (2.0 * lam))

if __name__ == "__main__":
    mu2 = 2.0
    l = 0.5
    v = find_vacuum_expectation_value(mu2, l)
    
    print(f"Symmetry Breaking Parameters: mu^2={mu2}, lambda={l}")
    print(f"Vacuum Expectation Value (v): {v:.4f}")
    
    # Check potential at origin vs VEV
    v_origin = mexican_hat_potential(0, 0, mu2, l)
    v_min = mexican_hat_potential(v, 0, mu2, l)
    
    print(f"Potential at origin (unbroken): {v_origin:.4f}")
    print(f"Potential at VEV (broken):      {v_min:.4f}")
    print(f"Energy density gain:            {abs(v_min - v_origin):.4f}")
