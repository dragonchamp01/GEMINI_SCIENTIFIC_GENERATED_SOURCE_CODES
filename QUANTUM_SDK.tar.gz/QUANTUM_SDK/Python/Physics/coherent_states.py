"""
[Alpha Quantum SDK - Quantum Optics]
Topic: Coherent States (|alpha>)
Purpose: Representing states with minimum uncertainty, closest to classical behavior.
Formula: |alpha> = exp(-|alpha|^2 / 2) * sum( (alpha^n / sqrt(n!)) * |n> )
"""

import numpy as np
from math import factorial

def get_coherent_state(alpha, n_max=30):
    """
    Returns the Fock space expansion of a coherent state.
    """
    psi = np.zeros(n_max, dtype=complex)
    prefactor = np.exp(-np.abs(alpha)**2 / 2.0)
    
    for n in range(n_max):
        psi[n] = (alpha**n) / np.sqrt(factorial(n))
        
    return prefactor * psi

if __name__ == "__main__":
    alpha_val = 2.0 + 1j
    print(f"Generating Coherent State |alpha={alpha_val}>")
    
    state = get_coherent_state(alpha_val)
    # Average photon number <n> = |alpha|^2
    avg_n = np.sum(np.arange(len(state)) * np.abs(state)**2)
    
    print(f"Expected <n>: {np.abs(alpha_val)**2:.4f}")
    print(f"Calculated <n>: {avg_n:.4f}")
    print(f"State Norm: {np.linalg.norm(state):.4f}")
