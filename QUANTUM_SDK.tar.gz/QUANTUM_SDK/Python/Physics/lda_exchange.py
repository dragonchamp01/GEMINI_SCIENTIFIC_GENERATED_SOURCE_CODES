"""
[Alpha Quantum SDK - Material Science]
Topic: LDA Exchange Functional (Dirac Form)
Purpose: Computing the exchange energy density for a given electron density n(r).
"""

import numpy as np

def lda_exchange_energy(n):
    """
    Dirac exchange functional: E_x = - (3/4) * (3/pi)^(1/3) * n^(4/3)
    """
    # C_x approx 0.7386
    Cx = 0.7385587663820223
    return -Cx * np.power(n, 4/3)

def lda_exchange_potential(n):
    """
    V_x = d(E_x)/dn = - (3/pi)^(1/3) * n^(1/3)
    """
    # C_vx approx 0.9847
    Cvx = 0.9847450218426965
    return -Cvx * np.power(n, 1/3)

if __name__ == "__main__":
    # Density profile (e.g. for an atom)
    n_profile = np.linspace(0.01, 1.0, 5)
    
    print("LDA Exchange Potential Analysis")
    print("-------------------------------")
    print(" Density (n) | Potential (V_x)")
    print("-------------|----------------")
    for n in n_profile:
        print(f" {n:11.2f} | {lda_exchange_potential(n):14.6f}")
