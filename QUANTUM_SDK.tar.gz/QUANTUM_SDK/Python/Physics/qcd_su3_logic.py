"""
[Alpha Quantum SDK - QCD Module]
Topic: Gell-Mann Matrices (SU(3) Generators)
Purpose: Basis for the strong force interaction in the Standard Model.
"""

import numpy as np

class GellMann:
    # The 8 generators of SU(3)
    L1 = np.array([[0, 1, 0], [1, 0, 0], [0, 0, 0]], dtype=complex)
    L2 = np.array([[0, -1j, 0], [1j, 0, 0], [0, 0, 0]], dtype=complex)
    L3 = np.array([[1, 0, 0], [0, -1, 0], [0, 0, 0]], dtype=complex)
    L4 = np.array([[0, 0, 1], [0, 0, 0], [1, 0, 0]], dtype=complex)
    L5 = np.array([[0, 0, -1j], [0, 0, 0], [1j, 0, 0]], dtype=complex)
    L6 = np.array([[0, 0, 0], [0, 0, 1], [0, 1, 0]], dtype=complex)
    L7 = np.array([[0, 0, 0], [0, 0, -1j], [0, 1j, 0]], dtype=complex)
    L8 = (1/np.sqrt(3)) * np.array([[1, 0, 0], [0, 1, 0], [0, 0, -2]], dtype=complex)

    @classmethod
    def get_all(cls):
        return [cls.L1, cls.L2, cls.L3, cls.L4, cls.L5, cls.L6, cls.L7, cls.L8]

def verify_commutation(A, B):
    """Checks [A, B] commutator."""
    return np.dot(A, B) - np.dot(B, A)

if __name__ == "__main__":
    matrices = GellMann.get_all()
    print(f"Gell-Mann SU(3) Generators Loaded. Total: {len(matrices)}")
    
    # Verify [L1, L2] = 2i L3
    res = verify_commutation(GellMann.L1, GellMann.L2)
    expected = 2j * GellMann.L3
    print(f"Commutation [L1, L2] == 2iL3: {np.allclose(res, expected)}")
