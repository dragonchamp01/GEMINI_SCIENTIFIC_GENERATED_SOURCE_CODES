"""
[Alpha Quantum SDK - Quantum Dynamics]
Topic: Quantum Decoherence (T2 Relaxation)
Purpose: Modeling the decay of off-diagonal elements in the density matrix.
Equation: rho_01(t) = rho_01(0) * exp(-t / T2)
"""

import numpy as np

def simulate_decoherence(rho_initial, t, T2):
    """
    Args:
        rho_initial: Initial 2x2 density matrix.
        t: Time elapsed.
        T2: Dephasing time constant.
    """
    rho_t = np.copy(rho_initial)
    # Decay factor for off-diagonal terms
    decay = np.exp(-t / T2)
    
    rho_t[0, 1] *= decay
    rho_t[1, 0] *= decay
    
    return rho_t

if __name__ == "__main__":
    # Initial state: |+> = 1/sqrt(2) (|0> + |1>)
    # rho = [[0.5, 0.5], [0.5, 0.5]]
    rho_0 = np.array([[0.5, 0.5], [0.5, 0.5]], dtype=complex)
    T2_time = 100.0 # microseconds
    
    print(f"Quantum Decoherence Analysis (T2 = {T2_time} us)")
    print("Time (us) | Coherence (rho_01)")
    print("----------|------------------")
    
    for time in [0, 50, 100, 200, 500]:
        rho_now = simulate_decoherence(rho_0, time, T2_time)
        print(f" {time:8.1f} | {rho_now[0,1].real:16.4f}")
        
    print("
Note: As time >> T2, the state becomes a classical statistical mixture.")
