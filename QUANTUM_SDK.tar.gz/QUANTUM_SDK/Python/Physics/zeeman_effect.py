"""
[Alpha Quantum SDK - Atomic Physics]
Topic: Zeeman Effect (Energy Splitting)
Formula: Delta_E = mu_B * B * (ml + 2*ms)
"""
import numpy as np

def zeeman_split(l, B_field):
    """Calculates splitting for orbital angular momentum l."""
    mu_B = 5.788e-5 # eV/T
    m_l = np.arange(-l, l + 1)
    return mu_B * B_field * m_l

if __name__ == "__main__":
    l = 2 # d-orbital
    B = 1.5 # Tesla
    shifts = zeeman_split(l, B)
    print(f"Zeeman Splitting for l={l} in B={B}T: {shifts} eV")
