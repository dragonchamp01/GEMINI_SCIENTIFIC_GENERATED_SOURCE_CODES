"""
[Alpha Quantum SDK - Quantum Algorithms]
Topic: Quantum Fourier Transform (QFT)
Purpose: Gate-based implementation of the QFT circuit.
"""

import numpy as np
from ..gemini_circuit import QuantumCircuit

def apply_qft(qc, n):
    """
    Applies the QFT circuit to the first n qubits of qc.
    """
    if n == 0:
        return
    
    # 1. Apply H to current qubit
    n -= 1
    qc.h(n)
    
    # 2. Apply controlled rotations from other qubits
    for i in range(n):
        # Rotation angle: 2*pi / 2^(n-i+1)
        phi = np.pi / (2**(n - i))
        qc.cp(i, n, phi)
    
    # 3. Recurse for remaining qubits
    apply_qft(qc, n)

def simulate_qft(n_qubits, input_state_idx=0):
    qc = QuantumCircuit(n_qubits)
    
    # Prepare input state if needed (e.g., |input_state_idx>)
    # For index 0, it's already |000...>
    
    # Apply QFT
    apply_qft(qc, n_qubits)
    
    # Swaps are usually required at the end for standard QFT order
    # for i in range(n_qubits // 2):
    #    qc.swap(i, n_qubits - i - 1)
    
    state = qc.simulate()
    return state

if __name__ == "__main__":
    n = 2
    print(f"Simulating {n}-qubit QFT Circuit...")
    qft_state = simulate_qft(n)
    
    print(f"Resulting Statevector: {np.round(qft_state, 3)}")
    
    # For |00>, QFT results in equal superposition [0.5, 0.5, 0.5, 0.5]
    expected = np.ones(2**n) / np.sqrt(2**n)
    print(f"Match Expected (Equal Superposition): {np.allclose(np.abs(qft_state), expected)}")

