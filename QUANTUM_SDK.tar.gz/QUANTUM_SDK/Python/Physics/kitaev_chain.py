"""
[Alpha Quantum SDK - Topological Quantum]
Topic: Kitaev Chain (Majorana Fermions)
Purpose: Simulating a 1D superconducting chain to identify topological end states.
Hamiltonian: H = -t sum(c_i^dag c_{i+1}) + Delta sum(c_i c_{i+1}) + chemical_mu sum(n_i)
"""

import numpy as np

def kitaev_hamiltonian(n_sites, t, delta, mu):
    """
    Constructs the Hamiltonian in the Bogoliubov-de Gennes (BdG) basis.
    Dimension: 2N x 2N
    """
    dim = 2 * n_sites
    H = np.zeros((dim, dim), dtype=complex)
    
    for i in range(n_sites):
        # On-site chemical potential
        H[i, i] = -mu
        H[i + n_sites, i + n_sites] = mu
        
        if i < n_sites - 1:
            # Hopping t
            H[i, i+1] = -t
            H[i+1, i] = -t
            H[i+n_sites+1, i+n_sites] = t
            H[i+n_sites, i+n_sites+1] = t
            
            # Superconducting pairing Delta
            H[i, i+n_sites+1] = delta
            H[i+1, i+n_sites] = -delta
            H[i+n_sites+1, i] = -delta
            H[i+n_sites, i+1] = delta
            
    return H

if __name__ == "__main__":
    N = 20
    t, delta = 1.0, 1.0
    mu = 0.0 # Topological phase (mu < 2t)
    
    print(f"Analyzing Kitaev Chain (N={N}, mu={mu})...")
    H = kitaev_hamiltonian(N, t, delta, mu)
    energies = np.linalg.eigvalsh(H)
    
    # In topological phase, there should be a pair of near-zero energy modes
    zero_modes = energies[np.abs(energies) < 1e-3]
    print(f"Found {len(zero_modes)} near-zero energy modes (Majorana states).")
    print(f"Lowest Energy Gap: {np.min(np.abs(energies[energies > 1e-3])):.4f}")
