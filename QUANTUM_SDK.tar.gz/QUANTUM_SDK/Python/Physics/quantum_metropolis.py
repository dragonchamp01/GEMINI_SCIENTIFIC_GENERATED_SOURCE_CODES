"""
[Alpha Quantum SDK - Quantum Monte Carlo]
Topic: Quantum Metropolis Algorithm (Concept)
Purpose: Sampling from a quantum distribution |psi(x)|^2.
"""

import numpy as np

def quantum_metropolis_step(curr_x, psi_func, step_size):
    """
    Standard Metropolis step for probability density |psi|^2.
    """
    # Propose new position
    next_x = curr_x + np.random.uniform(-step_size, step_size)
    
    # Prob ratio = |psi(next)|^2 / |psi(curr)|^2
    prob_ratio = (np.abs(psi_func(next_x))**2) / (np.abs(psi_func(curr_x))**2)
    
    if np.random.rand() < prob_ratio:
        return next_x
    return curr_x

if __name__ == "__main__":
    # Target: SHO ground state psi = exp(-x^2 / 2)
    def psi_sho(x): return np.exp(-x**2 / 2.0)
    
    x = 0.0
    samples = []
    print("Running Quantum Metropolis Sampling...")
    for _ in range(10000):
        x = quantum_metropolis_step(x, psi_sho, 0.5)
        samples.append(x)
        
    print(f"Sample Mean: {np.mean(samples):.4f} (Expected: 0.0)")
    print(f"Sample Var:  {np.var(samples):.4f}  (Expected: 1.0)")
