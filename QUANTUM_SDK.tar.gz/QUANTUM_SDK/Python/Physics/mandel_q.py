"""
[Alpha Quantum SDK - Quantum Optics]
Topic: Mandel Q-parameter
Purpose: Characterizing the non-classicality of photon statistics.
Formula: Q = (Var(n) - <n>) / <n>
"""

import numpy as np

def calculate_mandel_q(photon_counts):
    """
    Args:
        photon_counts: List of detected photon numbers.
    """
    n = np.array(photon_counts)
    mean_n = np.mean(n)
    var_n = np.var(n)
    
    if mean_n == 0: return 0
    return (var_n - mean_n) / mean_n

if __name__ == "__main__":
    # Case 1: Coherent State (Poisson, Q=0)
    coherent = np.random.poisson(lam=5.0, size=1000)
    
    # Case 2: Thermal State (Super-Poisson, Q > 0)
    thermal = np.random.negative_binomial(n=1, p=0.2, size=1000)
    
    # Case 3: Fock State |n> (Sub-Poisson, Q = -1) - Mocked
    fock = np.full(1000, 5)
    
    print("Mandel Q Parameter Analysis")
    print("---------------------------")
    print(f"Coherent State Q: {calculate_mandel_q(coherent):.4f} (Ideal: 0)")
    print(f"Thermal State Q:  {calculate_mandel_q(thermal):.4f} (Ideal: >0)")
    print(f"Fock State Q:     {calculate_mandel_q(fock):.4f} (Ideal: -1)")
