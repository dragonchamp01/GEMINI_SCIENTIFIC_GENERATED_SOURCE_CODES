"""
[Alpha Quantum SDK - Measurement Dynamics]
Topic: Quantum Zeno Effect
Purpose: Demonstrating that frequent observation inhibits transition.
"""

import numpy as np

def simulate_zeno(total_time, n_measurements, omega):
    """
    Args:
        total_time: T.
        n_measurements: Frequency of observations.
        omega: Rabi frequency of transition.
    """
    dt = total_time / n_measurements
    prob_survival = 1.0
    
    # Prob(remain in state) = cos^2(omega * dt)
    # Total Prob = [cos^2(omega * dt)]^n
    for _ in range(n_measurements):
        prob_survival *= np.cos(omega * dt)**2
        
    return prob_survival

if __name__ == "__main__":
    T = 1.0
    W = 1.5 # Rabi frequency
    
    print(f"Quantum Zeno Effect Analysis (T={T}, Omega={W})")
    print("Measurements | Survival Probability")
    print("-------------|---------------------")
    
    for n in [1, 10, 100, 1000]:
        p = simulate_zeno(T, n, W)
        print(f" {n:11d} | {p:18.6f}")
        
    print("
Result: As n -> infinity, the system is frozen in its initial state.")
