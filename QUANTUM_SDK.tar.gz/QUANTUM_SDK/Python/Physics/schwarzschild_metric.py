"""
[Alpha Quantum SDK - Relativity]
Topic: Schwarzschild Metric & Spacetime Curvature
Purpose: Calculating the metric tensor components near a non-rotating mass.
Formula: ds^2 = -(1 - 2M/r)dt^2 + (1 - 2M/r)^-1 dr^2 + r^2(d_theta^2 + sin^2(theta)d_phi^2)
"""

import numpy as np

class SchwarzschildMetric:
    def __init__(self, M):
        self.M = M # Mass of the central object (G=c=1)
        self.rs = 2 * M # Schwarzschild radius

    def get_components(self, r, theta):
        """Returns the non-zero g_uv components at (r, theta)."""
        if r <= self.rs:
            return "Inside Event Horizon"
            
        g_tt = -(1 - self.rs / r)
        g_rr = 1 / (1 - self.rs / r)
        g_th = r**2
        g_ph = (r**2) * (np.sin(theta)**2)
        
        return {
            "g_tt": g_tt,
            "g_rr": g_rr,
            "g_theta_theta": g_th,
            "g_phi_phi": g_ph
        }

if __name__ == "__main__":
    M_sun = 1.0 # Normalized
    sm = SchwarzschildMetric(M_sun)
    
    # Test at 3 times the Schwarzschild radius
    r_test = 3 * sm.rs
    theta_test = np.pi / 2
    
    components = sm.get_components(r_test, theta_test)
    print(f"--- Schwarzschild Metric at r={r_test}M ---")
    for k, v in components.items():
        print(f"  {k}: {v:.4f}")
