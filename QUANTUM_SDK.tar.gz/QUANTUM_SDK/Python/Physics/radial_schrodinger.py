"""
[Alpha Quantum SDK - Atomic Physics]
Topic: Radial Schrodinger Equation (Hydrogen Atom)
Purpose: Numerical solution for the radial wavefunction R_nl(r).
Equation: -1/2 * d2(u)/dr2 + [l(l+1)/2r^2 - 1/r] * u = E * u (where u = r*R)
"""

import numpy as np

def hydrogen_radial_potential(r, l):
    """Effective potential: Centrifugal term + Coulomb term."""
    # Using atomic units: hbar = m = e = 1
    if r == 0: return 1e9
    return (l * (l + 1)) / (2 * r**2) - (1.0 / r)

def solve_radial_wf(n, l, r_max=20.0, n_points=1000):
    """
    Finds the radial wavefunction for given quantum numbers n, l.
    """
    dr = r_max / n_points
    r = np.linspace(dr, r_max, n_points)
    
    # Finite Difference Matrix for -0.5 * d2/dr2
    k = -0.5 / (dr**2)
    H = np.zeros((n_points, n_points))
    for i in range(n_points):
        H[i, i] = -2 * k + hydrogen_radial_potential(r[i], l)
        if i > 0: H[i, i-1] = k
        if i < n_points - 1: H[i, i+1] = k
        
    # Find eigenvalues and eigenvectors
    evals, evecs = np.linalg.eigh(H)
    
    # Sort and pick the state corresponding to n
    # Energy E_n = -1 / (2*n^2)
    target_E = -1.0 / (2 * n**2)
    idx = np.argmin(np.abs(evals - target_E))
    
    return r, evecs[:, idx], evals[idx]

if __name__ == "__main__":
    n, l = 1, 0 # Ground state 1s
    print(f"Solving Hydrogen Radial Equation for n={n}, l={l}...")
    r, u, E = solve_radial_wf(n, l)
    
    print(f"Calculated Energy: {E:.6f} a.u.")
    print(f"Analytical Energy: {-0.5/(n**2):.6f} a.u.")
    print(f"Peak Probability at r = {r[np.argmax(u**2)]:.4f} (Expected for 1s: 1.0)")
