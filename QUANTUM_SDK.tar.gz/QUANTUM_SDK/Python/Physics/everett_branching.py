"""
[Alpha Quantum SDK - Interpretations]
Topic: Everettian Branching (Many Worlds)
Purpose: Simulating the relative state formulation of quantum mechanics.
"""

import numpy as np

class UniversalWavefunction:
    def __init__(self):
        # Basis: |System>_i |Observer>_j
        # Initial: |+>_s |Ready>_o
        self.branches = {
            "System:0 | Observer:Ready": 1.0/np.sqrt(2),
            "System:1 | Observer:Ready": 1.0/np.sqrt(2)
        }

    def interact(self):
        """Observer measures the system, causing entanglement (branching)."""
        new_branches = {}
        for description, amp in self.branches.items():
            if "System:0" in description:
                new_branches["System:0 | Observer:Saw_0"] = amp
            else:
                new_branches["System:1 | Observer:Saw_1"] = amp
        self.branches = new_branches

    def print_worlds(self):
        print("Universal State Branches:")
        for desc, amp in self.branches.items():
            prob = abs(amp)**2
            print(f" -> {desc} | Probability: {prob*100:.1f}%")

if __name__ == "__main__":
    universe = UniversalWavefunction()
    print("Pre-measurement state (Superposition):")
    universe.print_worlds()
    
    print("
Observation Event Occurring...")
    universe.interact()
    
    universe.print_worlds()
    print("
Note: In MWI, both branches exist simultaneously in the global state.")
