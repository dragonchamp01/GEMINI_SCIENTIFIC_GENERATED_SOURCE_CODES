"""
[Alpha Quantum SDK - Many-Body Physics]
Topic: Second Quantization (Fock States)
Purpose: Modeling particle occupation numbers and operator actions.
"""

import numpy as np

class FockState:
    def __init__(self, occupations):
        """Args: occupations list [n1, n2, ..., nk]"""
        self.state = np.array(occupations)

    def annihilate(self, mode_idx):
        """Applies a_i to the state."""
        if self.state[mode_idx] > 0:
            coeff = np.sqrt(self.state[mode_idx])
            new_state = self.state.copy()
            new_state[mode_idx] -= 1
            return new_state, coeff
        return None, 0

    def create(self, mode_idx):
        """Applies a_i_dag to the state."""
        coeff = np.sqrt(self.state[mode_idx] + 1)
        new_state = self.state.copy()
        new_state[mode_idx] += 1
        return new_state, coeff

if __name__ == "__main__":
    initial_fock = FockState([2, 0, 1]) # 2 particles in mode 0, 1 in mode 2
    print(f"Initial Fock State: {initial_fock.state}")
    
    # Annihilate 1 particle from mode 0
    new_s, c = initial_fock.annihilate(0)
    print(f"Action a_0 |2,0,1>: coeff={c:.4f}, state={new_s}")
