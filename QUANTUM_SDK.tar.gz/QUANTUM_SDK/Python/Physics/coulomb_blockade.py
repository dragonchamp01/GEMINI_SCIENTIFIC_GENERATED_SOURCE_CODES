"""
[Alpha Quantum SDK - Nanotechnology]
Topic: Coulomb Blockade in Quantum Dots
Purpose: Modeling the charging energy and tunneling in single-electron devices.
Formula: E_charge = e^2 / (2 * C_total)
"""

import numpy as np

class QuantumDotSET:
    def __init__(self, capacitance, temperature):
        self.C = capacitance # Farads
        self.T = temperature # Kelvin
        self.e = 1.602e-19
        self.kB = 1.38e-23

    def get_charging_energy(self):
        """Ec = e^2 / (2C)"""
        return (self.e**2) / (2 * self.C)

    def is_blocked(self, voltage_bias):
        """Determines if current is blocked by Coulomb energy."""
        Ec = self.get_charging_energy()
        thermal_energy = self.kB * self.T
        
        # If bias energy < Charging energy, tunneling is suppressed
        bias_energy = self.e * abs(voltage_bias)
        return bias_energy < Ec or thermal_energy > Ec

if __name__ == "__main__":
    # Tiny dot with attofarad capacitance
    dot = QuantumDotSET(capacitance=1e-18, temperature=0.1)
    Ec_ev = dot.get_charging_energy() / 1.602e-19
    
    print(f"Quantum Dot Analysis (C={dot.C} F)")
    print(f"Charging Energy: {Ec_ev:.4f} eV")
    print(f"Blocked at 0.05V bias? {dot.is_blocked(0.05)}")
