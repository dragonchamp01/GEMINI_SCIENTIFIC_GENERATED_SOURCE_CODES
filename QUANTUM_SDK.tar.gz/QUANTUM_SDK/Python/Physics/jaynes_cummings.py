"""
[Alpha Quantum SDK - Quantum Optics]
Topic: Jaynes-Cummings Model
Purpose: Simulating the interaction between a qubit and a quantized cavity mode.
Hamiltonian: H = 0.5*hbar*wa*sigma_z + hbar*wc*a_dag*a + hbar*g*(a*sigma_plus + a_dag*sigma_minus)
"""

import numpy as np

def jc_hamiltonian(n_max, omega_a, omega_c, g):
    """
    Constructs the JC Hamiltonian in the |atom, n_photons> basis.
    Args:
        n_max: Maximum number of photons in the cavity.
        omega_a: Atomic transition frequency.
        omega_c: Cavity frequency.
        g: Coupling strength.
    """
    dim = 2 * (n_max + 1)
    H = np.zeros((dim, dim), dtype=complex)
    
    for n in range(n_max + 1):
        # Indices: |g, n> -> 2*n, |e, n> -> 2*n + 1
        # Atomic/Cavity energy
        H[2*n, 2*n] = -0.5 * omega_a + n * omega_c
        H[2*n+1, 2*n+1] = 0.5 * omega_a + n * omega_c
        
        # Interaction (RWA)
        if n < n_max:
            # |e, n> <-> |g, n+1|
            interaction = g * np.sqrt(n + 1)
            H[2*n+1, 2*n+2] = interaction
            H[2*n+2, 2*n+1] = interaction
            
    return H

if __name__ == "__main__":
    n_photons = 5
    wa, wc, g = 1.0, 1.0, 0.1 # Resonance condition
    
    print(f"Constructing Jaynes-Cummings Hamiltonian (n_max={n_photons})...")
    H = jc_hamiltonian(n_photons, wa, wc, g)
    
    # Find eigenvalues (Rabi Splitting)
    energies = np.linalg.eigvalsh(H)
    print("
First 4 Energy Levels (showing Rabi splitting):")
    print(np.round(energies[:4], 4))
