"""
[Alpha Quantum SDK - Measurement]
Topic: Quantum State Tomography (1-Qubit)
Purpose: Reconstructing the density matrix rho from Pauli expectations.
"""
import numpy as np
from ..gemini_circuit import QuantumCircuit

def get_expectations(statevector):
    """
    Simulates measurements for Pauli X, Y, Z on a single qubit statevector.
    """
    X = np.array([[0, 1], [1, 0]], dtype=complex)
    Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
    Z = np.array([[1, 0], [0, -1]], dtype=complex)
    
    # <A> = <psi| A |psi>
    exp_x = np.vdot(statevector, np.dot(X, statevector)).real
    exp_y = np.vdot(statevector, np.dot(Y, statevector)).real
    exp_z = np.vdot(statevector, np.dot(Z, statevector)).real
    
    return exp_x, exp_y, exp_z

def reconstruct_rho(exp_x, exp_y, exp_z):
    """
    rho = 0.5 * (I + <X>X + <Y>Y + <Z>Z)
    """
    I = np.eye(2, dtype=complex)
    X = np.array([[0, 1], [1, 0]], dtype=complex)
    Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
    Z = np.array([[1, 0], [0, -1]], dtype=complex)
    
    rho = 0.5 * (I + exp_x * X + exp_y * Y + exp_z * Z)
    return rho

if __name__ == "__main__":
    # 1. Prepare a state using QuantumCircuit
    qc = QuantumCircuit(1)
    qc.h(0) # State |+> = [1/sqrt(2), 1/sqrt(2)]
    
    state = qc.simulate()
    print(f"Prepared Statevector: {np.round(state, 3)}")
    
    # 2. Simulate expectations
    ex, ey, ez = get_expectations(state)
    print(f"Simulated Expectations: <X>={ex:.2f}, <Y>={ey:.2f}, <Z>={ez:.2f}")
    
    # 3. Reconstruct rho
    rho_rec = reconstruct_rho(ex, ey, ez)
    print("Reconstructed Density Matrix:
", np.round(rho_rec, 3))
    
    # Expected for |+>: [[0.5, 0.5], [0.5, 0.5]]
    expected_rho = np.array([[0.5, 0.5], [0.5, 0.5]])
    print(f"Match Expected: {np.allclose(rho_rec, expected_rho)}")

