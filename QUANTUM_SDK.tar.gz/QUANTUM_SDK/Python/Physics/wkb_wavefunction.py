"""
[Alpha Quantum SDK - Semi-classical QM]
Topic: WKB Wavefunction Construction
Purpose: Computing the oscillating and exponential parts of the WKB approximation.
Formula: psi(x) ~ [p(x)]^(-1/2) * exp(i/hbar * integral p(x) dx)
"""

import numpy as np

def wkb_wavefunction(x_grid, V_func, E, m=1.0, hbar=1.0):
    """
    Constructs the WKB wavefunction for a given energy E.
    """
    # Momentum p(x) = sqrt(2m(E - V(x)))
    p_sq = 2.0 * m * (E - V_func(x_grid))
    
    # Identify classically allowed (p^2 > 0) and forbidden (p^2 < 0) regions
    allowed = p_sq > 0
    forbidden = ~allowed
    
    psi = np.zeros_like(x_grid, dtype=complex)
    
    # Allowed Region: Oscillatory
    p = np.sqrt(p_sq[allowed])
    phase = np.cumsum(p) * (x_grid[1] - x_grid[0]) / hbar
    psi[allowed] = (1.0 / np.sqrt(p)) * np.exp(1j * phase)
    
    # Forbidden Region: Exponential Decay
    kappa = np.sqrt(-p_sq[forbidden])
    decay = np.cumsum(kappa) * (x_grid[1] - x_grid[0]) / hbar
    psi[forbidden] = (1.0 / np.sqrt(kappa)) * np.exp(-decay)
    
    return psi

if __name__ == "__main__":
    # Harmonic Potential V = 0.5 * x^2
    x = np.linspace(-5, 5, 500)
    def V(x): return 0.5 * x**2
    E = 2.0 # Classically allowed between -2 and 2
    
    print(f"Constructing WKB Wavefunction for E={E}")
    psi_wkb = wkb_wavefunction(x, V, E)
    
    # Find turning points
    tp = np.where(np.diff(E > V(x)))[0]
    print(f"Turning Points detected at x approx: {x[tp]}")
    print(f"Max Amplitude in allowed region: {np.max(np.abs(psi_wkb)):.4f}")
