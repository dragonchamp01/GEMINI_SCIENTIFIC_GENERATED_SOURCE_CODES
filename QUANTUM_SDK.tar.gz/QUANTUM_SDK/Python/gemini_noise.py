"""
Gemini Quantum SDK - Python Noise Models
----------------------------------------
Tools for simulating decoherence and gate errors.
"""

import numpy as np

class NoiseModel:
    @staticmethod
    def depolarizing_error(p):
        """Returns a set of Kraus operators for a depolarizing channel."""
        # rho -> (1-p)rho + (p/3)(X rho X + Y rho Y + Z rho Z)
        I = np.eye(2, dtype=complex)
        X = np.array([[0, 1], [1, 0]], dtype=complex)
        Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
        Z = np.array([[1, 0], [0, -1]], dtype=complex)
        
        return [
            np.sqrt(1 - p) * I,
            np.sqrt(p / 3) * X,
            np.sqrt(p / 3) * Y,
            np.sqrt(p / 3) * Z
        ]

    @staticmethod
    def amplitude_damping(gamma):
        """Kraus operators for amplitude damping (T1 relaxation)."""
        E0 = np.array([[1, 0], [0, np.sqrt(1 - gamma)]], dtype=complex)
        E1 = np.array([[0, np.sqrt(gamma)], [0, 0]], dtype=complex)
        return [E0, E1]

class DensityMatrixSimulator:
    def __init__(self, n_qubits):
        self.n = n_qubits
        dim = 2**n_qubits
        # Initialize to |0...0><0...0|
        self.rho = np.zeros((dim, dim), dtype=complex)
        self.rho[0, 0] = 1.0

    def apply_unitary(self, U):
        """rho -> U rho U_dag"""
        self.rho = U @ self.rho @ U.conj().T

    def apply_kraus(self, kraus_ops, target_qubit):
        """rho -> sum(Ek rho Ek_dag)"""
        new_rho = np.zeros_like(self.rho)
        dim = 2**self.n
        
        for Ek in kraus_ops:
            # Expand Ek to full space
            full_Ek = 1
            for i in range(self.n):
                if i == target_qubit:
                    full_Ek = np.kron(full_Ek, Ek)
                else:
                    full_Ek = np.kron(full_Ek, np.eye(2))
            
            new_rho += full_Ek @ self.rho @ full_Ek.conj().T
        
        self.rho = new_rho

    def get_purity(self):
        return np.trace(self.rho @ self.rho).real

    def partial_trace(self, keep_indices):
        """Computes reduced density matrix for qubits in keep_indices."""
        n_keep = len(keep_indices)
        dim_keep = 2**n_keep
        res = np.zeros((dim_keep, dim_keep), dtype=complex)
        
        # Binary mask logic for partial trace
        for i in range(2**self.n):
            for j in range(2**self.n):
                # Check if traced-out bits match
                match = True
                idx_i_new = 0
                idx_j_new = 0
                
                for k in range(self.n):
                    bit_i = (i >> k) & 1
                    bit_j = (j >> k) & 1
                    
                    if k in keep_indices:
                        new_pos = keep_indices.index(k)
                        idx_i_new |= (bit_i << new_pos)
                        idx_j_new |= (bit_j << new_pos)
                    else:
                        if bit_i != bit_j:
                            match = False
                            break
                
                if match:
                    res[idx_i_new, idx_j_new] += self.rho[i, j]
        return res

if __name__ == "__main__":

    print("Noise Model & Density Matrix Simulator Initialized.")
    sim = DensityMatrixSimulator(1)
    
    # Apply H gate
    H = np.array([[1, 1], [1, -1]]) / np.sqrt(2)
    sim.apply_unitary(H)
    print(f"Purity after H: {sim.get_purity():.4f}")
    
    # Apply Depolarizing Noise
    kraus = NoiseModel.depolarizing_error(0.1)
    sim.apply_kraus(kraus, 0)
    print(f"Purity after 10% Depolarizing Noise: {sim.get_purity():.4f}")
