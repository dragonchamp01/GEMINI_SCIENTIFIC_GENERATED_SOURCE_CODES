"""
Gemini Quantum SDK - Python Circuit Module
------------------------------------------
Advanced circuit representation and statevector evolution.
"""

import numpy as np
from .gemini_quantum_core import QuantumGates, QuantumState

class QuantumCircuit:
    def __init__(self, n_qubits):
        self.n = n_qubits
        self.state = QuantumState(n_qubits)
        self.gates = []

    def h(self, target):
        """Add Hadamard gate."""
        self.gates.append(('H', target))
        
    def cx(self, control, target):
        """Add CNOT gate."""
        self.gates.append(('CX', control, target))

    def x(self, target):
        """Add X (Pauli-X) gate."""
        self.gates.append(('X', target))

    def y(self, target):
        """Add Y (Pauli-Y) gate."""
        self.gates.append(('Y', target))

    def z(self, target):
        """Add Z (Pauli-Z) gate."""
        self.gates.append(('Z', target))

    def ry(self, target, theta):
        """Add RY (Rotation-Y) gate with angle theta."""
        self.gates.append(('RY', target, theta))

    def rx(self, target, theta):
        """Add RX (Rotation-X) gate with angle theta."""
        self.gates.append(('RX', target, theta))

    def rz(self, target, theta):
        """Add RZ (Rotation-Z) gate with angle theta."""
        self.gates.append(('RZ', target, theta))

    def cz(self, control, target):
        """Add Controlled-Z gate."""
        self.gates.append(('CZ', control, target))

    def ccx(self, control1, control2, target):
        """Add Toffoli (CCX) gate."""
        self.gates.append(('CCX', control1, control2, target))

    def cp(self, control, target, phi):
        """Add Controlled-Phase (CP) gate with phase phi."""
        self.gates.append(('CP', control, target, phi))

    def mcp(self, controls, target, phi):
        """Add Multi-Control Phase (MCP) gate with phase phi."""
        self.gates.append(('MCP', list(controls), target, phi))

    def mcu(self, controls, target, unitary_matrix):
        """Add Multi-Controlled Unitary (MCU) gate."""
        self.gates.append(('MCU', list(controls), target, unitary_matrix))

    def get_full_matrix(self, gate_matrix, target):

        """Computes the full 2^n x 2^n matrix for a single-qubit gate."""
        res = 1
        for i in range(self.n):
            if i == target:
                res = np.kron(res, gate_matrix)
            else:
                res = np.kron(res, np.eye(2))
        return res

    def get_controlled_matrix(self, control, target, gate_matrix):
        """Computes the full 2^n x 2^n matrix for a controlled single-qubit gate."""
        p0 = np.array([[1, 0], [0, 0]])
        p1 = np.array([[0, 0], [0, 1]])
        
        full_0 = 1
        full_1 = 1
        
        for i in range(self.n):
            if i == control:
                full_0 = np.kron(full_0, p0)
                full_1 = np.kron(full_1, p1)
            elif i == target:
                full_0 = np.kron(full_0, np.eye(2))
                full_1 = np.kron(full_1, gate_matrix)
            else:
                full_0 = np.kron(full_0, np.eye(2))
                full_1 = np.kron(full_1, np.eye(2))
        
        return full_0 + full_1

    def simulate(self):
        """Executes all gates on the initial statevector."""
        for gate in self.gates:
            if gate[0] in ['H', 'X', 'Y', 'Z']:
                g_map = {'H': QuantumGates.H, 'X': QuantumGates.X, 'Y': QuantumGates.Y, 'Z': QuantumGates.Z}
                op = self.get_full_matrix(g_map[gate[0]], gate[1])
                self.state.psi = np.dot(op, self.state.psi)
            elif gate[0] == 'RY':
                theta = gate[2]
                ry_mat = np.array([[np.cos(theta/2), -np.sin(theta/2)], [np.sin(theta/2), np.cos(theta/2)]])
                op = self.get_full_matrix(ry_mat, gate[1])
                self.state.psi = np.dot(op, self.state.psi)
            elif gate[0] == 'RX':
                theta = gate[2]
                rx_mat = np.array([[np.cos(theta/2), -1j*np.sin(theta/2)], [-1j*np.sin(theta/2), np.cos(theta/2)]])
                op = self.get_full_matrix(rx_mat, gate[1])
                self.state.psi = np.dot(op, self.state.psi)
            elif gate[0] == 'RZ':
                theta = gate[2]
                rz_mat = np.array([[np.exp(-1j*theta/2), 0], [0, np.exp(1j*theta/2)]])
                op = self.get_full_matrix(rz_mat, gate[1])
                self.state.psi = np.dot(op, self.state.psi)
            elif gate[0] == 'CX':

                op = self.get_controlled_matrix(gate[1], gate[2], QuantumGates.X)
                self.state.psi = np.dot(op, self.state.psi)
            elif gate[0] == 'CZ':
                op = self.get_controlled_matrix(gate[1], gate[2], QuantumGates.Z)
                self.state.psi = np.dot(op, self.state.psi)
            elif gate[0] == 'CP':
                # CP matrix: |11> -> exp(i*phi)|11>
                phi = gate[3]
                cp_mat = np.array([[1, 0], [0, np.exp(1j * phi)]])
                op = self.get_controlled_matrix(gate[1], gate[2], cp_mat)
                self.state.psi = np.dot(op, self.state.psi)
            elif gate[0] == 'MCP':
                # Multi-controlled Phase flip
                controls, target, phi = gate[1], gate[2], gate[3]
                mask = 0
                for c in controls: mask |= (1 << c)
                mask |= (1 << target)
                
                phase = np.exp(1j * phi)
                for i in range(2**self.n):
                    if (i & mask) == mask:
                        self.state.psi[i] *= phase
            elif gate[0] == 'MCU':
                # Multi-controlled Unitary
                controls, target, U = gate[1], gate[2], gate[3]
                c_mask = 0
                for c in controls: c_mask |= (1 << c)
                t_mask = (1 << target)
                
                for i in range(2**self.n):
                    if (i & c_mask) == c_mask and not (i & t_mask):
                        j = i | t_mask
                        psi_i = self.state.psi[i]
                        psi_j = self.state.psi[j]
                        
                        self.state.psi[i] = U[0,0]*psi_i + U[0,1]*psi_j
                        self.state.psi[j] = U[1,0]*psi_i + U[1,1]*psi_j
            elif gate[0] == 'CCX':
                # Toffoli: |110> <-> |111>
                c1, c2, t = gate[1], gate[2], gate[3]
                for i in range(2**self.n):
                    # Check if both control bits are 1
                    if ((i >> c1) & 1) and ((i >> c2) & 1):
                        # If target bit is 0, swap with the state where target bit is 1
                        if not ((i >> t) & 1):
                            j = i | (1 << t)
                            self.state.psi[i], self.state.psi[j] = self.state.psi[j], self.state.psi[i]

        return self.state.psi



    def get_probabilities(self):
        """Return array of probabilities for all computational basis states."""
        return np.abs(self.state.psi)**2

    def measure(self):
        """Samples one state index from the current probability distribution."""
        probs = self.get_probabilities()
        # Ensure probabilities sum to 1.0 (float precision)
        probs /= np.sum(probs)
        return np.random.choice(len(probs), p=probs)

if __name__ == "__main__":

    qc = QuantumCircuit(2)
    qc.h(0)
    qc.cx(0, 1)
    probs = qc.get_probabilities()
    print(f"Probabilities after Bell Phi+ circuit: {probs}")

