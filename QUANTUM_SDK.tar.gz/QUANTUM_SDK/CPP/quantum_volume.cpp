/**
 * [Alpha Quantum SDK - Benchmarking]
 * Topic: Quantum Volume (QV) in C++
 * Purpose: Measuring the quality of the C++ simulation engine.
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <vector>
#include <numeric>
#include <algorithm>
#include <random>

using namespace Gemini::Quantum;

double calculate_heavy_prob(const StateVector& probs) {
    std::vector<double> d_probs;
    for (const auto& p : probs) d_probs.push_back(p.real());
    
    std::vector<double> sorted_probs = d_probs;
    std::sort(sorted_probs.begin(), sorted_probs.end());
    
    double median = 0;
    int n = sorted_probs.size();
    if (n % 2 == 0) median = (sorted_probs[n/2 - 1] + sorted_probs[n/2]) / 2.0;
    else median = sorted_probs[n/2];
    
    double heavy_prob = 0;
    for (double p : d_probs) {
        if (p > median) heavy_prob += p;
    }
    return heavy_prob;
}

bool run_qv_test(int n_qubits, int n_trials = 100) {
    std::cout << "--- Quantum Volume Benchmark (C++): " << n_qubits << " Qubits ---" << std::endl;
    
    int heavy_count = 0;
    std::mt19937 gen(42);
    std::uniform_real_distribution<> dis(0, 2 * M_PI);

    for (int t = 0; t < n_trials; ++t) {
        Simulator sim(n_qubits);
        
        // Random square circuit depth = n_qubits
        for (int layer = 0; layer < n_qubits; ++layer) {
            // Random RY rotations
            for (int q = 0; q < n_qubits; ++q) sim.ry(q, dis(gen));
            
            // Random entanglements (simplified pairing)
            std::vector<int> p(n_qubits);
            std::iota(p.begin(), p.end(), 0);
            std::shuffle(p.begin(), p.end(), gen);
            for (int i = 0; i < n_qubits - 1; i += 2) {
                sim.cx(p[i], p[i+1]);
            }
        }
        
        auto probs = sim.get_probabilities();
        if (calculate_heavy_prob(probs) > 2.0/3.0) {
            heavy_count++;
        }
    }
    
    double success_rate = (double)heavy_count / n_trials;
    std::cout << "Success Rate: " << success_rate << " (Threshold: 0.667)" << std::endl;
    return success_rate > 2.0/3.0;
}

int main() {
    for (int n = 2; n <= 10; ++n) {
        if (run_qv_test(n, 50)) {
            std::cout << "PASSED: Log2(QV) >= " << n << std::endl;
        } else {
            std::cout << "FAILED at " << n << " qubits." << std::endl;
            break;
        }
    }
    return 0;
}
