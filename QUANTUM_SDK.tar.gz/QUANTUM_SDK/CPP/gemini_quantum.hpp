/**
 * Gemini Quantum SDK - C++ Template Library
 * -----------------------------------------
 * High-performance quantum state simulations using C++17.
 */

#ifndef GEMINI_QUANTUM_HPP
#define GEMINI_QUANTUM_HPP

#include <vector>
#include <complex>
#include <cmath>
#include <iostream>
#include <random>
#include <algorithm>
#include <numeric>
#include <immintrin.h>

namespace Gemini {
    namespace Quantum {

        using Complex = std::complex<double>;
        using StateVector = std::vector<Complex>;

        class Simulator {
            int n_qubits;
            StateVector state;
            std::mt19937 gen;

        public:
            Simulator(int n) : n_qubits(n), gen(std::random_device{}()) {
                state.assign(1 << n, 0.0);
                state[0] = 1.0;
            }

            void h(int target) {
                int n_states = 1 << n_qubits;
                double inv_sqrt2 = 1.0 / std::sqrt(2.0);
                int mask = 1 << target;

#ifdef __AVX512F__
                // Ultra-optimized path for AVX-512 (8 doubles = 4 complex numbers per reg)
                if (n_states >= 8) {
                    __m512d factor = _mm512_set1_pd(inv_sqrt2);
                    for (int i = 0; i < n_states; i += 4) {
                        // Check if block of 4 bits doesn't have the mask bit set
                        // This is a simplification; for target > 1, we might need a more complex loop
                        // but for bit 0 or 1 this works. For general target, we check individually.
                        if (!(i & mask) && !((i+1) & mask) && !((i+2) & mask) && !((i+3) & mask)) {
                            int j = i | mask;
                            __m512d vi = _mm512_loadu_pd((double*)&state[i]);
                            __m512d vj = _mm512_loadu_pd((double*)&state[j]);
                            
                            __m512d res_i = _mm512_mul_pd(_mm512_add_pd(vi, vj), factor);
                            __m512d res_j = _mm512_mul_pd(_mm512_sub_pd(vi, vj), factor);
                            
                            _mm512_storeu_pd((double*)&state[i], res_i);
                            _mm512_storeu_pd((double*)&state[j], res_j);
                        } else {
                            // Individual fallback for mixed bit-mask blocks
                            for (int k = 0; k < 4; ++k) {
                                int curr = i + k;
                                if (!(curr & mask)) {
                                    int target_j = curr | mask;
                                    Complex psi_i = state[curr];
                                    Complex psi_j = state[target_j];
                                    state[curr] = (psi_i + psi_j) * inv_sqrt2;
                                    state[target_j] = (psi_i - psi_j) * inv_sqrt2;
                                }
                            }
                        }
                    }
                    return;
                }
#endif

#ifdef __AVX2__
                // Optimized path for large statevectors (256-bit)
                if (n_states >= 4) {
                    __m256d factor = _mm256_set1_pd(inv_sqrt2);
                    for (int i = 0; i < n_states; ++i) {
                        if (!(i & mask)) {
                            int j = i | mask;
                            
                            // Load two complex numbers (4 doubles) from state[i] and state[j]
                            // Since complex<double> is [re, im], we load [re_i, im_i] and [re_j, im_j]
                            __m256d vi = _mm256_loadu_pd((double*)&state[i]);
                            __m256d vj = _mm256_loadu_pd((double*)&state[j]);
                            
                            // i' = (i + j) * inv_sqrt2
                            // j' = (i - j) * inv_sqrt2
                            __m256d res_i = _mm256_mul_pd(_mm256_add_pd(vi, vj), factor);
                            __m256d res_j = _mm256_mul_pd(_mm256_sub_pd(vi, vj), factor);
                            
                            _mm256_storeu_pd((double*)&state[i], res_i);
                            _mm256_storeu_pd((double*)&state[j], res_j);
                        }
                    }
                    return;
                }
#endif
                // Fallback
                for (int i = 0; i < n_states; ++i) {
                    if (!(i & mask)) {
                        int j = i | mask;
                        Complex psi_i = state[i];
                        Complex psi_j = state[j];
                        
                        state[i] = (psi_i + psi_j) * inv_sqrt2;
                        state[j] = (psi_i - psi_j) * inv_sqrt2;
                    }
                }
            }


            void x(int target) {
                int n_states = 1 << n_qubits;
                int mask = 1 << target;

#ifdef __AVX512F__
                if (n_states >= 8) {
                    for (int i = 0; i < n_states; i += 4) {
                        if (!(i & mask) && !((i+1) & mask) && !((i+2) & mask) && !((i+3) & mask)) {
                            int j = i | mask;
                            __m512d vi = _mm512_loadu_pd((double*)&state[i]);
                            __m512d vj = _mm512_loadu_pd((double*)&state[j]);
                            _mm512_storeu_pd((double*)&state[i], vj);
                            _mm512_storeu_pd((double*)&state[j], vi);
                        } else {
                            for (int k = 0; k < 4; ++k) {
                                int curr = i + k;
                                if (!(curr & mask)) std::swap(state[curr], state[curr | mask]);
                            }
                        }
                    }
                    return;
                }
#endif

#ifdef __AVX2__
                if (n_states >= 4) {
                    for (int i = 0; i < n_states; i += 2) {
                        if (!(i & mask) && !((i+1) & mask)) {
                            int j = i | mask;
                            __m256d vi = _mm256_loadu_pd((double*)&state[i]);
                            __m256d vj = _mm256_loadu_pd((double*)&state[j]);
                            _mm256_storeu_pd((double*)&state[i], vj);
                            _mm256_storeu_pd((double*)&state[j], vi);
                        } else {
                            if (!(i & mask)) std::swap(state[i], state[i | mask]);
                            if (!((i+1) & mask)) std::swap(state[i+1], state[(i+1) | mask]);
                        }
                    }
                    return;
                }
#endif

                for (int i = 0; i < n_states; ++i) {
                    if (!(i & mask)) {
                        int j = i | mask;
                        std::swap(state[i], state[j]);
                    }
                }
            }


            void z(int target) {
                int n_states = 1 << n_qubits;
                int mask = 1 << target;

#ifdef __AVX512F__
                if (n_states >= 8) {
                    __m512d neg_one = _mm512_set1_pd(-1.0);
                    for (int i = 0; i < n_states; i += 4) {
                        // If all 4 bits in block have the mask bit set, multiply entire block by -1
                        if ((i & mask) && ((i+1) & mask) && ((i+2) & mask) && ((i+3) & mask)) {
                            __m512d vi = _mm512_loadu_pd((double*)&state[i]);
                            _mm512_storeu_pd((double*)&state[i], _mm512_mul_pd(vi, neg_one));
                        } else {
                            for (int k = 0; k < 4; ++k) {
                                if ((i + k) & mask) state[i+k] *= -1.0;
                            }
                        }
                    }
                    return;
                }
#endif

#ifdef __AVX2__
                if (n_states >= 4) {
                    __m256d neg_one = _mm256_set1_pd(-1.0);
                    for (int i = 0; i < n_states; i += 2) {
                        if ((i & mask) && ((i+1) & mask)) {
                            __m256d vi = _mm256_loadu_pd((double*)&state[i]);
                            _mm256_storeu_pd((double*)&state[i], _mm256_mul_pd(vi, neg_one));
                        } else {
                            if (i & mask) state[i] *= -1.0;
                            if ((i+1) & mask) state[i+1] *= -1.0;
                        }
                    }
                    return;
                }
#endif

                for (int i = 0; i < n_states; ++i) {
                    if (i & mask) {
                        state[i] *= -1.0;
                    }
                }
            }


            void ry(int target, double theta) {
                int n_states = 1 << n_qubits;
                double c = std::cos(theta / 2.0);
                double s = std::sin(theta / 2.0);
                for (int i = 0; i < n_states; ++i) {
                    if (!(i & (1 << target))) {
                        int j = i | (1 << target);
                        Complex psi_i = state[i];
                        Complex psi_j = state[j];
                        state[i] = c * psi_i - s * psi_j;
                        state[j] = s * psi_i + c * psi_j;
                    }
                }
            }

            void rx(int target, double theta) {
                int n_states = 1 << n_qubits;
                double c = std::cos(theta / 2.0);
                Complex s(0, -std::sin(theta / 2.0));
                for (int i = 0; i < n_states; ++i) {
                    if (!(i & (1 << target))) {
                        int j = i | (1 << target);
                        Complex psi_i = state[i];
                        Complex psi_j = state[j];
                        state[i] = c * psi_i + s * psi_j;
                        state[j] = s * psi_i + c * psi_j;
                    }
                }
            }

            void rz(int target, double theta) {
                int n_states = 1 << n_qubits;
                Complex p0 = std::exp(Complex(0, -theta / 2.0));
                Complex p1 = std::exp(Complex(0, theta / 2.0));
                for (int i = 0; i < n_states; ++i) {
                    if (i & (1 << target)) state[i] *= p1;
                    else state[i] *= p0;
                }
            }

            void cx(int control, int target) {

                int n_states = 1 << n_qubits;
                for (int i = 0; i < n_states; ++i) {
                    // Check if control qubit is 1
                    if ((i & (1 << control)) && !(i & (1 << target))) {
                        int j = i | (1 << target);
                        std::swap(state[i], state[j]);
                    }
                }
            }

            void cp(int control, int target, double phi) {
                int n_states = 1 << n_qubits;
                Complex phase = std::exp(Complex(0, phi));
                for (int i = 0; i < n_states; ++i) {
                    if ((i & (1 << control)) && (i & (1 << target))) {
                        state[i] *= phase;
                    }
                }
            }

            void mcp(const std::vector<int>& controls, int target, double phi) {
                int n_states = 1 << n_qubits;
                int mask = (1 << target);
                for (int c : controls) mask |= (1 << c);
                
                Complex phase = std::exp(Complex(0, phi));
                for (int i = 0; i < n_states; ++i) {
                    if ((i & mask) == mask) {
                        state[i] *= phase;
                    }
                }
            }

            void mcu(const std::vector<int>& controls, int target, const Complex U[2][2]) {
                int n_states = 1 << n_qubits;
                int c_mask = 0;
                for (int c : controls) c_mask |= (1 << c);
                int t_mask = (1 << target);

                for (int i = 0; i < n_states; ++i) {
                    if ((i & c_mask) == c_mask && !(i & t_mask)) {
                        int j = i | t_mask;
                        Complex psi_i = state[i];
                        Complex psi_j = state[j];
                        state[i] = U[0][0] * psi_i + U[0][1] * psi_j;
                        state[j] = U[1][0] * psi_i + U[1][1] * psi_j;
                    }
                }
            }

            void ccx(int c1, int c2, int target) {
                int n_states = 1 << n_qubits;
                for (int i = 0; i < n_states; ++i) {
                    // Check if both control qubits are 1 and target is 0
                    if ((i & (1 << c1)) && (i & (1 << c2)) && !(i & (1 << target))) {
                        int j = i | (1 << target);
                        std::swap(state[i], state[j]);
                    }
                }
            }


            StateVector get_probabilities() {
                StateVector probs(state.size());
                for (size_t i = 0; i < state.size(); ++i) {
                    probs[i] = std::norm(state[i]);
                }
                return probs;
            }

            const StateVector& get_state() const {
                return state;
            }

            int measure() {
                auto probs = get_probabilities();
                std::vector<double> d_probs;
                for (const auto& p : probs) d_probs.push_back(p.real());
                
                std::discrete_distribution<> d(d_probs.begin(), d_probs.end());
                return d(gen);
            }

            void print_state() {
                for (size_t i = 0; i < state.size(); ++i) {
                    if (std::norm(state[i]) > 1e-6) {
                        std::cout << "| " << i << " > : " << state[i] << std::endl;
                    }
                }
            }
        };


    }
}

#endif
