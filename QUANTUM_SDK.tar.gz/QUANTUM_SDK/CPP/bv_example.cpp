/**
 * [Alpha Quantum SDK]
 * Topic: Bernstein-Vazirani Algorithm (C++)
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <string>
#include <bitset>

using namespace Gemini::Quantum;

std::string bv_algorithm(std::string hidden_bits) {
    int n = hidden_bits.length();
    Simulator sim(n + 1);

    for (int i = 0; i < n; ++i) sim.h(i);
    sim.x(n); sim.h(n);

    for (int i = 0; i < n; ++i) {
        if (hidden_bits[n - 1 - i] == '1') {
            sim.cx(i, n);
        }
    }

    for (int i = 0; i < n; ++i) sim.h(i);

    int res = sim.measure();
    std::bitset<32> bs(res & ((1 << n) - 1));
    std::string found = bs.to_string().substr(32 - n);
    std::string rev(found.rbegin(), found.rend());
    return rev;
}

int main() {
    std::string hidden = "1101";
    std::cout << "--- Bernstein-Vazirani Algorithm (C++) ---" << std::endl;
    std::cout << "Target Bits: " << hidden << std::endl;

    std::string result = bv_algorithm(hidden);
    std::cout << "Found:       " << result << std::endl;

    return 0;
}
