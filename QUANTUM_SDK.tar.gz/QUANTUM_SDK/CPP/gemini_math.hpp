/**
 * Gemini Quantum SDK - C++ Matrix Math
 * ------------------------------------
 * High-performance Kronecker product and Linear Algebra.
 */

#ifndef GEMINI_MATH_HPP
#define GEMINI_MATH_HPP

#include "gemini_quantum.hpp"

namespace Gemini::Math {

    using namespace Gemini::Quantum;

    /**
     * @brief Computes C = A (x) B (Kronecker Product)
     */
    Matrix kronecker(const Matrix& A, const Matrix& B) {
        int ar = A.size();
        int ac = A[0].size();
        int br = B.size();
        int bc = B[0].size();
        
        Matrix C(ar * br, std::vector<double>(ac * bc, 0.0));

        for (int i = 0; i < ar; i++) {
            for (int j = 0; j < ac; j++) {
                for (int k = 0; k < br; k++) {
                    for (int l = 0; l < bc; l++) {
                        C[i * br + k][j * bc + l] = A[i][j] * B[k][l];
                    }
                }
            }
        }
        return C;
    }
}

#endif
