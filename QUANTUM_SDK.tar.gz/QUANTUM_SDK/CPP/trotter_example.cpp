/**
 * [Alpha Quantum SDK - Time Dynamics]
 * Topic: Trotter-Suzuki Time Evolution (C++)
 * System: 1D Transverse Field Ising Model (TFIM)
 * Hamiltonian: H = -J * sum(Zi * Zi+1) - h * sum(Xi)
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace Gemini::Quantum;

class TFIMSimulator {
    int n;
    double J, h;
public:
    TFIMSimulator(int qubits, double j_val, double h_val) : n(qubits), J(j_val), h(h_val) {}

    void run_simulation(double t_total, int steps) {
        Simulator sim(n);
        double dt = t_total / steps;

        for (int s = 0; s < steps; ++s) {
            // 1. ZZ Interactions
            double phi_zz = -2.0 * J * dt;
            for (int i = 0; i < n - 1; ++i) {
                sim.cx(i, i + 1);
                sim.rz(i + 1, phi_zz);
                sim.cx(i, i + 1);
            }

            // 2. Transverse Field
            double phi_x = -2.0 * h * dt;
            for (int i = 0; i < n; ++i) {
                sim.rx(i, phi_x);
            }
        }

        std::cout << "--- TFIM Time Evolution (C++) ---" << std::endl;
        auto probs = sim.get_probabilities();
        
        double magnetization = 0.0;
        for (int i = 0; i < (1 << n); ++i) {
            int n_ones = 0;
            for (int q = 0; q < n; ++q) if (i & (1 << q)) n_ones++;
            int n_zeros = n - n_ones;
            magnetization += probs[i].real() * (double)(n_zeros - n_ones) / n;
        }

        std::cout << "Final Magnetization <Z>: " << std::fixed << std::setprecision(4) << magnetization << std::endl;
    }
};

int main() {
    TFIMSimulator tfim(4, 1.0, 0.5);
    tfim.run_simulation(1.0, 20);
    return 0;
}
