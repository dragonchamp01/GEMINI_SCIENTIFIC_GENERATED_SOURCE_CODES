/**
 * [Alpha Quantum SDK]
 * Topic: Bell State Generation using C++ Simulator
 * State: (|00> + |11>) / sqrt(2)
 */

#include "gemini_quantum.hpp"
#include <iostream>

int main() {
    using namespace Gemini::Quantum;

    // 1. Initialize a 2-qubit simulator
    Simulator sim(2);

    std::cout << "--- Initial State ---" << std::endl;
    sim.print_state();

    // 2. Apply H to q0
    sim.h(0);

    // 3. Apply CX from q0 to q1
    sim.cx(0, 1);

    std::cout << "
--- Bell State |Phi+> Generated ---" << std::endl;
    sim.print_state();

    // 4. Print probabilities
    auto probs = sim.get_probabilities();
    std::cout << "
Probabilities:" << std::endl;
    for (size_t i = 0; i < probs.size(); ++i) {
        std::cout << "P(| " << i << " >) = " << probs[i].real() << std::endl;
    }

    return 0;
}
