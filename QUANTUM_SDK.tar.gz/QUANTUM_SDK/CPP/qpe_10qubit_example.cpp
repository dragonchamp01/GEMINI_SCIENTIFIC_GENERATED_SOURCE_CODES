/**
 * [Alpha Quantum SDK]
 * Topic: 10-Qubit Quantum Phase Estimation (C++)
 * Purpose: Precision benchmarking of the AVX-512 accelerated core.
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <algorithm>

using namespace Gemini::Quantum;

int main() {
    int n_count = 10;
    int total = n_count + 1;
    double target_theta = 0.345678;

    std::cout << "--- 10-Qubit QPE precision Benchmark (C++) ---" << std::endl;
    std::cout << "Target Theta: " << target_theta << std::endl;

    Simulator sim(total);

    // 1. Superposition
    for (int i = 0; i < n_count; ++i) sim.h(i);

    // 2. Eigenstate |1>
    sim.x(n_count);

    // 3. Controlled Rotations
    std::cout << "Applying controlled rotations..." << std::endl;
    for (int i = 0; i < n_count; ++i) {
        double angle = 2.0 * M_PI * target_theta * std::pow(2.0, i);
        sim.cp(i, n_count, angle);
    }

    // 4. Inverse QFT
    std::cout << "Applying Inverse QFT..." << std::endl;
    for (int i = n_count - 1; i >= 0; --i) {
        for (int j = n_count - 1; j > i; --j) {
            double phi = -M_PI / std::pow(2.0, j - i);
            sim.cp(j, i, phi);
        }
        sim.h(i);
    }

    // 5. Analysis
    auto probs = sim.get_probabilities();
    std::vector<double> count_probs(1 << n_count, 0.0);
    for (size_t i = 0; i < probs.size(); ++i) {
        count_probs[i & ((1 << n_count) - 1)] += probs[i].real();
    }

    auto max_it = std::max_element(count_probs.begin(), count_probs.end());
    int best_idx = std::distance(count_probs.begin(), max_it);
    double est = (double)best_idx / (1 << n_count);

    std::cout << std::fixed << std::setprecision(6);
    std::cout << "
Results:" << std::endl;
    std::cout << "  Estimated Theta: " << est << std::endl;
    std::cout << "  Probability:     " << *max_it << std::endl;
    std::cout << "  Absolute Error:  " << std::abs(target_theta - est) << std::endl;

    return 0;
}
