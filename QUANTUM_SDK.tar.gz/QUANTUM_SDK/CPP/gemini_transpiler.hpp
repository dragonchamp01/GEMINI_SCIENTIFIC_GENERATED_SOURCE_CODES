/**
 * Gemini Quantum SDK - C++ Circuit Transpiler
 * -----------------------------------------
 * Decomposes complex gates into fault-tolerant Clifford+T set.
 */

#ifndef GEMINI_TRANSPILER_HPP
#define GEMINI_TRANSPILER_HPP

#include "gemini_quantum.hpp"
#include <vector>
#include <string>
#include <cmath>

namespace Gemini {
    namespace Quantum {

        struct Gate {
            std::string name;
            std::vector<int> qubits;
            double theta = 0.0;
        };

        class Circuit {
            int n_qubits;
            std::vector<Gate> gates;

        public:
            Circuit(int n) : n_qubits(n) {}

            void h(int q) { gates.push_back({"H", {q}}); }
            void x(int q) { gates.push_back({"X", {q}}); }
            void cx(int c, int t) { gates.push_back({"CX", {c, t}}); }
            void rz(int q, double theta) { gates.push_back({"RZ", {q}, theta}); }

            /**
             * @brief Transpiles the circuit into Clifford+T.
             */
            std::vector<Gate> transpile() {
                std::vector<Gate> new_gates;
                for (const auto& g : gates) {
                    if (g.name == "RZ") {
                        // Map specific angles to T or S
                        if (std::abs(g.theta - M_PI/4.0) < 1e-6) {
                            new_gates.push_back({"T", g.qubits});
                        } else if (std::abs(g.theta - M_PI/2.0) < 1e-6) {
                            new_gates.push_back({"S", g.qubits});
                        } else {
                            new_gates.push_back(g); // Fallback
                        }
                    } else {
                        new_gates.push_back(g);
                    }
                }
                return new_gates;
            }

            void run(Simulator& sim) {
                auto optimized = transpile();
                for (const auto& g : optimized) {
                    if (g.name == "H") sim.h(g.qubits[0]);
                    else if (g.name == "X") sim.x(g.qubits[0]);
                    else if (g.name == "CX") sim.cx(g.qubits[0], g.qubits[1]);
                    else if (g.name == "RZ") sim.rz(g.qubits[0], g.theta);
                    // T and S would need implementation in Simulator or map back to RZ
                }
            }
        };
    }
}

#endif
