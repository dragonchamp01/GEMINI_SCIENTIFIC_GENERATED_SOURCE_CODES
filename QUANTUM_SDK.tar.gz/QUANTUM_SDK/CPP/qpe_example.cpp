/**
 * [Alpha Quantum SDK]
 * Topic: Quantum Phase Estimation (QPE)
 * Purpose: Estimating the phase theta of a unitary U such that U|psi> = exp(2*pi*i*theta)|psi>.
 * Example: U = PhaseGate(phi), where phi = 2*pi*0.125 (theta = 0.125 = 1/8).
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace Gemini::Quantum;

// Inverse QFT function for C++
void apply_iqft(Simulator& sim, int start_qubit, int n_qubits) {
    for (int i = start_qubit + n_qubits - 1; i >= start_qubit; --i) {
        for (int j = start_qubit + n_qubits - 1; j > i; --j) {
            double phi = -M_PI / std::pow(2.0, j - i);
            sim.cp(j, i, phi);
        }
        sim.h(i);
    }
}

int main() {
    // 3 counting qubits (bits 0,1,2) + 1 target qubit (bit 3)
    int n_count = 3;
    int total = n_count + 1;
    Simulator sim(total);

    std::cout << "--- Quantum Phase Estimation (C++) ---" << std::endl;
    std::cout << "Target: Estimate theta = 0.125 (1/8)" << std::endl;

    // 1. Prepare superposition on counting qubits
    for (int i = 0; i < n_count; ++i) sim.h(i);

    // 2. Prepare eigenstate |1> on target qubit
    sim.x(n_count);

    // 3. Controlled-U operations
    // U = Phase(2*pi*theta)
    // Here we apply controlled-U^(2^j) manually
    double theta = 0.125;
    for (int i = 0; i < n_count; ++i) {
        double total_phi = 2.0 * M_PI * theta * std::pow(2.0, i);
        sim.cp(i, n_count, total_phi);
    }

    // 4. Apply Inverse QFT on counting register
    apply_iqft(sim, 0, n_count);

    std::cout << "
Results (Counting Register Probabilities):" << std::endl;
    auto probs = sim.get_probabilities();
    
    // Marginalize over target qubit
    std::vector<double> count_probs(1 << n_count, 0.0);
    for (size_t i = 0; i < probs.size(); ++i) {
        count_probs[i & ((1 << n_count) - 1)] += probs[i].real();
    }

    std::cout << std::fixed << std::setprecision(3);
    for (int i = 0; i < (1 << n_count); ++i) {
        if (count_probs[i] > 0.01) {
            double estimated_theta = (double)i / (1 << n_count);
            std::cout << "Index " << i << ": Estimated Theta = " << estimated_theta 
                      << ", Probability = " << count_probs[i] << std::endl;
        }
    }

    return 0;
}
