/**
 * [Alpha Quantum SDK]
 * Topic: Surface Code Syndrome Measurement (C++)
 * Purpose: Simulating a d=3 rotated surface code cycle (17 qubits).
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <vector>
#include <bitset>

using namespace Gemini::Quantum;

class SurfaceCode {
    int d;
public:
    SurfaceCode(int dist) : d(dist) {}

    void run_cycle(const std::vector<int>& error_indices) {
        int n_data = d * d;
        int n_ancilla = d * d - 1;
        Simulator sim(n_data + n_ancilla);

        // 1. Inject Errors
        for (int idx : error_indices) sim.x(idx);

        // 2. X-Stabilizer Cycles (Simplified Connections)
        for (int anc = 9; anc < 13; ++anc) sim.h(anc);
        
        // Mock connections for X-parity
        sim.cx(9, 0); sim.cx(9, 1); sim.cx(9, 3); sim.cx(9, 4);
        sim.cx(10, 1); sim.cx(10, 2); sim.cx(10, 4); sim.cx(10, 5);
        sim.cx(11, 3); sim.cx(11, 4); sim.cx(11, 6); sim.cx(11, 7);
        sim.cx(12, 4); sim.cx(12, 5); sim.cx(12, 7); sim.cx(12, 8);

        for (int anc = 9; anc < 13; ++anc) sim.h(anc);

        // 3. Z-Stabilizer Cycles
        sim.cx(0, 13); sim.cx(1, 13); sim.cx(3, 13); sim.cx(4, 13);
        sim.cx(1, 14); sim.cx(2, 14); sim.cx(4, 14); sim.cx(5, 14);
        sim.cx(3, 15); sim.cx(4, 15); sim.cx(6, 15); sim.cx(7, 15);
        sim.cx(4, 16); sim.cx(5, 16); sim.cx(7, 16); sim.cx(8, 16);

        std::cout << "--- Surface Code Syndrome Extraction Cycle (C++) ---" << std::endl;
        std::cout << "Data Qubits: 9, Ancilla Qubits: 8" << std::endl;
        
        // In large scale simulations, we would only measure ancillas
        int result = sim.measure();
        std::cout << "Measured Outcome (Binary): " << std::bitset<17>(result) << std::endl;
        
        // Extract syndrome (bits 9 to 16)
        int syndrome = (result >> 9) & 0xFF;
        std::cout << "Extracted Syndrome (Hex): 0x" << std::hex << syndrome << std::dec << std::endl;
    }
};

int main() {
    SurfaceCode sc(3);
    
    // Inject error on center data qubit (index 4)
    std::cout << "Injecting Pauli-X error on Data Qubit 4..." << std::endl;
    sc.run_cycle({4});

    return 0;
}
