/**
 * [Alpha Quantum SDK]
 * Topic: Quantum Fourier Transform (QFT) in C++
 * Purpose: Simulating QFT using the high-performance Simulator core.
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <cmath>
#include <iomanip>

using namespace Gemini::Quantum;

void apply_qft(Simulator& sim, int n_qubits) {
    for (int i = n_qubits - 1; i >= 0; --i) {
        sim.h(i);
        for (int j = 0; j < i; ++j) {
            double phi = M_PI / std::pow(2.0, i - j);
            sim.cp(j, i, phi);
        }
    }
}

int main() {
    int n = 3;
    Simulator sim(n);

    std::cout << "--- Initial State |000> ---" << std::endl;
    sim.print_state();

    std::cout << "
Applying 3-qubit QFT..." << std::endl;
    apply_qft(sim, n);

    std::cout << "
--- QFT State Result ---" << std::endl;
    sim.print_state();

    auto probs = sim.get_probabilities();
    std::cout << std::fixed << std::setprecision(4);
    std::cout << "
All Probabilities (Expected: " << 1.0/std::pow(2, n) << "):" << std::endl;
    for (size_t i = 0; i < probs.size(); ++i) {
        std::cout << "P(| " << i << " >) = " << probs[i].real() << std::endl;
    }

    return 0;
}
