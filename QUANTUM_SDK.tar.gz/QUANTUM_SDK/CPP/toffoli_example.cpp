/**
 * [Alpha Quantum SDK]
 * Topic: Toffoli (CCX) Gate Verification (C++)
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <cassert>

using namespace Gemini::Quantum;

void verify_toffoli() {
    std::cout << "--- 3-Qubit CCX (Toffoli) Gate Verification ---" << std::endl;

    // Test Case: Both controls are 1, target is 0 -> target should become 1
    Simulator sim(3);
    
    // Set c0=1, c1=1, t=0 (|011>)
    sim.x(0);
    sim.x(1);
    
    std::cout << "Initial state (|011>):" << std::endl;
    sim.print_state();

    // Apply CCX(0, 1, 2) -> target bit 2 is flipped
    sim.ccx(0, 1, 2);

    std::cout << "
After CCX(0, 1, 2) (|111>):" << std::endl;
    sim.print_state();

    auto probs = sim.get_probabilities();
    // Index 7 is |111> (bit2=1, bit1=1, bit0=1)
    if (probs[7].real() > 0.99) {
        std::cout << "
SUCCESS: CCX(0,1,2) flipped target bit from 0 to 1." << std::endl;
    } else {
        std::cerr << "
FAILURE: CCX(0,1,2) did not flip target bit." << std::endl;
    }
}

int main() {
    verify_toffoli();
    return 0;
}
