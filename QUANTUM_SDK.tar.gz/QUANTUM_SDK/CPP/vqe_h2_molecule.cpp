/**
 * [Alpha Quantum SDK - Quantum Chemistry]
 * Topic: VQE Molecular Model for H2 (C++)
 * Purpose: Finding the ground state energy of H2 using the C++ Simulator core.
 * Hamiltonian: Jordan-Wigner mapped H2 at 0.75A.
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <numeric>

using namespace Gemini::Quantum;

class H2VQE {
    double g0 = -0.8126, g1 = 0.1712, g2 = 0.1712, g3 = 0.1205, g4 = 0.0453, g5 = 0.0453;

public:
    double compute_expectation(const std::vector<double>& theta) {
        Simulator sim(2);
        sim.x(0);
        sim.ry(0, theta[0]);
        sim.ry(1, theta[1]);
        sim.cx(0, 1);
        sim.ry(0, theta[2]);

        const auto& psi = sim.get_state();
        
        // H = g0*II + g1*ZI + g2*IZ + g3*ZZ + g4*XX + g5*YY
        // II is identity
        // ZI: q0 is Z, q1 is I. In basis |00>,|01>,|10>,|11>: diag(1, 1, -1, -1)
        // IZ: diag(1, -1, 1, -1)
        // ZZ: diag(1, -1, -1, 1)
        
        double exp_val = g0; // <II> = 1
        
        // <ZI>
        exp_val += g1 * (std::norm(psi[0]) + std::norm(psi[1]) - std::norm(psi[2]) - std::norm(psi[3]));
        // <IZ>
        exp_val += g2 * (std::norm(psi[0]) - std::norm(psi[1]) + std::norm(psi[2]) - std::norm(psi[3]));
        // <ZZ>
        exp_val += g3 * (std::norm(psi[0]) - std::norm(psi[1]) - std::norm(psi[2]) + std::norm(psi[3]));
        
        // XX: |00><->|11|, |01><->|10|
        // <psi|XX|psi> = psi0* psi3 + psi1* psi2 + psi2* psi1 + psi3* psi0
        exp_val += g4 * (std::conj(psi[0])*psi[3] + std::conj(psi[1])*psi[2] + std::conj(psi[2])*psi[1] + std::conj(psi[3])*psi[0]).real();
        
        // YY: |00><->-|11|, |01><->|10| ... complex
        exp_val += g5 * (-(std::conj(psi[0])*psi[3]) + std::conj(psi[1])*psi[2] + std::conj(psi[2])*psi[1] - (std::conj(psi[3])*psi[0])).real();

        return exp_val;
    }

    void solve() {
        std::vector<double> best_theta = {0, 0, 0};
        double min_energy = compute_expectation(best_theta);
        
        std::mt19937 gen(42);
        std::uniform_real_distribution<> dis(-M_PI, M_PI);

        std::cout << "Starting VQE Optimization (Random Search)..." << std::endl;
        for (int i = 0; i < 5000; ++i) {
            std::vector<double> trial = {dis(gen), dis(gen), dis(gen)};
            double energy = compute_expectation(trial);
            if (energy < min_energy) {
                min_energy = energy;
                best_theta = trial;
            }
        }

        std::cout << "Final Results:" << std::endl;
        std::cout << "  Min Energy: " << min_energy << " Hartree" << std::endl;
        std::cout << "  Exact:      -1.137 Hartree (approx)" << std::endl;
    }
};

int main() {
    H2VQE vqe;
    vqe.solve();
    return 0;
}
