/**
 * [Alpha Quantum SDK - Electromagnetics]
 * Topic: 1D Maxwell Equations (FDTD Method)
 * 
 * Simulates E-field and H-field coupling over time.
 * Equations: dE/dt = -1/eps * dH/dx , dH/dt = -1/mu * dE/dx
 */

#include <iostream>
#include <vector>
#include <cmath>

const int SIZE = 200;
const int STEPS = 500;

int main() {
    std::vector<double> ez(SIZE, 0.0);
    std::vector<double> hy(SIZE, 0.0);
    double imp0 = 377.0; // Impedance of free space

    std::cout << "Simulating Electromagnetic Wave Propagation (FDTD)..." << std::endl;

    for (int t = 0; t < STEPS; ++t) {
        // 1. Update Magnetic Field H
        for (int i = 0; i < SIZE - 1; ++i) {
            hy[i] = hy[i] + (ez[i + 1] - ez[i]) / imp0;
        }

        // 2. Update Electric Field E
        for (int i = 1; i < SIZE; ++i) {
            ez[i] = ez[i] + (hy[i] - hy[i - 1]) * imp0;
        }

        // 3. Source (Gaussian Pulse)
        ez[0] = std::exp(-(pow(t - 30.0, 2) / 100.0));

        if (t % 100 == 0) {
            std::cout << "t=" << t << " | E-field at center: " << ez[SIZE/2] << std::endl;
        }
    }

    std::cout << "FDTD Simulation Complete." << std::endl;
    return 0;
}
