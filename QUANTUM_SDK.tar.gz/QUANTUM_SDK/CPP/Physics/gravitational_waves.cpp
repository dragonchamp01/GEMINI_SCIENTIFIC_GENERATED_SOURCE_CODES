/**
 * [Alpha Quantum SDK - Numerical Relativity]
 * Topic: Gravitational Waveform (TaylorT4 Approximation)
 * 
 * Computes the time-domain strain h(t) for a compact binary inspiral.
 */

#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

class GravitationalWaveSim {
    double m1, m2; // Masses in solar masses
    double dist;   // Distance in Megaparsecs
public:
    GravitationalWaveSim(double mass1, double mass2, double d) : m1(mass1), m2(mass2), dist(d) {}

    // Simplified PN amplitude: h ~ (M/r) * (v^2)
    double calculate_strain(double time, double frequency) {
        double total_m = m1 + m2;
        double chirp_mass = std::pow(m1 * m2, 0.6) / std::pow(total_m, 0.2);
        
        // Phase phi(t) logic for chirping signal
        double phase = 2.0 * M_PI * frequency * time;
        double amplitude = (4.0 / dist) * std::pow(chirp_mass, 5.0/3.0) * std::pow(M_PI * frequency, 2.0/3.0);
        
        return amplitude * std::cos(phase);
    }
};

int main() {
    GravitationalWaveSim binary(30.0, 30.0, 410.0); // GW150914-like parameters
    std::cout << "Simulating GW Strain during Inspiral:" << std::endl;
    
    for (double t = 0; t < 0.05; t += 0.005) {
        double f = 100.0 + t * 1000.0; // Frequency chirp
        std::cout << "t: " << t << "s | Frequency: " << f << "Hz | h(t): " << binary.calculate_strain(t, f) << std::endl;
    }
    return 0;
}
