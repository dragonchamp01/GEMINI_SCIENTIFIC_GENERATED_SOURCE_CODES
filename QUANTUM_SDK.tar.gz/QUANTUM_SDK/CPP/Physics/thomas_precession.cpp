/**
 * [Alpha Quantum SDK - Relativity]
 * Topic: Thomas Precession Calculation
 * 
 * Computes the angular velocity of Thomas Precession for a 
 * particle moving in a circular orbit.
 */

#include <iostream>
#include <cmath>
#include <iomanip>

const double C = 299792458.0;

class ThomasPrecession {
public:
    /**
     * @brief Calculates angular frequency omega_T.
     * @param v Velocity of the particle
     * @param a Acceleration
     */
    static double calculate_omega(double v, double a) {
        double gamma = 1.0 / std::sqrt(1.0 - (v * v) / (C * C));
        // omega_T = (gamma^2 / (gamma + 1)) * (v x a) / c^2
        return (gamma * gamma / (gamma + 1.0)) * (v * a) / (C * C);
    }
};

int main() {
    double v_ratio = 0.1; // 10% speed of light
    double velocity = v_ratio * C;
    double radius = 1e-10; // Atomic scale
    double acceleration = (velocity * velocity) / radius;

    double omega_t = ThomasPrecession::calculate_omega(velocity, acceleration);

    std::cout << std::fixed << std::setprecision(4);
    std::cout << "Thomas Precession Simulation" << std::endl;
    std::cout << "Velocity: " << v_ratio << " c" << std::endl;
    std::cout << "Omega_T:  " << omega_t << " rad/s" << std::endl;

    return 0;
}
