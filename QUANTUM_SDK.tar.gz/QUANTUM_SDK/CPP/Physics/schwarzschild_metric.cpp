/**
 * [Alpha Quantum SDK - General Relativity]
 * Topic: Schwarzschild Metric Solver
 * Purpose: Spacetime metric components around a static mass.
 */

#include <iostream>
#include <cmath>
#include <iomanip>
#include <map>
#include <string>

class SchwarzschildSolver {
    double M; // Mass
    double rs; // Schwarzschild Radius
public:
    SchwarzschildSolver(double mass) : M(base_mass(mass)), rs(2.0 * M) {}

    static double base_mass(double m) { return m; }

    void calculate_at(double r, double theta) {
        if (r <= rs) {
            std::cout << "Coordinate singularity or inside horizon." << std::endl;
            return;
        }

        double g_tt = -(1.0 - rs / r);
        double g_rr = 1.0 / (1.0 - rs / r);
        double g_th = std::pow(r, 2.0);
        double g_ph = std::pow(r, 2.0) * std::pow(std::sin(theta), 2.0);

        std::cout << std::fixed << std::setprecision(4);
        std::cout << "--- Schwarzschild Metric (r=" << r << ", theta=" << theta << ") ---" << std::endl;
        std::cout << "  g_tt: " << g_tt << std::endl;
        std::cout << "  g_rr: " << g_rr << std::endl;
        std::cout << "  g_th: " << g_th << std::endl;
        std::cout << "  g_ph: " << g_ph << std::endl;
    }
};

int main() {
    double mass = 1.0;
    SchwarzschildSolver solver(mass);

    double test_r = 6.0; // 3 * rs
    double test_theta = M_PI / 2.0;

    solver.calculate_at(test_r, test_theta);

    return 0;
}
