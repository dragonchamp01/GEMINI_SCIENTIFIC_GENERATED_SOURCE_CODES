/**
 * [Alpha Quantum SDK - Semi-classical Physics]
 * Topic: WKB Approximation for Tunneling
 * 
 * Computes the transmission coefficient T through a barrier V(x).
 * T approx exp(-2 * integral |p(x)|/hbar dx)
 */

#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

class WKBTunneling {
    double m; // Particle mass
public:
    WKBTunneling(double mass) : m(mass) {}

    // Example barrier: Rectangular V(x) = V0 for [0, L]
    double calculate_transmission(double E, double V0, double L) {
        if (E >= V0) return 1.0; // Over-the-barrier (classical)

        // Kappa = sqrt(2m(V-E))/hbar
        double kappa = std::sqrt(2.0 * m * (V0 - E));
        
        // Gamow Factor G = 2 * integral(kappa dx)
        double G = 2.0 * kappa * L;
        
        return std::exp(-G);
    }
};

int main() {
    WKBTunneling sim(1.0); // m=1
    double energy = 2.0;
    double barrier_height = 5.0;
    double width = 1.5;

    std::cout << "WKB Tunneling Approximation Analysis" << std::endl;
    std::cout << "------------------------------------" << std::endl;
    std::cout << "Energy: " << energy << " | Barrier: " << barrier_height << " | Width: " << width << std::endl;

    double T = sim.calculate_transmission(energy, barrier_height, width);

    std::cout << std::scientific << std::setprecision(6);
    std::cout << "Transmission Coefficient T: " << T << std::endl;
    std::cout << "This represents the quantum tunneling probability." << std::endl;

    return 0;
}
