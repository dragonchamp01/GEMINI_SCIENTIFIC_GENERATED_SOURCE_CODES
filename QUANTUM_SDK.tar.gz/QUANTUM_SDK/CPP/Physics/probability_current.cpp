/**
 * @file probability_current.cpp
 * @brief Quantum Mechanics: Probability Current Density (j).
 * 
 * Computes j = (hbar/m) * Im( psi* * grad(psi) )
 * This script demonstrates the current for a plane wave psi = exp(ikx).
 */

#include <iostream>
#include <complex>
#include <cmath>
#include <iomanip>

using namespace std;
typedef complex<double> dcomp;

class QuantumFluids {
    double hbar, m;
public:
    QuantumFluids() : hbar(1.0), m(1.0) {}

    /**
     * @brief Calculates probability current in 1D.
     */
    double calculate_j(dcomp psi, dcomp d_psi) {
        // j = (hbar/m) * Im( conj(psi) * d_psi )
        return (hbar / m) * (conj(psi) * d_psi).imag();
    }
};

int main() {
    QuantumFluids qf;
    // Plane wave: psi(x) = exp(i * k * x) -> d_psi = i * k * psi
    double k = 2.0;
    double x = 0.5;
    dcomp psi = exp(dcomp(0, k * x));
    dcomp d_psi = dcomp(0, k) * psi;

    double j = qf.calculate_j(psi, d_psi);

    cout << "Probability Current Analysis" << endl;
    cout << "----------------------------" << endl;
    cout << "Wave number k: " << k << endl;
    cout << "Current j:     " << j << " (Expected: k/m = 2.0)" << endl;

    return 0;
}
