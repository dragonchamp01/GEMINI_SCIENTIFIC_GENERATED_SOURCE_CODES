/**
 * @file variational_numerical.cpp
 * @brief Quantum Mechanics: Numerical Variational Method.
 * 
 * Minimizes E(alpha) = <psi_alpha | H | psi_alpha> / <psi_alpha | psi_alpha>
 * for a trial wavefunction psi = exp(-alpha * x^2).
 */

#include <iostream>
#include <cmath>
#include <iomanip>
#include <functional>

// Simpson's Rule for Expectation Value Integrals
double integrate(std::function<double(double)> f, double a, double b, int n = 1000) {
    double h = (b - a) / n;
    double sum = f(a) + f(b);
    for (int i = 1; i < n; i++) {
        double x = a + i * h;
        sum += (i % 2 == 0 ? 2 : 4) * f(x);
    }
    return h * sum / 3.0;
}

int main() {
    // Hamiltonian for Harmonic Oscillator: H = -0.5 * d2/dx2 + 0.5 * x^2
    // Trial psi = exp(-alpha * x^2)
    
    auto compute_energy = [](double alpha) {
        auto psi_sq = [alpha](double x) { return std::exp(-2.0 * alpha * x * x); };
        auto psi_H_psi = [alpha](double x) {
            double p = std::exp(-alpha * x * x);
            // H*psi = [-0.5 * (4*alpha^2*x^2 - 2*alpha) + 0.5*x^2] * psi
            double kin = -0.5 * (4.0 * alpha * alpha * x * x - 2.0 * alpha) * p;
            double pot = 0.5 * x * x * p;
            return p * (kin + pot);
        };

        double norm = integrate(psi_sq, -5.0, 5.0);
        double expect_h = integrate(psi_H_psi, -5.0, 5.0);
        return expect_h / norm;
    };

    std::cout << "Variational Energy Minimization (SHO Ground State)" << std::endl;
    std::cout << "Alpha | Energy (E_trial)" << std::endl;
    std::cout << "------|----------------" << std::endl;

    for (double a = 0.3; a <= 0.7; a += 0.05) {
        std::cout << std::fixed << std::setprecision(2) << a << "  | " 
                  << std::setprecision(6) << compute_energy(a) << std::endl;
    }

    std::cout << "
Minimum expected at alpha = 0.5, E = 0.5." << std::endl;
    return 0;
}
