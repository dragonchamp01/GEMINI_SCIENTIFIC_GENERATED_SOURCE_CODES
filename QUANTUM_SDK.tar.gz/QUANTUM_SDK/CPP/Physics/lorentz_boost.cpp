/**
 * @file lorentz_boost.cpp
 * @brief Special Relativity: Lorentz Transformation of 4-vectors.
 * 
 * Transforms (t, x, y, z) from S frame to S' frame moving with velocity v.
 */

#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

struct FourVector {
    double t, x, y, z;
};

class RelativityTools {
public:
    /**
     * @brief Performs boost along X-axis.
     * @param v Velocity relative to speed of light (beta = v/c)
     */
    static FourVector boost_x(const FourVector& v4, double beta) {
        double gamma = 1.0 / std::sqrt(1.0 - beta * beta);
        FourVector res;
        res.t = gamma * (v4.t - beta * v4.x);
        res.x = gamma * (v4.x - beta * v4.t);
        res.y = v4.y;
        res.z = v4.z;
        return res;
    }
};

int main() {
    FourVector event = {1.0, 0.0, 0.0, 0.0}; // Event at t=1s, x=0 in S
    double v_c = 0.8; // 80% speed of light

    std::cout << "Lorentz Boost along X-axis (beta=0.8)" << std::endl;
    std::cout << "Initial (S):  t=" << event.t << ", x=" << event.x << std::endl;

    FourVector boosted = RelativityTools::boost_x(event, v_c);

    std::cout << std::fixed << std::setprecision(4);
    std::cout << "Boosted (S'): t=" << boosted.t << ", x=" << boosted.x << std::endl;
    std::cout << "Time Dilation confirmed: t' = gamma * t" << std::endl;

    return 0;
}
