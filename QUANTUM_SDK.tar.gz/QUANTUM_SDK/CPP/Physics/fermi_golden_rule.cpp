/**
 * [Alpha Quantum SDK - Quantum Dynamics]
 * Topic: Fermi's Golden Rule
 * 
 * Computes the transition rate Gamma = (2pi/hbar) * |<f|V|i>|^2 * rho(Ef)
 */

#include <iostream>
#include <cmath>
#include <iomanip>

class TransitionSimulator {
    double hbar;
public:
    TransitionSimulator() : hbar(1.0) {} // Atomic units

    /**
     * @brief Calculates transition rate.
     * @param matrix_element <f|V|i>
     * @param density_of_states rho(E)
     */
    double calculate_rate(double matrix_element, double density_of_states) {
        return (2.0 * M_PI / hbar) * std::pow(matrix_element, 2) * density_of_states;
    }
};

int main() {
    TransitionSimulator sim;
    double V_fi = 0.05; // Interaction strength
    double rho_E = 100.0; // High density of final states

    double rate = sim.calculate_rate(V_fi, rho_E);

    std::cout << std::fixed << std::setprecision(6);
    std::cout << "Fermi's Golden Rule Transition Rate Analysis" << std::endl;
    std::cout << "Matrix Element: " << V_fi << " | Density of States: " << rho_E << std::endl;
    std::cout << "Transition Rate (Gamma): " << rate << " s^-1" << std::endl;

    return 0;
}
