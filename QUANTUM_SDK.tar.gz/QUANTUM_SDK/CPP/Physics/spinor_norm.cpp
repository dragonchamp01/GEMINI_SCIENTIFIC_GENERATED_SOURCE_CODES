/**
 * @file spinor_algebra.cpp
 * @brief Relativity: Spinor Norm and Bilinear calculation.
 * 
 * Computes the Dirac Adjoint and the scalar norm of a 4-component spinor.
 * Norm = psi_dag * gamma_0 * psi
 */

#include <iostream>
#include <vector>
#include <complex>
#include <iomanip>

using Complex = std::complex<double>;

class Spinor {
    std::vector<Complex> components;
public:
    Spinor(Complex a, Complex b, Complex c, Complex d) : components({a, b, c, d}) {}

    /**
     * @brief Computes the scalar norm (Dirac bilinear).
     */
    double calculate_norm() {
        // Dirac Adjoint psi_bar = psi_dag * gamma_0
        // In standard representation, gamma_0 = diag(1, 1, -1, -1)
        double res = std::norm(components[0]) + std::norm(components[1]) - 
                     std::norm(components[2]) - std::norm(components[3]);
        return res;
    }
};

int main() {
    // A particle-like spinor (rest frame)
    Spinor electron(Complex(1, 0), 0, 0, 0);
    // An anti-particle-like spinor
    Spinor positron(0, 0, Complex(0, 1), 0);

    std::cout << "Spinor Norm Analysis:" << std::endl;
    std::cout << "Electron-like norm: " << electron.calculate_norm() << " (Positive energy)" << std::endl;
    std::cout << "Positron-like norm: " << positron.calculate_norm() << " (Negative energy density)" << std::endl;

    return 0;
}
