/**
 * [Alpha Quantum SDK]
 * Topic: 3-Qubit Grover Search Algorithm (C++)
 * Target State: |7> (|111>)
 * Purpose: Demonstrating vectorized MCP gates.
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace Gemini::Quantum;

void run_grover_3qubit() {
    int n = 3;
    Simulator sim(n);

    // 1. Superposition
    for (int i = 0; i < n; ++i) sim.h(i);

    // Iterations ~ pi/4 * sqrt(2^n)
    int iterations = 2;

    for (int i = 0; i < iterations; ++i) {
        // 2. Oracle (|111>)
        sim.mcp({0, 1}, 2, M_PI);

        // 3. Diffuser
        for (int q = 0; q < n; ++q) sim.h(q);
        for (int q = 0; q < n; ++q) sim.x(q);
        
        sim.mcp({0, 1}, 2, M_PI);

        for (int q = 0; q < n; ++q) sim.x(q);
        for (int q = 0; q < n; ++q) sim.h(q);
    }

    std::cout << "--- 3-Qubit Grover Search (|111>) [C++] ---" << std::endl;
    auto probs = sim.get_probabilities();
    for (int i = 0; i < (1 << n); ++i) {
        std::cout << "| " << i << " > : " << std::fixed << std::setprecision(4) << probs[i].real() << std::endl;
    }

    if (probs[7].real() > 0.9) {
        std::cout << "
SUCCESS: Target state |7> found!" << std::endl;
    }
}

int main() {
    run_grover_3qubit();
    return 0;
}
