/**
 * [Alpha Quantum SDK - Mathematics]
 * Topic: Complex Residue Calculation
 * 
 * Numerically estimates the residue of a function f(z) at a pole z0
 * using a small circular contour integration.
 * Res(f, z0) = (1 / 2pi*i) * Integral( f(z) dz )
 */

#include <iostream>
#include <complex>
#include <vector>
#include <cmath>

using namespace std;

typedef complex<double> Complex;

Complex residue(std::function<Complex(Complex)> f, Complex z0, double r = 1e-4) {
    const int N = 1000;
    Complex sum(0, 0);
    double dt = 2.0 * M_PI / N;

    for (int i = 0; i < N; ++i) {
        double theta = i * dt;
        Complex z = z0 + r * Complex(cos(theta), sin(theta));
        Complex dz = r * Complex(-sin(theta), cos(theta)) * dt;
        sum += f(z) * dz;
    }

    return sum / (2.0 * M_PI * Complex(0, 1));
}

int main() {
    // Example: f(z) = 1 / (z - 1)
    // Pole at z=1, expected residue = 1
    auto f = [](Complex z) { return 1.0 / (z - 1.0); };
    Complex z0(1, 0);

    Complex res = residue(f, z0);

    cout << "Residue of 1/(z-1) at z=1: " << res.real() << " + " << res.imag() << "i" << endl;
    return 0;
}
