/**
 * @file tensor_product.cpp
 * @brief Linear Algebra: Kronecker (Tensor) Product of Operators.
 * 
 * Computes C = A (x) B. Essential for composite quantum systems.
 */

#include <iostream>
#include <vector>
#include <iomanip>

using Matrix = std::vector<std::vector<double>>;

Matrix tensor_product(const Matrix& A, const Matrix& B) {
    int ar = A.size();
    int ac = A[0].size();
    int br = B.size();
    int bc = B[0].size();
    
    Matrix C(ar * br, std::vector<double>(ac * bc, 0.0));

    for (int i = 0; i < ar; i++) {
        for (int j = 0; j < ac; j++) {
            for (int k = 0; k < br; k++) {
                for (int l = 0; l < bc; l++) {
                    C[i * br + k][j * ac + l] = A[i][j] * B[k][l];
                }
            }
        }
    }
    return C;
}

int main() {
    // Pauli X and I matrices
    Matrix X = {{0, 1}, {1, 0}};
    Matrix I = {{1, 0}, {0, 1}};

    std::cout << "Computing IX = Identity (x) Pauli-X..." << std::endl;
    Matrix IX = tensor_product(I, X);

    for (const auto& row : IX) {
        for (double val : row) std::cout << val << " ";
        std::cout << std::endl;
    }

    return 0;
}
