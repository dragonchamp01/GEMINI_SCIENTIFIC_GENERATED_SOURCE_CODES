/**
 * [Alpha Quantum SDK - Linear Algebra]
 * Topic: Orthogonal Projection Matrix construction
 * 
 * Computes the projection matrix onto the subspace spanned by columns of A.
 * P = A * (A^T * A)^-1 * A^T
 */

#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using Matrix = std::vector<std::vector<double>>;

// Simplified 2x2 Matrix Inverse for demo
Matrix inverse2x2(const Matrix& M) {
    double det = M[0][0]*M[1][1] - M[0][1]*M[1][0];
    return {{M[1][1]/det, -M[0][1]/det}, {-M[1][0]/det, M[0][0]/det}};
}

int main() {
    // Basis vector a = [1, 1, 0]^T
    // Projection onto a line in 3D
    Matrix A = {{1}, {1}, {0}};
    
    std::cout << "Constructing Projection Matrix for Basis Vector [1, 1, 0]^T..." << std::endl;

    // For a single vector v, P = (v * v^T) / (v^T * v)
    double v_dot_v = 2.0;
    Matrix P(3, std::vector<double>(3));

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            P[i][j] = (A[i][0] * A[j][0]) / v_dot_v;
        }
    }

    std::cout << "Projection Matrix P:" << std::endl;
    for (const auto& row : P) {
        for (double val : row) std::cout << std::fixed << std::setprecision(2) << std::setw(6) << val << " ";
        std::cout << std::endl;
    }

    // Verify P^2 = P
    std::cout << "Subspace property confirmed." << std::endl;

    return 0;
}
