/**
 * @file change_basis.cpp
 * @brief Linear Algebra: Change of Basis Transformation.
 * 
 * Computes [v]_B' = P^-1 * [v]_B
 * where P is the transition matrix from B to B'.
 */

#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using Vector = std::vector<double>;
using Matrix = std::vector<std::vector<double>>;

// Basic 2x2 matrix inversion for the SDK utility
Matrix invert2x2(const Matrix& P) {
    double det = P[0][0]*P[1][1] - P[0][1]*P[1][0];
    if (std::abs(det) < 1e-12) return P; // Should throw exception
    return {{P[1][1]/det, -P[0][1]/det}, {-P[1][0]/det, P[0][0]/det}};
}

Vector mat_vec_mul(const Matrix& A, const Vector& v) {
    Vector res(A.size(), 0.0);
    for (size_t i = 0; i < A.size(); i++)
        for (size_t j = 0; j < v.size(); j++)
            res[i] += A[i][j] * v[j];
    return res;
}

int main() {
    // Basis B: Standard {(1,0), (0,1)}
    // Basis B': {(1,1), (2,1)}
    // Transition Matrix P (Columns are vectors of B' in terms of B)
    Matrix P = {{1, 2}, {1, 1}};
    
    // Vector v in standard basis
    Vector v_B = {3, 2};

    std::cout << "Change of Basis: [v]_B -> [v]_B'" << std::endl;
    std::cout << "[v]_B: [ " << v_B[0] << " " << v_B[1] << " ]" << std::endl;

    Matrix P_inv = invert2x2(P);
    Vector v_Bprime = mat_vec_mul(P_inv, v_B);

    std::cout << std::fixed << std::setprecision(4);
    std::cout << "[v]_B': [ " << v_Bprime[0] << " " << v_Bprime[1] << " ]" << std::endl;
    
    // Verification: v_B = 1.0 * (1,1) + 1.0 * (2,1) = (1+2, 1+1) = (3, 2). Correct.
    return 0;
}
