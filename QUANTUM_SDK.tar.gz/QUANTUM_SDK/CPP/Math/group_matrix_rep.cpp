/**
 * [Alpha Quantum SDK - Representation Theory]
 * Topic: Group Matrix Representation
 * 
 * Constructs matrices for rotation group SO(2) and Cyclic group Z_n.
 */

#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using Matrix2x2 = std::vector<std::vector<double>>;

/**
 * @brief Returns SO(2) rotation matrix.
 */
Matrix2x2 get_rotation_matrix(double theta) {
    return {
        {std::cos(theta), -std::sin(theta)},
        {std::sin(theta),  std::cos(theta)}
    };
}

int main() {
    double angle = M_PI / 4.0; // 45 deg
    std::cout << "SO(2) Group Matrix Representation (theta = 45 deg):" << std::endl;
    
    Matrix2x2 R = get_rotation_matrix(angle);

    for (int i = 0; i < 2; ++i) {
        for (int j = 0; j < 2; ++j) {
            std::cout << std::fixed << std::setprecision(4) << std::setw(10) << R[i][j] << " ";
        }
        std::cout << std::endl;
    }

    return 0;
}
