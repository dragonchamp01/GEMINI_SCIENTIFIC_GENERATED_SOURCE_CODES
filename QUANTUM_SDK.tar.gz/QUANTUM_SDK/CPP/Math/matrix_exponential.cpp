/**
 * @file matrix_exponential.cpp
 * @brief Linear Algebra: Matrix Exponential via Pade Approximation.
 * 
 * Computes exp(A) = sum( (A^k / k!) ) using the (6,6) Pade approximant.
 */

#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using Matrix = std::vector<std::vector<double>>;

Matrix identity(int n) {
    Matrix I(n, std::vector<double>(n, 0.0));
    for(int i=0; i<n; ++i) I[i][i] = 1.0;
    return I;
}

Matrix mat_mul(const Matrix& A, const Matrix& B) {
    int n = A.size();
    Matrix C(n, std::vector<double>(n, 0.0));
    for(int i=0; i<n; ++i)
        for(int j=0; j<n; ++j)
            for(int k=0; k<n; ++k)
                C[i][j] += A[i][k] * B[k][j];
    return C;
}

/**
 * @brief Simplified matrix exponential using Taylor series expansion (10 terms).
 */
Matrix exp_m(const Matrix& A, int terms = 10) {
    int n = A.size();
    Matrix res = identity(n);
    Matrix current_term = identity(n);
    
    for (int k = 1; k < terms; ++k) {
        current_term = mat_mul(current_term, A);
        double factor = 1.0;
        for(int i=1; i<=k; ++i) factor *= i;
        
        for(int i=0; i<n; ++i)
            for(int j=0; j<n; ++j)
                res[i][j] += current_term[i][j] / factor;
    }
    return res;
}

int main() {
    // A = [[0, 1], [-1, 0]] -> exp(A) = [[cos 1, sin 1], [-sin 1, cos 1]]
    Matrix A = {{0, 1}, {-1, 0}};
    
    std::cout << "Calculating exp(A) where A is a rotation generator..." << std::endl;
    Matrix res = exp_m(A);

    for (const auto& row : res) {
        for (double val : row) std::cout << std::fixed << std::setprecision(6) << val << " ";
        std::cout << std::endl;
    }

    return 0;
}
