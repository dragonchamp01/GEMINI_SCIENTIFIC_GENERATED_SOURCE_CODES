/**
 * @file avl_rotation.cpp
 * @brief Discrete Math: AVL Tree Balance Rotations.
 * 
 * Implements Right Rotate and Left Rotate for self-balancing BSTs.
 */

#include <iostream>
#include <algorithm>

struct Node {
    int key;
    Node *left, *right;
    int height;
    Node(int k) : key(k), left(nullptr), right(nullptr), height(1) {}
};

int height(Node* n) { return n ? n->height : 0; }

/**
 * @brief Right Rotation
 */
Node* rightRotate(Node* y) {
    Node* x = y->left;
    Node* T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = std::max(height(y->left), height(y->right)) + 1;
    x->height = std::max(height(x->left), height(x->right)) + 1;

    return x;
}

/**
 * @brief Left Rotation
 */
Node* leftRotate(Node* x) {
    Node* y = x->right;
    Node* T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = std::max(height(x->left), height(x->right)) + 1;
    y->height = std::max(height(y->left), height(y->right)) + 1;

    return y;
}

int main() {
    std::cout << "AVL Tree Rotation Utility Loaded." << std::endl;
    // Logic for balancing check and rotation trigger
    std::cout << "Ready for O(log N) tree operations." << std::endl;
    return 0;
}
