/**
 * Gemini Quantum SDK - C++ Density Matrix Simulator (Pure STL)
 * -----------------------------------------------------------
 * Supports full density matrix evolution and Kraus operator application.
 */

#ifndef GEMINI_DENSITY_HPP
#define GEMINI_DENSITY_HPP

#include <vector>
#include <complex>
#include <iostream>
#include <cmath>

namespace Gemini {
    namespace Quantum {

        using Complex = std::complex<double>;
        using Matrix = std::vector<std::vector<Complex>>;

        class DensitySimulator {
            int n_qubits;
            int dim;
            Matrix rho;

        public:
            DensitySimulator(int n) : n_qubits(n), dim(1 << n) {
                rho.assign(dim, std::vector<Complex>(dim, 0.0));
                rho[0][0] = 1.0; // Initialize to |0><0|
            }

            static Matrix multiply(const Matrix& A, const Matrix& B) {
                int r = A.size();
                int c = B[0].size();
                int inner = B.size();
                Matrix C(r, std::vector<Complex>(c, 0.0));
                for (int i = 0; i < r; ++i) {
                    for (int k = 0; k < inner; ++k) {
                        Complex temp = A[i][k];
                        for (int j = 0; j < c; ++j) {
                            C[i][j] += temp * B[k][j];
                        }
                    }
                }
                return C;
            }

            static Matrix adjoint(const Matrix& A) {
                int r = A.size();
                int c = A[0].size();
                Matrix B(c, std::vector<Complex>(r));
                for (int i = 0; i < r; ++i) {
                    for (int j = 0; j < c; ++j) {
                        B[j][i] = std::conj(A[i][j]);
                    }
                }
                return B;
            }

            void apply_unitary(const Matrix& U) {
                Matrix U_adj = adjoint(U);
                rho = multiply(U, multiply(rho, U_adj));
            }

            void apply_kraus(const std::vector<Matrix>& KrausOps, int target_qubit) {
                Matrix new_rho(dim, std::vector<Complex>(dim, 0.0));
                for (const auto& Ek : KrausOps) {
                    Matrix full_Ek = expand_operator(Ek, target_qubit);
                    Matrix Ek_adj = adjoint(full_Ek);
                    Matrix term = multiply(full_Ek, multiply(rho, Ek_adj));
                    for (int i = 0; i < dim; ++i) {
                        for (int j = 0; j < dim; ++j) {
                            new_rho[i][j] += term[i][j];
                        }
                    }
                }
                rho = new_rho;
            }

            double get_purity() {
                Complex trace_rho_sq = 0;
                Matrix rho_sq = multiply(rho, rho);
                for (int i = 0; i < dim; ++i) trace_rho_sq += rho_sq[i][i];
                return trace_rho_sq.real();
            }

            const Matrix& get_rho() const { return rho; }

        private:
            Matrix expand_operator(const Matrix& Ek, int target) {
                Matrix full = {{1.0}};
                Matrix I = {{1.0, 0.0}, {0.0, 1.0}};

                for (int i = 0; i < n_qubits; ++i) {
                    if (i == target) {
                        full = kronecker_product(full, Ek);
                    } else {
                        full = kronecker_product(full, I);
                    }
                }
                return full;
            }

            Matrix kronecker_product(const Matrix& A, const Matrix& B) {
                int ar = A.size();
                int ac = A[0].size();
                int br = B.size();
                int bc = B[0].size();
                Matrix C(ar * br, std::vector<Complex>(ac * bc));
                for (int i = 0; i < ar; ++i) {
                    for (int j = 0; j < ac; ++j) {
                        for (int k = 0; k < br; ++k) {
                            for (int l = 0; l < bc; ++l) {
                                C[i * br + k][j * bc + l] = A[i][j] * B[k][l];
                            }
                        }
                    }
                }
                return C;
            }
        };

        namespace Noise {
            inline std::vector<Matrix> depolarizing(double p) {
                Matrix I = {{1.0, 0.0}, {0.0, 1.0}};
                Matrix X = {{0.0, 1.0}, {1.0, 0.0}};
                Matrix Y = {{0.0, Complex(0, -1)}, {Complex(0, 1), 0.0}};
                Matrix Z = {{1.0, 0.0}, {0.0, -1.0}};

                double f0 = std::sqrt(1.0 - p);
                double f1 = std::sqrt(p / 3.0);

                auto scale = [](Matrix M, double s) {
                    for (auto& row : M) for (auto& val : row) val *= s;
                    return M;
                };

                return { scale(I, f0), scale(X, f1), scale(Y, f1), scale(Z, f1) };
            }

            inline std::vector<Matrix> amplitude_damping(double gamma) {
                Matrix E0 = {{1.0, 0.0}, {0.0, std::sqrt(1.0 - gamma)}};
                Matrix E1 = {{0.0, std::sqrt(gamma)}, {0.0, 0.0}};
                return { E0, E1 };
            }

            inline std::vector<Matrix> phase_damping(double lambda) {
                Matrix E0 = {{1.0, 0.0}, {0.0, std::sqrt(1.0 - lambda)}};
                Matrix E1 = {{0.0, 0.0}, {0.0, std::sqrt(lambda)}};
                return { E0, E1 };
            }
        }
    }
}

#endif
