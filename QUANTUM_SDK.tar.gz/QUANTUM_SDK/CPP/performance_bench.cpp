/**
 * [Alpha Quantum SDK]
 * Topic: Simulation Performance Benchmark (C++)
 * Purpose: Comparing standard loop vs AVX2 optimized kernels.
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <chrono>
#include <vector>

using namespace Gemini::Quantum;
using namespace std::chrono;

void run_benchmark(int n_qubits, int n_gates) {
    std::cout << "--- Benchmarking " << n_qubits << " Qubits (" << (1 << n_qubits) << " states) ---" << std::endl;
    
    Simulator sim(n_qubits);
    
    auto start = high_resolution_clock::now();
    
    for (int i = 0; i < n_gates; ++i) {
        // Apply H to all qubits multiple times
        for (int q = 0; q < n_qubits; ++q) {
            sim.h(q);
        }
    }
    
    auto end = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(end - start);
    
    std::cout << "Executed " << n_gates * n_qubits << " gates in " << duration.count() << " ms" << std::endl;
    std::cout << "Speed: " << (double)(n_gates * n_qubits) / (duration.count() / 1000.0) << " gates/sec" << std::endl;
}

int main() {
    // Warm up
    run_benchmark(10, 100);
    
    // Large scale test
    // 20 qubits = 1,048,576 states
    run_benchmark(20, 10);
    
    return 0;
}
