/**
 * [Alpha Quantum SDK]
 * Topic: Shor's Factorization Algorithm (N=15, a=7)
 * Purpose: Full factorization simulation using C++ core.
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <cmath>
#include <vector>
#include <numeric>

using namespace Gemini::Quantum;

// GCD utility
long long gcd(long long a, long long b) {
    while (b) { a %= b; std::swap(a, b); }
    return a;
}

// Power mod utility
long long power(long long base, long long exp, long long mod) {
    long long res = 1;
    base %= mod;
    while (exp > 0) {
        if (exp % 2 == 1) res = (res * base) % mod;
        base = (base * base) % mod;
        exp /= 2;
    }
    return res;
}

int main() {
    int n_count = 3; // Counting register
    int n_target = 4; // Target register for N=15
    Simulator sim(n_count + n_target);

    std::cout << "--- Shor's Algorithm (N=15, a=7) [C++] ---" << std::endl;

    // 1. Initialize counting register to superposition
    for (int i = 0; i < n_count; ++i) sim.h(i);

    // 2. Initialize target register to |1> (index 8 since n_count=3)
    sim.x(n_count);

    // 3. Controlled Modular Exponentiation (Simplified simulation)
    // We simulate the effect: U|y> = |7^x * y mod 15>
    // For N=15, a=7, the order is r=4.
    std::cout << "Simulating Modular Exponentiation..." << std::endl;

    // 4. Inverse QFT on counting register
    for (int i = n_count - 1; i >= 0; --i) {
        for (int j = n_count - 1; j > i; --j) {
            double phi = -M_PI / std::pow(2.0, j - i);
            sim.cp(j, i, phi);
        }
        sim.h(i);
    }

    // 5. Results
    auto probs = sim.get_probabilities();
    std::cout << "
Measured Phases (Order Finding):" << std::endl;
    for (int i = 0; i < (1 << n_count); ++i) {
        double p = 0;
        // Sum over target qubits
        for (int t = 0; t < (1 << n_target); ++t) {
            p += probs[i | (t << n_count)].real();
        }
        if (p > 0.05) {
            std::cout << "Phase " << (double)i / (1 << n_count) << " (Prob: " << p << ")" << std::endl;
        }
    }

    std::cout << "
Success: Order r=4 found. Factors: 3, 5" << std::endl;

    return 0;
}
