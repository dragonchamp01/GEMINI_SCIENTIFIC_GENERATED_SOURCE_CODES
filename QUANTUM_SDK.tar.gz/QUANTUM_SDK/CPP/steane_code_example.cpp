/**
 * [Alpha Quantum SDK - QEC]
 * Topic: Steane 7-Qubit Code (C++)
 * Purpose: Protecting a qubit using the [[7, 1, 3]] CSS code.
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <vector>
#include <bitset>

using namespace Gemini::Quantum;

class SteaneCode {
public:
    StateVector encode(int initial_state_idx = 0) {
        Simulator sim(7);

        // 1. Initial State
        if (initial_state_idx == 1) {
            for (int i = 0; i < 7; ++i) sim.x(i);
        }

        // 2. CSS Encoding
        sim.h(4); sim.h(5); sim.h(6);

        // Parity 3
        sim.cx(6, 1); sim.cx(6, 2); sim.cx(6, 3);
        // Parity 2
        sim.cx(5, 0); sim.cx(5, 2); sim.cx(5, 3);
        // Parity 1
        sim.cx(4, 0); sim.cx(4, 1); sim.cx(4, 3);

        return sim.get_probabilities();
    }
};

int main() {
    SteaneCode sc;
    std::cout << "Encoding |0>L using Steane Code (C++)..." << std::endl;
    auto probs = sc.encode(0);

    std::cout << "
Non-zero amplitude states (Hamming codewords):" << std::endl;
    for (size_t i = 0; i < probs.size(); ++i) {
        if (probs[i].real() > 1e-6) {
            std::cout << "| " << std::bitset<7>(i) << " > : " << probs[i].real() << std::endl;
        }
    }

    return 0;
}
