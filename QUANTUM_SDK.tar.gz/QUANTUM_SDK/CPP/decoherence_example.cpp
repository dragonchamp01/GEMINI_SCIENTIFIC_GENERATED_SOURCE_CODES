/**
 * [Alpha Quantum SDK]
 * Topic: T1 and T2 Relaxation Simulation (C++)
 * Purpose: Simulating longitudinal (T1) and transverse (T2) decoherence.
 */

#include "gemini_density.hpp"
#include <iostream>
#include <iomanip>

using namespace Gemini::Quantum;

int main() {
    std::cout << "--- Decoherence Analysis: T1 and T2 Relaxation (C++) ---" << std::endl;

    // 1. Amplitude Damping (T1)
    // Start in |1> and see it decay to |0>
    DensitySimulator sim_t1(1);
    Matrix X = {{0, 1}, {1, 0}};
    sim_t1.apply_unitary(X);
    
    std::cout << "
[T1 Relaxation]" << std::endl;
    std::cout << "Initial Prob(|1>): " << sim_t1.get_rho()[1][1].real() << std::endl;
    
    double gamma = 0.2; // Decay probability
    auto kraus_t1 = Noise::amplitude_damping(gamma);
    sim_t1.apply_kraus(kraus_t1, 0);
    std::cout << "Prob(|1>) after gamma=" << gamma << ": " << sim_t1.get_rho()[1][1].real() << std::endl;

    // 2. Phase Damping (T2)
    // Start in |+> and see coherence (off-diagonals) decay
    DensitySimulator sim_t2(1);
    double inv_sqrt2 = 1.0 / std::sqrt(2.0);
    Matrix H = {{inv_sqrt2, inv_sqrt2}, {inv_sqrt2, -inv_sqrt2}};
    sim_t2.apply_unitary(H);
    
    std::cout << "
[T2 Dephasing]" << std::endl;
    std::cout << "Initial Coherence (rho_01): " << sim_t2.get_rho()[0][1].real() << std::endl;
    
    double lambda = 0.3; // Dephasing factor
    auto kraus_t2 = Noise::phase_damping(lambda);
    sim_t2.apply_kraus(kraus_t2, 0);
    std::cout << "Coherence after lambda=" << lambda << ": " << sim_t2.get_rho()[0][1].real() << std::endl;

    return 0;
}
