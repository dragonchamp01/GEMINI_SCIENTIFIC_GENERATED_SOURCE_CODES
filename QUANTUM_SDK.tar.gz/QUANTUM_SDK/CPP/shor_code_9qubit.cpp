/**
 * [Alpha Quantum SDK - Error Correction]
 * Topic: Shor's 9-Qubit Code
 * Purpose: Protecting a logical qubit against any single-qubit error in C++.
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <bitset>
#include <iomanip>

using namespace Gemini::Quantum;

class ShorCode {
public:
    ShorCode() {
        std::cout << "Shor 9-Qubit Code (QEC) Core Engaged." << std::endl;
    }

    /**
     * @brief Encodes a logical qubit into 9 physical qubits.
     * @param initial_state_idx 0 for |0>L, 1 for |1>L.
     * @return StateVector 2^9 = 512 components.
     */
    StateVector encode(int initial_state_idx = 0) {
        Simulator sim(9);

        // 1. Prepare initial state
        if (initial_state_idx == 1) {
            sim.x(0);
        }

        // 2. Phase-flip (Outer) Encoding
        sim.cx(0, 3);
        sim.cx(0, 6);
        sim.h(0);
        sim.h(3);
        sim.h(6);

        // 3. Bit-flip (Inner) Encoding on each of the 3 blocks
        // Block 1 (0,1,2)
        sim.cx(0, 1);
        sim.cx(0, 2);
        // Block 2 (3,4,5)
        sim.cx(3, 4);
        sim.cx(3, 5);
        // Block 3 (6,7,8)
        sim.cx(6, 7);
        sim.cx(6, 8);

        return sim.get_probabilities(); // Returning probabilities for inspection
    }
};

int main() {
    ShorCode qec;

    std::cout << "
Encoding Logical |0> into 9-qubit state (C++)..." << std::endl;
    auto probs0 = qec.encode(0);

    std::cout << "
Non-zero amplitude indices for |0>L (Expected 8 basis states):" << std::endl;
    int count = 0;
    for (size_t i = 0; i < probs0.size(); ++i) {
        if (probs0[i].real() > 1e-6) {
            std::cout << "| " << std::bitset<9>(i) << " > : " 
                      << std::fixed << std::setprecision(3) << probs0[i].real() << std::endl;
            count++;
        }
    }
    std::cout << "Total basis states in superposition: " << count << std::endl;

    return 0;
}
