/**
 * [Alpha Quantum SDK]
 * Topic: Noisy Quantum Simulation & Error Analysis (C++)
 * Purpose: Demonstrating Kraus operator application and purity decay.
 */

#include "gemini_density.hpp"
#include <iostream>
#include <iomanip>

using namespace Gemini::Quantum;

int main() {
    std::cout << "--- Noisy Quantum Simulation (C++) ---" << std::endl;

    // 1. Initialize a 1-qubit density matrix simulator
    DensitySimulator sim(1);
    std::cout << "Initial Purity: " << sim.get_purity() << " (Pure state |0>)" << std::endl;

    // 2. Apply Hadamard Gate
    double inv_sqrt2 = 1.0 / std::sqrt(2.0);
    Matrix H = {{inv_sqrt2, inv_sqrt2}, {inv_sqrt2, -inv_sqrt2}};
    sim.apply_unitary(H);
    std::cout << "Purity after H: " << sim.get_purity() << " (Pure state |+>)" << std::endl;

    // 3. Apply 10% Depolarizing Noise
    double p = 0.1;
    auto noise = Noise::depolarizing(p);
    sim.apply_kraus(noise, 0);

    std::cout << "
Applying " << p*100 << "% Depolarizing Noise..." << std::endl;
    std::cout << "Final Purity: " << std::fixed << std::setprecision(4) << sim.get_purity() << std::endl;
    std::cout << "Expected: " << 1.0 - (4.0/3.0)*p*(1.0-p) << " (approx for 1-qubit depolarizing)" << std::endl;

    // 4. Print Density Matrix
    auto rho = sim.get_rho();
    std::cout << "
Final Density Matrix (rho):" << std::endl;
    for (const auto& row : rho) {
        for (const auto& val : row) {
            std::cout << "(" << val.real() << ", " << val.imag() << ") ";
        }
        std::cout << std::endl;
    }

    return 0;
}
