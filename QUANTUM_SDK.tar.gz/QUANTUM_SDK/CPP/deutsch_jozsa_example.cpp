/**
 * [Alpha Quantum SDK]
 * Topic: Deutsch-Jozsa Algorithm (C++)
 */

#include "gemini_quantum.hpp"
#include <iostream>
#include <string>

using namespace Gemini::Quantum;

bool deutsch_jozsa(int n_bits, std::string type) {
    int total = n_bits + 1;
    Simulator sim(total);

    // 1. Setup
    for (int i = 0; i < n_bits; ++i) sim.h(i);
    sim.x(n_bits); sim.h(n_bits);

    // 2. Oracle
    if (type == "balanced") {
        sim.cx(0, n_bits);
    } else { // constant
        sim.x(n_bits);
    }

    // 3. Hadamard back
    for (int i = 0; i < n_bits; ++i) sim.h(i);

    // 4. Measure input register
    int res = sim.measure();
    int input_reg = res & ((1 << n_bits) - 1);

    return input_reg == 0;
}

int main() {
    int n = 3;
    std::cout << "--- Deutsch-Jozsa Algorithm (C++) ---" << std::endl;

    bool res_c = deutsch_jozsa(n, "constant");
    std::cout << "Oracle: Constant -> Result: " << (res_c ? "Constant" : "Balanced") << std::endl;

    bool res_b = deutsch_jozsa(n, "balanced");
    std::cout << "Oracle: Balanced -> Result: " << (res_b ? "Constant" : "Balanced") << std::endl;

    return 0;
}
