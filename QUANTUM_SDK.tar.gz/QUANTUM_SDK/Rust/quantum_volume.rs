mod gemini_quantum;
use gemini_quantum::Simulator;
use rand::seq::SliceRandom;
use rand::Rng;
use std::f64::consts::PI;

fn get_heavy_prob(probs: &[f64]) -> f64 {
    let mut sorted = probs.to_vec();
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap());
    
    let mid = sorted.len() / 2;
    let median = if sorted.len() % 2 == 0 {
        (sorted[mid - 1] + sorted[mid]) / 2.0
    } else {
        sorted[mid]
    };
    
    probs.iter().filter(|&&p| p > median).sum()
}

fn run_qv_test(n_qubits: usize, n_trials: usize) -> bool {
    println!("--- Quantum Volume Benchmark (Rust): {} Qubits ---", n_qubits);
    
    let mut heavy_count = 0;
    let mut rng = rand::thread_rng();

    for _ in 0..n_trials {
        let mut sim = Simulator::new(n_qubits);
        
        for _layer in 0..n_qubits {
            // Random RY
            for q in 0..n_qubits {
                sim.ry(q, rng.gen::<f64>() * 2.0 * PI);
            }
            
            // Random entanglement
            let mut p: Vec<usize> = (0..n_qubits).collect();
            p.shuffle(&mut rng);
            for i in (0..n_qubits - 1).step_by(2) {
                sim.cx(p[i], p[i+1]);
            }
        }
        
        let probs = sim.get_probabilities();
        if get_heavy_prob(&probs) > 2.0/3.0 {
            heavy_count += 1;
        }
    }
    
    let success_rate = heavy_count as f64 / n_trials as f64;
    println!("Success Rate: {:.3} (Threshold: 0.667)", success_rate);
    success_rate > 2.0/3.0
}

fn main() {
    for n in 2..=10 {
        if run_qv_test(n, 50) {
            println!("PASSED: Log2(QV) >= {}", n);
        } else {
            println!("FAILED at {} qubits.", n);
            break;
        }
    }
}
