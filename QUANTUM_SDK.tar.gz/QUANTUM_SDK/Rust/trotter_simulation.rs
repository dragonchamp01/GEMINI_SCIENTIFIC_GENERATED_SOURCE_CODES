mod gemini_quantum;
use gemini_quantum::Simulator;

struct TFIMSimulation {
    n_qubits: usize,
    j: f64,
    h: f64,
}

impl TFIMSimulation {
    fn new(n: usize, j: f64, h: f64) -> Self {
        TFIMSimulation { n_qubits: n, j, h }
    }

    fn trotter_step(&self, sim: &mut Simulator, dt: f64) {
        // 1. ZZ Interaction: e^i J dt ZZ
        let phi_zz = -2.0 * self.j * dt;
        for i in 0..self.n_qubits - 1 {
            sim.cx(i, i + 1);
            sim.rz(i + 1, phi_zz);
            sim.cx(i, i + 1);
        }

        // 2. Transverse Field: e^i h dt X
        let phi_x = -2.0 * self.h * dt;
        for i in 0..self.n_qubits {
            sim.rx(i, phi_x);
        }
    }

    fn simulate(&self, t_final: f64, steps: usize) -> Vec<f64> {
        let dt = t_final / steps as f64;
        let mut sim = Simulator::new(self.n_qubits);

        for _ in 0..steps {
            self.trotter_step(&mut sim, dt);
        }

        sim.get_probabilities()
    }
}

fn main() {
    let n = 4;
    let j_val = 1.0;
    let h_val = 0.5;
    let t_total = 1.0;
    let n_steps = 20;

    println!("--- TFIM Time Evolution (Rust) ---");
    println!("Parameters: J={}, h={}, T={}", j_val, h_val, t_total);

    let sim = TFIMSimulation::new(n, j_val, h_val);
    let probs = sim.simulate(t_total, n_steps);

    println!("
Final State Sample Probabilities:");
    let indices = [0, 1, 8, 15];
    for &i in indices.iter() {
        if i < probs.len() {
            println!("| {:04b} > : {:.4}", i, probs[i]);
        }
    }

    let mut magnetization = 0.0;
    for (i, &p) in probs.iter().enumerate() {
        let mut n_ones = 0;
        for q in 0..n {
            if (i & (1 << q)) != 0 {
                n_ones += 1;
            }
        }
        let n_zeros = n - n_ones;
        magnetization += p * (n_zeros as f64 - n_ones as f64) / n as f64;
    }

    println!("
Average Magnetization <Z>: {:.4}", magnetization);
}
