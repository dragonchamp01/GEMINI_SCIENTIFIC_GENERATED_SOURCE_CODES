use std::f64::consts::PI;
use num_complex::Complex64;

pub struct Simulator {
    pub n_qubits: usize,
    pub state: Vec<Complex64>,
}

impl Simulator {
    pub fn new(n: usize) -> Self {
        let mut state = vec![Complex64::new(0.0, 0.0); 1 << n];
        state[0] = Complex64::new(1.0, 0.0);
        Simulator { n_qubits: n, state }
    }

    pub fn h(&mut self, target: usize) {
        let n_states = 1 << self.n_qubits;
        let inv_sqrt2 = 1.0 / (2.0f64).sqrt();
        let mask = 1 << target;

        for i in 0..n_states {
            if (i & mask) == 0 {
                let j = i | mask;
                let psi_i = self.state[i];
                let psi_j = self.state[j];

                self.state[i] = (psi_i + psi_j) * inv_sqrt2;
                self.state[j] = (psi_i - psi_j) * inv_sqrt2;
            }
        }
    }

    pub fn x(&mut self, target: usize) {
        let n_states = 1 << self.n_qubits;
        let mask = 1 << target;
        for i in 0..n_states {
            if (i & mask) == 0 {
                let j = i | mask;
                self.state.swap(i, j);
            }
        }
    }

    pub fn z(&mut self, target: usize) {
        let n_states = 1 << self.n_qubits;
        let mask = 1 << target;
        for i in 0..n_states {
            if (i & mask) != 0 {
                self.state[i] = -self.state[i];
            }
        }
    }

    pub fn rx(&mut self, target: usize, theta: f64) {
        let n_states = 1 << self.n_qubits;
        let mask = 1 << target;
        let (s, c) = (theta / 2.0).sin_cos();
        let cos_val = Complex64::new(c, 0.0);
        let sin_val = Complex64::new(0.0, -s);

        for i in 0..n_states {
            if (i & mask) == 0 {
                let j = i | mask;
                let psi_i = self.state[i];
                let psi_j = self.state[j];

                self.state[i] = cos_val * psi_i + sin_val * psi_j;
                self.state[j] = sin_val * psi_i + cos_val * psi_j;
            }
        }
    }

    pub fn ry(&mut self, target: usize, theta: f64) {
        let n_states = 1 << self.n_qubits;
        let mask = 1 << target;
        let (s, c) = (theta / 2.0).sin_cos();

        for i in 0..n_states {
            if (i & mask) == 0 {
                let j = i | mask;
                let psi_i = self.state[i];
                let psi_j = self.state[j];

                self.state[i] = c * psi_i - s * psi_j;
                self.state[j] = s * psi_i + c * psi_j;
            }
        }
    }

    pub fn rz(&mut self, target: usize, theta: f64) {
        let n_states = 1 << self.n_qubits;
        let mask = 1 << target;
        let p0 = Complex64::from_polar(1.0, -theta / 2.0);
        let p1 = Complex64::from_polar(1.0, theta / 2.0);

        for i in 0..n_states {
            if (i & mask) != 0 {
                self.state[i] *= p1;
            } else {
                self.state[i] *= p0;
            }
        }
    }

    pub fn cx(&mut self, control: usize, target: usize) {
        let n_states = 1 << self.n_qubits;
        let c_mask = 1 << control;
        let t_mask = 1 << target;
        for i in 0..n_states {
            if (i & c_mask) != 0 && (i & t_mask) == 0 {
                let j = i | t_mask;
                self.state.swap(i, j);
            }
        }
    }

    pub fn cp(&mut self, control: usize, target: usize, phi: f64) {
        let n_states = 1 << self.n_qubits;
        let c_mask = 1 << control;
        let t_mask = 1 << target;
        let phase = Complex64::from_polar(1.0, phi);
        for i in 0..n_states {
            if (i & c_mask) != 0 && (i & t_mask) != 0 {
                self.state[i] *= phase;
            }
        }
    }

    pub fn mcu(&mut self, controls: &[usize], target: usize, u: [[Complex64; 2]; 2]) {
        let n_states = 1 << self.n_qubits;
        let mut c_mask = 0;
        for &c in controls {
            c_mask |= 1 << c;
        }
        let t_mask = 1 << target;

        for i in 0..n_states {
            if (i & c_mask) == c_mask && (i & t_mask) == 0 {
                let j = i | t_mask;
                let psi_i = self.state[i];
                let psi_j = self.state[j];
                self.state[i] = u[0][0] * psi_i + u[0][1] * psi_j;
                self.state[j] = u[1][0] * psi_i + u[1][1] * psi_j;
            }
        }
    }

    pub fn ccx(&mut self, c1: usize, c2: usize, target: usize) {
        let n_states = 1 << self.n_qubits;
        let c1_mask = 1 << c1;
        let c2_mask = 1 << c2;
        let t_mask = 1 << target;
        for i in 0..n_states {
            if (i & c1_mask) != 0 && (i & c2_mask) != 0 && (i & t_mask) == 0 {
                let j = i | t_mask;
                self.state.swap(i, j);
            }
        }
    }

    pub fn get_probabilities(&self) -> Vec<f64> {
        self.state.iter().map(|c| c.norm_sqr()).collect()
    }

    pub fn print_state(&self) {
        for (i, &amp) in self.state.iter().enumerate() {
            if amp.norm_sqr() > 1e-6 {
                println!("| {} > : {:.3} + {:.3}i", i, amp.re, amp.im);
            }
        }
    }
}
