mod gemini_quantum;
use gemini_quantum::Simulator;

pub struct ShorCode;

impl ShorCode {
    pub fn new() -> Self {
        println!("Shor 9-Qubit Code (QEC) initialized [Rust].");
        ShorCode
    }

    pub fn encode(&self, initial_state_idx: usize) -> Vec<f64> {
        let mut sim = Simulator::new(9);

        // 1. Prepare initial state
        if initial_state_idx == 1 {
            sim.x(0);
        }

        // 2. Phase-flip (Outer) Encoding
        sim.cx(0, 3);
        sim.cx(0, 6);
        sim.h(0);
        sim.h(3);
        sim.h(6);

        // 3. Bit-flip (Inner) Encoding
        // Block 1
        sim.cx(0, 1);
        sim.cx(0, 2);
        // Block 2
        sim.cx(3, 4);
        sim.cx(3, 5);
        // Block 3
        sim.cx(6, 7);
        sim.cx(6, 8);

        sim.get_probabilities()
    }
}

fn main() {
    let qec = ShorCode::new();
    
    println!("Encoding Logical |0> (Rust)...");
    let probs = qec.encode(0);
    
    let mut count = 0;
    for (i, &p) in probs.iter().enumerate() {
        if p > 1e-6 {
            println!("| {:09b} > : {:.3}", i, p);
            count += 1;
        }
    }
    println!("Total non-zero basis states: {}", count);
}
