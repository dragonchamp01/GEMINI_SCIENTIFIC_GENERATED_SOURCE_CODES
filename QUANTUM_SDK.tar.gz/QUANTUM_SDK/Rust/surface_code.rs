mod gemini_quantum;
use gemini_quantum::Simulator;

fn main() {
    println!("--- Surface Code (d=3) Syndrome Cycle [Rust] ---");

    // 17 Qubits (9 data, 8 ancilla)
    let mut sim = Simulator::new(17);

    // Inject Error on Data 4
    sim.x(4);

    // X-Stabilizers
    for a in 9..13 { sim.h(a); }
    sim.cx(9, 0); sim.cx(9, 1); sim.cx(9, 3); sim.cx(9, 4);
    sim.cx(10, 1); sim.cx(10, 2); sim.cx(10, 4); sim.cx(10, 5);
    sim.cx(11, 3); sim.cx(11, 4); sim.cx(11, 6); sim.cx(11, 7);
    sim.cx(12, 4); sim.cx(12, 5); sim.cx(12, 7); sim.cx(12, 8);
    for a in 9..13 { sim.h(a); }

    // Z-Stabilizers
    sim.cx(0, 13); sim.cx(1, 13); sim.cx(3, 13); sim.cx(4, 13);
    sim.cx(1, 14); sim.cx(2, 14); sim.cx(4, 14); sim.cx(5, 14);
    sim.cx(3, 15); sim.cx(4, 15); sim.cx(6, 15); sim.cx(7, 15);
    sim.cx(4, 16); sim.cx(5, 16); sim.cx(7, 16); sim.cx(8, 16);

    println!("Simulation Complete. Extracting ancilla parities...");
    let probs = sim.get_probabilities();
    
    // Find most likely state
    let mut max_idx = 0;
    let mut max_p = 0.0;
    for (i, &p) in probs.iter().enumerate() {
        if p > max_p {
            max_p = p;
            max_idx = i;
        }
    }

    let syndrome = (max_idx >> 9) & 0xFF;
    println!("Measured Syndrome: {:08b}", syndrome);
}
