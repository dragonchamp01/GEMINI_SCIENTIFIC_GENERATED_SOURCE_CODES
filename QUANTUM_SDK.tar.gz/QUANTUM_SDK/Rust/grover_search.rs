mod gemini_quantum;
use gemini_quantum::Simulator;

fn main() {
    println!("--- Grover's Search Algorithm (Rust) ---");
    println!("Target State: |3> (|11>)");
    
    // 1. Initialize a 2-qubit simulator
    let mut sim = Simulator::new(2);
    
    // 2. Superposition
    sim.h(0);
    sim.h(1);
    
    // 3. Oracle (Flip |11> phase)
    sim.cp(0, 1, std::f64::consts::PI);
    
    // 4. Diffuser
    sim.h(0);
    sim.h(1);
    sim.x(0);
    sim.x(1);
    
    sim.cp(0, 1, std::f64::consts::PI);
    
    sim.x(0);
    sim.x(1);
    sim.h(0);
    sim.h(1);
    
    // 5. Results
    println!("Final Probabilities:");
    let probs = sim.get_probabilities();
    for (i, p) in probs.iter().enumerate() {
        println!("P(| {} >) = {:.4}", i, p);
    }
    
    if probs[3] > 0.99 {
        println!("SUCCESS: Target state |3> found with high probability.");
    }
}
