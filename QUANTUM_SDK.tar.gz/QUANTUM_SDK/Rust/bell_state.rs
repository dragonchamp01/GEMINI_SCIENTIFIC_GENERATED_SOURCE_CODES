mod gemini_quantum;
use gemini_quantum::Simulator;

fn main() {
    println!("--- Bell State |Phi+> Generation (Rust) ---");
    
    // 1. Initialize a 2-qubit simulator
    let mut sim = Simulator::new(2);
    
    // 2. Apply H to q0
    sim.h(0);
    
    // 3. Apply CX from q0 to q1
    sim.cx(0, 1);
    
    // 4. Print results
    println!("Statevector after circuit:");
    sim.print_state();
    
    let probs = sim.get_probabilities();
    println!("
Probabilities:");
    for (i, p) in probs.iter().enumerate() {
        println!("P(| {} >) = {:.4}", i, p);
    }
}
