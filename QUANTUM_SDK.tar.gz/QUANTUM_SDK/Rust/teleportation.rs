mod gemini_quantum;
use gemini_quantum::Simulator;

fn main() {
    println!("--- Quantum Teleportation Protocol (Rust) ---");
    
    // 3 Qubits: 0=Psi (Alice), 1=EPR_Alice, 2=EPR_Bob
    let mut sim = Simulator::new(3);
    
    // 1. Prepare State to Teleport: |+> on qubit 0
    sim.h(0);
    
    // 2. Create EPR Pair on qubits 1 and 2
    sim.h(1);
    sim.cx(1, 2);
    
    // 3. Alice measures in Bell Basis
    sim.cx(0, 1);
    sim.h(0);
    
    // 4. Bob applies corrections based on Alice's measurements
    // Simulated as controlled gates
    sim.cx(1, 2); // If q1=1, apply X
    
    // Controlled-Z logic: H-CX-H
    sim.h(2);
    sim.cx(0, 2);
    sim.h(2);
    
    println!("Final State Analysis:");
    sim.print_state();
    
    let probs = sim.get_probabilities();
    // Sum probabilities where Bob's qubit (bit 2) matches Alice's initial state
    // For |+>, it's complicated to see in basis states without statevector reconstruction,
    // but the simulator results will show the correct superposition.
}
