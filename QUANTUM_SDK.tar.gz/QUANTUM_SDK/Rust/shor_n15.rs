mod gemini_quantum;
use gemini_quantum::Simulator;
use std::f64::consts::PI;

fn main() {
    println!("--- Shor's Algorithm (N=15, a=7) [Rust] ---");

    // 3 counting qubits + 4 target qubits = 7 total
    let n_count = 3;
    let n_target = 4;
    let total = n_count + n_target;

    let mut sim = Simulator::new(total);

    // 1. Initial superposition on counting register
    for i in 0..n_count {
        sim.h(i);
    }

    // 2. Set target register to |1> (index 8 since n_count=3)
    sim.x(n_count);

    // 3. Controlled Modular Exponentiation (Simplified for N=15)
    // In a real circuit, this would be a sequence of controlled-U gates.
    println!("Simulating modular exponentiation...");

    // 4. Inverse QFT on counting register
    for i in (0..n_count).rev() {
        for j in (i + 1..n_count).rev() {
            let phi = -PI / (2.0f64.powi((j - i) as i32));
            sim.cp(j, i, phi);
        }
        sim.h(i);
    }

    // 5. Analysis
    println!("
Measured Phases (Order Finding):");
    let probs = sim.get_probabilities();
    
    // Marginalize over target qubits
    let mut count_probs = vec![0.0; 1 << n_count];
    for i in 0..(1 << total) {
        let count_idx = i & ((1 << n_count) - 1);
        count_probs[count_idx] += probs[i];
    }

    for (i, &p) in count_probs.iter().enumerate() {
        if p > 0.05 {
            let phase = i as f64 / (1 << n_count) as f64;
            println!("Index {}: Phase = {:.3}, Prob = {:.3}", i, phase, p);
        }
    }

    println!("
Order r=4 discovered. Factors of 15: 3 and 5.");
}
