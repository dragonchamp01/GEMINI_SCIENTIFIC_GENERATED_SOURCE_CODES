mod gemini_quantum;
use gemini_quantum::Simulator;

fn main() {
    println!("--- Steane 7-Qubit Code Encoding (Rust) ---");

    let mut sim = Simulator::new(7);

    // Encode |0>L
    sim.h(4); sim.h(5); sim.h(6);

    sim.cx(6, 1); sim.cx(6, 2); sim.cx(6, 3);
    sim.cx(5, 0); sim.cx(5, 2); sim.cx(5, 3);
    sim.cx(4, 0); sim.cx(4, 1); sim.cx(4, 3);

    println!("Steane |0>L State Probabilities:");
    let probs = sim.get_probabilities();
    
    let mut count = 0;
    for (i, &p) in probs.iter().enumerate() {
        if p > 1e-6 {
            println!("| {:07b} > : {:.3}", i, p);
            count += 1;
        }
    }
    println!("Total Hamming codewords in superposition: {}", count);
}
