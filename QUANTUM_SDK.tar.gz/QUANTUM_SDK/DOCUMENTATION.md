# Alpha Quantum Science SDK Documentation (v4.5)

The **Alpha Quantum Science SDK** is a unified, multi-language framework for quantum simulation, research, and education. It provides high-performance simulation cores and modular algorithm libraries.

## 🚀 Supported Languages

| Language | Module / Class | Key Features |
| :--- | :--- | :--- |
| **Python** | `gemini_circuit.py` | Object-oriented, Qiskit-like syntax, full gate set. |
| **C++** | `gemini_quantum.hpp` | High-performance, in-place state evolution, AVX-512 optimized. |
| **C++ (Noisy)**| `gemini_density.hpp` | Full rho evolution, Kraus operators, T1/T2 noise models. |
| **Free Pascal**| `GeminiQuantum.pas` | Object-oriented modeling, strict typing, educational focus. |
| **Julia** | `GeminiQuantum.jl` | Matrix-friendly, ideal for density matrix and open system research. |
| **Rust** | `gemini_quantum.rs` | Memory-safe, concurrency-ready, type-safe gate operations. |
| **Go** | `gemini_quantum.go` | Lightweight, fast compilation, built-in complex number support. |
| **NASM** | `gate_kernels.asm` | SSE/AVX optimized micro-kernels for bottleneck operations. |

---

## 🛠️ Gate Set

The SDK supports a universal gate set across all language cores:
- **Single-Qubit**: H, X, Y, Z, RX, RY, RZ, CP.
- **Two-Qubit**: CX (CNOT), CZ, CP.
- **Multi-Qubit**: CCX (Toffoli), MCP (Multi-Control Phase), MCU (Multi-Controlled Unitary).

---

## 🔄 Circuit Transpilation

The SDK includes tools to decompose complex gates into the fault-tolerant **Clifford+T** set ({H, S, T, CX}).

- **Python**: `gemini_transpiler.py`.
- **C++**: `gemini_transpiler.hpp`.
- **Julia**: `GeminiTranspiler.jl`.

---

## 🌊 Time Dynamics: Trotterization

The SDK supports real-time simulation of Hamiltonian evolution using the **Trotter-Suzuki decomposition**.

- **Example**: 1D Transverse Field Ising Model (TFIM).
- **Languages**: Python, C++, Rust, Julia.

---

## 🧪 Noisy Simulation & Density Matrices

The SDK provides advanced tools for simulating realistic, noisy quantum systems using the **Density Matrix ($\rho$)** formalism and **Kraus Operators**.

### Python Core
- `gemini_noise.py`: Full evolution of $\rho$ with standard noise channels (Depolarizing, T1, T2).
- `zne_mitigation.py`: Zero-Noise Extrapolation implementation.
- `entanglement_analysis.py`: Bell state purity analysis.

### C++ Core
- `gemini_density.hpp`: High-performance density matrix simulator using pure STL.
- **Noise Channels**: Depolarizing, Amplitude Damping (T1), Phase Damping (T2).
- `noisy_sim_example.cpp`: Demonstration of Kraus operator application.
- `decoherence_example.cpp`: Specialized T1/T2 decay analysis.

### Julia Core
- `GeminiQuantum.jl`: Includes `get_density_matrix`, `apply_kraus!`, and `partial_trace`.
- `noisy_gate_sim.jl`: Example of decoherence in Julia.

---

## ⚛️ Quantum Chemistry (VQE)

The SDK includes molecular models for variational research:
- **H2 Molecule (Python, C++, Julia)**: Simulates a 2-qubit Hydrogen molecule Hamiltonian at equilibrium distance (0.75A).
- **LiH Molecule (Python, C++, Julia)**: Simulates a **4-qubit** Lithium Hydride molecule using a hardware-efficient Ansatz and Hartree-Fock initial state preparation.

---

## 📊 Benchmarking: Quantum Volume (QV)

The SDK includes tools to measure the quality and reliability of the simulated engines using the **Quantum Volume** protocol.

- **Python**: `quantum_volume.py`.
- **C++**: `quantum_volume.cpp`.
- **Julia**: `quantum_volume.jl`.
- **Rust**: `quantum_volume.rs`.
- **Protocol**: A simulation passes for $n$ qubits if the probability of measuring a "heavy" state is $> 2/3$.

---

## 🏗️ Unified Build System

The SDK includes a comprehensive build system using **Makefiles** across all language modules.

### Root Build
The master `Makefile` at the project root discovers and executes all sub-Makefiles.
```bash
make
```

### Verification
To perform a full ecosystem syntax and compilation check:
```bash
make verify
```

---

## ⚡ Performance Tuning (C++)

The C++ `Simulator` core features hardware-specific optimizations using SIMD.
- **AVX2 (256-bit)**: Processes 2 complex numbers in parallel.
- **AVX-512 (512-bit)**: Processes 4 complex numbers in parallel.

---

## 📚 Algorithm Library

- **Shor's Algorithm (N=15)**: Prime factorization using order finding.
- **Grover Search (3-Qubit)**: Target state $|111\rangle$ using MCP gates.
- **Deutsch-Jozsa**: Characterizing functions as constant or balanced.
- **Bernstein-Vazirani**: Identifying hidden bitstrings.
- **VQE Molecular Model (H2)**: Finding ground state energy.
- **Quantum Teleportation**: Information transfer via entanglement.

---

## 🛡 Quantum Error Correction (QEC)

- **Shor 9-Qubit Code**: Protecting against bit and phase flips.
- **Steane 7-Qubit Code**: CSS code implementation.
- **Surface Code (d=3)**: 17-qubit syndrome extraction cycle.

---

## 🧪 Error Recovery

If you encounter compilation errors:
1. Ensure you have `g++` (v7+), `fpc`, `rustc`, `go`, `julia`, and `python3` installed.
2. For C++ AVX support, ensure your CPU supports the instruction set or remove the `-mavx` flags from the local `Makefile`.
3. Run `make clean` before rebuilding.
