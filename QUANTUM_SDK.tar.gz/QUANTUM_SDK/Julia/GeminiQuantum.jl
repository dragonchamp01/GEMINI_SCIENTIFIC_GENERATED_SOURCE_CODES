module GeminiQuantum

using LinearAlgebra

export QuantumState, h!, x!, z!, cx!, cz!, cp!, ccx!, measure, get_probabilities

mutable struct QuantumState
    n::Int
    psi::Vector{ComplexF64}
end

function QuantumState(n::Int)
    psi = zeros(ComplexF64, 2^n)
    psi[1] = 1.0
    return QuantumState(n, psi)
end

function h!(state::QuantumState, target::Int)
    n = state.n
    inv_sqrt2 = 1.0 / sqrt(2.0)
    mask = 1 << target
    for i in 0:(2^n - 1)
        if (i & mask) == 0
            j = i | mask
            # Julia uses 1-based indexing
            idx_i = i + 1
            idx_j = j + 1
            psi_i = state.psi[idx_i]
            psi_j = state.psi[idx_j]
            state.psi[idx_i] = (psi_i + psi_j) * inv_sqrt2
            state.psi[idx_j] = (psi_i - psi_j) * inv_sqrt2
        end
    end
end

function x!(state::QuantumState, target::Int)
    n = state.n
    mask = 1 << target
    for i in 0:(2^n - 1)
        if (i & mask) == 0
            j = i | mask
            idx_i = i + 1
            idx_j = j + 1
            state.psi[idx_i], state.psi[idx_j] = state.psi[idx_j], state.psi[idx_i]
        end
    end
end

function z!(state::QuantumState, target::Int)
    n = state.n
    mask = 1 << target
    for i in 0:(2^n - 1)
        if (i & mask) != 0
            state.psi[i + 1] *= -1.0
        end
    end
end

function ry!(state::QuantumState, target::Int, theta::Float64)
    n = state.n
    mask = 1 << target
    c = cos(theta / 2)
    s = sin(theta / 2)
    for i in 0:(2^n - 1)
        if (i & mask) == 0
            j = i | mask
            idx_i = i + 1
            idx_j = j + 1
            psi_i = state.psi[idx_i]
            psi_j = state.psi[idx_j]
            state.psi[idx_i] = c * psi_i - s * psi_j
            state.psi[idx_j] = s * psi_i + c * psi_j
        end
    end
end

function cz!(state::QuantumState, control::Int, target::Int)
    n = state.n
    c_mask = 1 << control
    t_mask = 1 << target
    for i in 0:(2^n - 1)
        if (i & c_mask) != 0 && (i & t_mask) != 0
            state.psi[i + 1] *= -1.0
        end
    end
end

function cp!(state::QuantumState, control::Int, target::Int, phi::Float64)
    n = state.n
    c_mask = 1 << control
    t_mask = 1 << target
    phase = exp(1im * phi)
    for i in 0:(2^n - 1)
        if (i & c_mask) != 0 && (i & t_mask) != 0
            state.psi[i + 1] *= phase
        end
    end
end

function cx!(state::QuantumState, control::Int, target::Int)
    n = state.n
    c_mask = 1 << control
    t_mask = 1 << target
    for i in 0:(2^n - 1)
        if (i & c_mask) != 0 && (i & t_mask) == 0
            j = i | t_mask
            idx_i = i + 1
            idx_j = j + 1
            state.psi[idx_i], state.psi[idx_j] = state.psi[idx_j], state.psi[idx_i]
        end
    end
end

function ccx!(state::QuantumState, c1::Int, c2::Int, target::Int)
    n = state.n
    c1_mask = 1 << c1
    c2_mask = 1 << c2
    t_mask = 1 << target
    for i in 0:(2^n - 1)
        if (i & c1_mask) != 0 && (i & c2_mask) != 0 && (i & t_mask) == 0
            j = i | t_mask
            idx_i = i + 1
            idx_j = j + 1
            state.psi[idx_i], state.psi[idx_j] = state.psi[idx_j], state.psi[idx_i]
        end
    end
end

function get_probabilities(state::QuantumState)
    return abs2.(state.psi)
end

function measure(state::QuantumState)
    probs = get_probabilities(state)
    r = rand()
    cum = 0.0
    for (i, p) in enumerate(probs)
        cum += p
        if r < cum
            return i - 1
        end
    end
    return length(probs) - 1
end

end
