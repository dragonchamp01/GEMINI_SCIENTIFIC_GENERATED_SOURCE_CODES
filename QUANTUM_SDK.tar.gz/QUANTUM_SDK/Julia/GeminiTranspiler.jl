module GeminiTranspiler

using ..GeminiQuantum

export Circuit, h!, x!, cx!, rz!, transpile!, execute!

mutable struct Gate
    name::String
    qubits::Vector{Int}
    theta::Float64
end

mutable struct Circuit
    n::Int
    gates::Vector{Gate}
end

Circuit(n::Int) = Circuit(n, Gate[])

h!(c::Circuit, q::Int) = push!(c.gates, Gate("H", [q], 0.0))
x!(c::Circuit, q::Int) = push!(c.gates, Gate("X", [q], 0.0))
cx!(c::Circuit, ctrl::Int, target::Int) = push!(c.gates, Gate("CX", [ctrl, target], 0.0))
rz!(c::Circuit, q::Int, theta::Float64) = push!(c.gates, Gate("RZ", [q], theta))

function transpile!(c::Circuit)
    new_gates = Gate[]
    for g in c.gates
        if g.name == "RZ"
            if isapprox(g.theta, π/4)
                push!(new_gates, Gate("T", g.qubits, 0.0))
            elseif isapprox(g.theta, π/2)
                push!(new_gates, Gate("S", g.qubits, 0.0))
            else
                push!(new_gates, g)
            end
        else
            push!(new_gates, g)
        end
    end
    c.gates = new_gates
end

function execute!(sim::QuantumState, c::Circuit)
    for g in c.gates
        if g.name == "H"
            GeminiQuantum.h!(sim, g.qubits[1])
        elseif g.name == "X"
            GeminiQuantum.x!(sim, g.qubits[1])
        elseif g.name == "CX"
            GeminiQuantum.cx!(sim, g.qubits[1], g.qubits[2])
        elseif g.name == "RZ"
            GeminiQuantum.rz!(sim, g.qubits[1], g.theta)
        elseif g.name == "T"
            GeminiQuantum.rz!(sim, g.qubits[1], π/4)
        elseif g.name == "S"
            GeminiQuantum.rz!(sim, g.qubits[1], π/2)
        end
    end
end

end
