push!(LOAD_PATH, "../../../")
using GeminiQuantum
using LinearAlgebra
using Statistics
using Random

function get_heavy_outputs(probs)
    m = median(probs)
    return findall(p -> p > m, probs) .- 1 # 0-indexed
end

function run_qv_test(n_qubits, n_trials=100)
    println("--- Quantum Volume Benchmark (Julia): $n_qubits Qubits ---")
    
    heavy_count = 0
    for trial in 1:n_trials
        sim = QuantumState(n_qubits)
        
        # Random square circuit depth = n_qubits
        for layer in 1:n_qubits
            # Random RY
            for q in 0:n_qubits-1
                ry!(sim, q, rand() * 2π)
            end
            
            # Random entanglement layer
            p = shuffle(0:n_qubits-1)
            for i in 1:2:(n_qubits-1)
                cx!(sim, p[i], p[i+1])
            end
        end
        
        probs = get_probabilities(sim)
        heavy_indices = get_heavy_outputs(probs)
        
        heavy_prob_total = sum(probs[idx + 1] for idx in heavy_indices)
        
        if heavy_prob_total > 2/3
            heavy_count += 1
        end
    end
    
    success_rate = heavy_count / n_trials
    println("Success Rate: $(round(success_rate, digits=3)) (Threshold: 0.667)")
    return success_rate > 2/3
end

function benchmark_qv()
    for n in 2:10
        if run_qv_test(n, 50)
            println("PASSED: Log2(QV) >= $n")
        else
            println("FAILED at $n qubits.")
            break
        end
    end
end

benchmark_qv()
