package main

import (
    "fmt"
    "QUANTUM_SDK/Go/gemini_quantum"
)

func main() {
    fmt.Println("--- Grover's Search Algorithm (Go) ---")
    fmt.Println("Target State: |3> (|11>)")
    
    // 1. Initialize a 2-qubit simulator
    sim := gemini_quantum.NewSimulator(2)
    
    // 2. Superposition
    sim.H(0)
    sim.H(1)
    
    // 3. Oracle (Flip |11> phase)
    // CZ using H-CX-H
    sim.H(1)
    sim.CX(0, 1)
    sim.H(1)
    
    // 4. Diffuser
    sim.H(0)
    sim.H(1)
    sim.X(0)
    sim.X(1)
    
    sim.H(1)
    sim.CX(0, 1)
    sim.H(1)
    
    sim.X(0)
    sim.X(1)
    sim.H(0)
    sim.H(1)
    
    // 5. Results
    fmt.Println("Final Probabilities:")
    probs := sim.GetProbabilities()
    for i, p := range probs {
        fmt.Printf("P(| %d >) = %.4f
", i, p)
    }
    
    if probs[3] > 0.99 {
        fmt.Println("SUCCESS: Target state |3> found with high probability.")
    }
}
