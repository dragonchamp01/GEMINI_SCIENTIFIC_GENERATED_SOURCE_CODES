package main

import (
    "fmt"
    "QUANTUM_SDK/Go/gemini_quantum"
)

func main() {
    fmt.Println("--- Quantum Teleportation Protocol (Go) ---")
    
    // 3 Qubits: 0=Psi (Alice), 1=EPR_Alice, 2=EPR_Bob
    sim := gemini_quantum.NewSimulator(3)
    
    // 1. Prepare State to Teleport: |+> on qubit 0
    sim.H(0)
    
    // 2. Create EPR Pair on qubits 1 and 2
    sim.H(1)
    sim.CX(1, 2)
    
    // 3. Bell Measurement
    sim.CX(0, 1)
    sim.H(0)
    
    // 4. Corrections
    sim.CX(1, 2)
    
    // CZ using H-CX-H
    sim.H(2)
    sim.CX(0, 2)
    sim.H(2)
    
    fmt.Println("Final State Analysis:")
    sim.PrintState()
}
