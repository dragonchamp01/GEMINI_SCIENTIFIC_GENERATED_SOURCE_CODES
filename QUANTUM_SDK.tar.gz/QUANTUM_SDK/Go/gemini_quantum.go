package gemini_quantum

import (
    "fmt"
    "math"
    "math/cmplx"
)

type Simulator struct {
    NQubits int
    State   []complex128
}

func NewSimulator(n int) *Simulator {
    state := make([]complex128, 1<<n)
    state[0] = 1.0
    return &Simulator{NQubits: n, State: state}
}

func (s *Simulator) H(target int) {
    nStates := 1 << s.NQubits
    invSqrt2 := 1.0 / math.Sqrt(2.0)
    mask := 1 << target

    for i := 0; i < nStates; i++ {
        if (i & mask) == 0 {
            j := i | mask
            psi_i := s.State[i]
            psi_j := s.State[j]

            s.State[i] = (psi_i + psi_j) * complex(invSqrt2, 0)
            s.State[j] = (psi_i - psi_j) * complex(invSqrt2, 0)
        }
    }
}

func (s *Simulator) X(target int) {
    nStates := 1 << s.NQubits
    mask := 1 << target
    for i := 0; i < nStates; i++ {
        if (i & mask) == 0 {
            j := i | mask
            s.State[i], s.State[j] = s.State[j], s.State[i]
        }
    }
}

func (s *Simulator) Z(target int) {
    nStates := 1 << s.NQubits
    mask := 1 << target
    for i := 0; i < nStates; i++ {
        if (i & mask) != 0 {
            s.State[i] = -s.State[i]
        }
    }
}

func (s *Simulator) CX(control, target int) {
    nStates := 1 << s.NQubits
    c_mask := 1 << control
    t_mask := 1 << target
    for i := 0; i < nStates; i++ {
        if (i & c_mask) != 0 && (i & t_mask) == 0 {
            j := i | t_mask
            s.State[i], s.State[j] = s.State[j], s.State[i]
        }
    }
}

func (s *Simulator) CP(control, target int, phi float64) {
    nStates := 1 << s.NQubits
    c_mask := 1 << control
    t_mask := 1 << target
    phase := cmplx.Exp(complex(0, phi))
    for i := 0; i < nStates; i++ {
        if (i & c_mask) != 0 && (i & t_mask) != 0 {
            s.State[i] *= phase
        }
    }
}

func (s *Simulator) CCX(c1, c2, target int) {
    nStates := 1 << s.NQubits
    c1_mask := 1 << c1
    c2_mask := 1 << c2
    t_mask := 1 << target
    for i := 0; i < nStates; i++ {
        if (i & c1_mask) != 0 && (i & c2_mask) != 0 && (i & t_mask) == 0 {
            j := i | t_mask
            s.State[i], s.State[j] = s.State[j], s.State[i]
        }
    }
}

func (s *Simulator) GetProbabilities() []float64 {
    probs := make([]float64, len(s.State))
    for i, amp := range s.State {
        probs[i] = real(cmplx.Conj(amp) * amp)
    }
    return probs
}

func (s *Simulator) PrintState() {
    for i, amp := range s.State {
        if real(cmplx.Conj(amp)*amp) > 1e-6 {
            fmt.Printf("| %d > : %.3f + %.3fi
", i, real(amp), imag(amp))
        }
    }
}
