package main

import (
    "fmt"
    "QUANTUM_SDK/Go/gemini_quantum"
)

func main() {
    fmt.Println("--- Bell State |Phi+> Generation (Go) ---")
    
    // 1. Initialize a 2-qubit simulator
    sim := gemini_quantum.NewSimulator(2)
    
    // 2. Apply H to q0
    sim.H(0)
    
    // 3. Apply CX from q0 to q1
    sim.CX(0, 1)
    
    // 4. Print results
    fmt.Println("Statevector after circuit:")
    sim.PrintState()
    
    probs := sim.GetProbabilities()
    fmt.Println("
Probabilities:")
    for i, p := range probs {
        fmt.Printf("P(| %d >) = %.4f
", i, p)
    }
}
