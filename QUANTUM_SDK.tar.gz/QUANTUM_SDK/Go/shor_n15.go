package main

import (
    "fmt"
    "math"
    "QUANTUM_SDK/Go/gemini_quantum"
)

func main() {
    fmt.Println("--- Shor's Algorithm (N=15, a=7) [Go] ---")

    // 3 counting qubits + 4 target qubits = 7 total
    nCount := 3
    nTarget := 4
    total := nCount + nTarget

    sim := gemini_quantum.NewSimulator(total)

    // 1. Superposition
    for i := 0; i < nCount; i++ {
        sim.H(i)
    }

    // 2. Target register to |1>
    sim.X(nCount)

    // 3. Modular Exponentiation
    fmt.Println("Simulating modular exponentiation...")

    // 4. Inverse QFT
    for i := nCount - 1; i >= 0; i-- {
        for j := nCount - 1; j > i; j-- {
            phi := -math.Pi / math.Pow(2.0, float64(j-i))
            sim.CP(j, i, phi)
        }
        sim.H(i)
    }

    // 5. Analysis
    fmt.Println("
Measured Phases:")
    probs := sim.GetProbabilities()
    
    countProbs := make([]float64, 1<<nCount)
    for i := 0; i < (1 << total); i++ {
        countIdx := i & ((1 << nCount) - 1)
        countProbs[countIdx] += probs[i]
    }

    for i, p := range countProbs {
        if p > 0.05 {
            phase := float64(i) / float64(1<<nCount)
            fmt.Printf("Index %d: Phase = %.3f, Prob = %.3f
", i, phase, p)
        }
    }

    fmt.Println("
Order r=4 found. Factors: 3, 5")
}
